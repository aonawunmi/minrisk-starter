import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// src/components/OperationsTabGroup.tsx
// Grouped tab for Incidents, Intelligence, and History
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
export function OperationsTabGroup({ IncidentsContent, IntelligenceContent, HistoryContent, }) {
    return (_jsxs(Tabs, { defaultValue: "incidents", className: "w-full", children: [_jsxs(TabsList, { children: [_jsx(TabsTrigger, { value: "incidents", children: "\uD83D\uDEA8 Incidents" }), _jsx(TabsTrigger, { value: "intelligence", children: "\uD83E\uDDE0 Intelligence" }), _jsx(TabsTrigger, { value: "history", children: "\uD83D\uDCDC History" })] }), _jsx(TabsContent, { value: "incidents", className: "space-y-4", children: IncidentsContent }), _jsx(TabsContent, { value: "intelligence", className: "space-y-4", children: IntelligenceContent }), _jsx(TabsContent, { value: "history", className: "space-y-4", children: HistoryContent })] }));
}
