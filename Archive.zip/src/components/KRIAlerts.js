import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// src/components/KRIAlerts.tsx
// KRI Alerts - View and manage threshold breaches
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle } from 'lucide-react';
import { loadKRIAlerts, loadKRIDefinitions } from '@/lib/kri';
export function KRIAlerts() {
    const [alerts, setAlerts] = useState([]);
    const [kris, setKris] = useState([]);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        Promise.all([
            loadKRIAlerts(),
            loadKRIDefinitions(),
        ]).then(([alertsData, krisData]) => {
            setAlerts(alertsData);
            setKris(krisData);
        }).finally(() => setLoading(false));
    }, []);
    if (loading) {
        return _jsx("div", { className: "p-8 text-center", children: "Loading alerts..." });
    }
    const getAlertColor = (level) => {
        return level === 'red'
            ? 'bg-red-100 text-red-800 border-red-200'
            : 'bg-yellow-100 text-yellow-800 border-yellow-200';
    };
    return (_jsxs("div", { className: "space-y-4", children: [_jsx("h2", { className: "text-2xl font-bold", children: "KRI Alerts" }), _jsxs(Card, { children: [_jsx(CardHeader, { children: _jsxs(CardTitle, { children: ["All Alerts (", alerts.length, ")"] }) }), _jsx(CardContent, { children: alerts.length === 0 ? (_jsxs("div", { className: "text-center py-12 text-gray-500", children: [_jsx(AlertTriangle, { className: "h-12 w-12 mx-auto mb-3 opacity-50" }), _jsx("p", { children: "No alerts" }), _jsx("p", { className: "text-sm mt-2", children: "Alerts will appear when KRIs breach thresholds" })] })) : (_jsx("div", { className: "space-y-2", children: alerts.map((alert) => {
                                const kri = kris.find(k => k.id === alert.kri_id);
                                return (_jsx("div", { className: `p-4 rounded-lg border ${getAlertColor(alert.alert_level)}`, children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { className: "flex-1", children: [_jsx("div", { className: "font-medium", children: kri?.kri_name || 'Unknown KRI' }), _jsxs("div", { className: "text-sm mt-1", children: ["Measured: ", _jsx("span", { className: "font-semibold", children: alert.measured_value }), " | Threshold: ", _jsx("span", { className: "font-semibold", children: alert.threshold_breached })] }), _jsxs("div", { className: "text-xs mt-2", children: ["Date: ", new Date(alert.alert_date).toLocaleDateString(), " | Status: ", alert.status] })] }), _jsx("span", { className: `px-3 py-1 rounded text-xs font-medium ${alert.alert_level === 'red' ? 'bg-red-600 text-white' : 'bg-yellow-600 text-white'}`, children: alert.alert_level === 'red' ? 'CRITICAL' : 'WARNING' })] }) }, alert.id));
                            }) })) })] })] }));
}
