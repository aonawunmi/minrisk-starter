import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// src/components/KRIDashboard.tsx
// KRI Dashboard - Overview of KRIs, trends, and alerts
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { TrendingDown, AlertTriangle, CheckCircle2, Activity } from 'lucide-react';
import { loadKRIDefinitions, getKRIDashboardSummary, loadKRIAlerts, } from '@/lib/kri';
export function KRIDashboard() {
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [summary, setSummary] = useState(null);
    const [alerts, setAlerts] = useState([]);
    const [kris, setKris] = useState([]);
    useEffect(() => {
        loadDashboardData();
    }, []);
    const loadDashboardData = async () => {
        try {
            setLoading(true);
            setError(null);
            const [summaryData, alertsData, krisData] = await Promise.all([
                getKRIDashboardSummary(),
                loadKRIAlerts(),
                loadKRIDefinitions(false),
            ]);
            setSummary(summaryData);
            setAlerts(alertsData);
            setKris(krisData);
        }
        catch (err) {
            console.error('Failed to load KRI dashboard:', err);
            setError('Failed to load dashboard data');
        }
        finally {
            setLoading(false);
        }
    };
    if (loading) {
        return (_jsx("div", { className: "flex items-center justify-center p-12", children: _jsxs("div", { className: "text-center", children: [_jsx(Activity, { className: "h-8 w-8 animate-spin mx-auto mb-2 text-blue-500" }), _jsx("p", { className: "text-gray-600", children: "Loading KRI Dashboard..." })] }) }));
    }
    if (error) {
        return (_jsxs(Alert, { variant: "destructive", children: [_jsx(AlertTriangle, { className: "h-4 w-4" }), _jsx(AlertDescription, { children: error })] }));
    }
    const getAlertColor = (level) => {
        switch (level) {
            case 'red':
                return 'bg-red-100 text-red-800 border-red-200';
            case 'yellow':
                return 'bg-yellow-100 text-yellow-800 border-yellow-200';
            default:
                return 'bg-green-100 text-green-800 border-green-200';
        }
    };
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: [_jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardTitle, { className: "text-sm font-medium text-gray-600", children: "Total KRIs" }) }), _jsxs(CardContent, { children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx("div", { className: "text-3xl font-bold", children: summary?.totalKRIs || 0 }), _jsx(Activity, { className: "h-8 w-8 text-blue-500" })] }), _jsxs("p", { className: "text-xs text-gray-500 mt-1", children: [summary?.activeKRIs || 0, " active"] })] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardTitle, { className: "text-sm font-medium text-gray-600", children: "Open Alerts" }) }), _jsxs(CardContent, { children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx("div", { className: "text-3xl font-bold text-red-600", children: summary?.openAlerts || 0 }), _jsx(AlertTriangle, { className: "h-8 w-8 text-red-500" })] }), _jsxs("p", { className: "text-xs text-gray-500 mt-1", children: [summary?.redAlerts || 0, " critical"] })] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardTitle, { className: "text-sm font-medium text-gray-600", children: "Within Thresholds" }) }), _jsxs(CardContent, { children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx("div", { className: "text-3xl font-bold text-green-600", children: summary?.greenKRIs || 0 }), _jsx(CheckCircle2, { className: "h-8 w-8 text-green-500" })] }), _jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Performing well" })] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardTitle, { className: "text-sm font-medium text-gray-600", children: "At Risk" }) }), _jsxs(CardContent, { children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx("div", { className: "text-3xl font-bold text-yellow-600", children: summary?.atRiskKRIs || 0 }), _jsx(TrendingDown, { className: "h-8 w-8 text-yellow-500" })] }), _jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Needs attention" })] })] })] }), alerts.length > 0 && (_jsxs(Card, { children: [_jsx(CardHeader, { children: _jsxs(CardTitle, { className: "flex items-center gap-2", children: [_jsx(AlertTriangle, { className: "h-5 w-5 text-red-500" }), "Active Alerts"] }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "space-y-2", children: alerts.slice(0, 5).map((alert) => {
                                    const kri = kris.find(k => k.id === alert.kri_id);
                                    return (_jsx("div", { className: `p-3 rounded-lg border ${getAlertColor(alert.alert_level)}`, children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { className: "flex-1", children: [_jsx("div", { className: "font-medium", children: kri?.kri_name || 'Unknown KRI' }), _jsxs("div", { className: "text-sm mt-1", children: ["Measured: ", _jsx("span", { className: "font-semibold", children: alert.measured_value }), " | Threshold: ", _jsx("span", { className: "font-semibold", children: alert.threshold_breached })] }), _jsx("div", { className: "text-xs text-gray-600 mt-1", children: new Date(alert.alert_date).toLocaleDateString() })] }), _jsx("span", { className: `px-2 py-1 rounded text-xs font-medium ${alert.alert_level === 'red' ? 'bg-red-600 text-white' : 'bg-yellow-600 text-white'}`, children: alert.alert_level === 'red' ? 'CRITICAL' : 'WARNING' })] }) }, alert.id));
                                }) }), alerts.length > 5 && (_jsxs("p", { className: "text-sm text-gray-500 mt-3 text-center", children: ["+", alerts.length - 5, " more alerts"] }))] })] })), _jsxs(Card, { children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "KRI Status Overview" }) }), _jsx(CardContent, { children: kris.length === 0 ? (_jsxs("div", { className: "text-center py-8 text-gray-500", children: [_jsx(Activity, { className: "h-12 w-12 mx-auto mb-3 opacity-50" }), _jsx("p", { children: "No KRIs defined yet" }), _jsx("p", { className: "text-sm mt-1", children: "Start by creating your first Key Risk Indicator" })] })) : (_jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4", children: kris.slice(0, 6).map((kri) => (_jsxs("div", { className: "p-4 border rounded-lg", children: [_jsxs("div", { className: "flex items-start justify-between mb-2", children: [_jsx("div", { className: "font-medium text-sm", children: kri.kri_code }), _jsx("span", { className: `px-2 py-0.5 rounded text-xs ${kri.enabled ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'}`, children: kri.enabled ? 'Active' : 'Disabled' })] }), _jsx("div", { className: "text-xs text-gray-900 font-medium mb-1", children: kri.kri_name }), _jsx("div", { className: "text-xs text-gray-500", children: kri.category || 'Uncategorized' }), _jsxs("div", { className: "text-xs text-gray-500 mt-2", children: ["Frequency: ", kri.collection_frequency] })] }, kri.id))) })) })] }), kris.length === 0 && (_jsxs(Card, { children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "Getting Started with KRIs" }) }), _jsx(CardContent, { children: _jsxs("div", { className: "space-y-3 text-sm", children: [_jsxs("div", { className: "flex gap-3", children: [_jsx("div", { className: "flex-shrink-0 w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-semibold", children: "1" }), _jsxs("div", { children: [_jsx("div", { className: "font-medium", children: "Define Your KRIs" }), _jsx("div", { className: "text-gray-600", children: "Go to KRI Management and create Key Risk Indicators with thresholds" })] })] }), _jsxs("div", { className: "flex gap-3", children: [_jsx("div", { className: "flex-shrink-0 w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-semibold", children: "2" }), _jsxs("div", { children: [_jsx("div", { className: "font-medium", children: "Enter Measurements" }), _jsx("div", { className: "text-gray-600", children: "Record KRI values regularly in the Data Entry tab" })] })] }), _jsxs("div", { className: "flex gap-3", children: [_jsx("div", { className: "flex-shrink-0 w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-semibold", children: "3" }), _jsxs("div", { children: [_jsx("div", { className: "font-medium", children: "Monitor Alerts" }), _jsx("div", { className: "text-gray-600", children: "Get automatic alerts when KRIs breach thresholds" })] })] })] }) })] }))] }));
}
