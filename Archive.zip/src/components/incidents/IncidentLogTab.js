import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// src/components/incidents/IncidentLogTab.tsx
// Main Incidents Log Tab Component
import { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Search, Download, AlertTriangle, CheckCircle, Clock, XCircle, Link as LinkIcon, TrendingUp, DollarSign, } from 'lucide-react';
import { loadIncidents, getIncidentStatistics } from '@/lib/incidents';
import { IncidentForm } from './IncidentForm';
import { IncidentDetailDialog } from './IncidentDetailDialog';
// =====================================================
// HELPER FUNCTIONS
// =====================================================
const getSeverityColor = (severity) => {
    switch (severity) {
        case 5: return 'bg-red-600 text-white';
        case 4: return 'bg-orange-500 text-white';
        case 3: return 'bg-yellow-400 text-gray-900';
        case 2: return 'bg-blue-400 text-white';
        case 1: return 'bg-green-400 text-white';
        default: return 'bg-gray-400 text-white';
    }
};
const getStatusIcon = (status) => {
    switch (status) {
        case 'Reported': return _jsx(AlertTriangle, { className: "h-4 w-4 text-yellow-600" });
        case 'Under Investigation': return _jsx(Clock, { className: "h-4 w-4 text-blue-600" });
        case 'Resolved': return _jsx(CheckCircle, { className: "h-4 w-4 text-green-600" });
        case 'Closed': return _jsx(XCircle, { className: "h-4 w-4 text-gray-600" });
        default: return null;
    }
};
const formatCurrency = (amount) => {
    if (!amount)
        return 'N/A';
    return new Intl.NumberFormat('en-NG', {
        style: 'currency',
        currency: 'NGN',
        minimumFractionDigits: 0,
    }).format(amount);
};
const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
};
export function IncidentLogTab({ onRisksUpdate, isAdmin = false } = {}) {
    // State
    const [incidents, setIncidents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [sortConfig, setSortConfig] = useState({ key: 'incident_date', direction: 'desc' });
    const [filterConfig, setFilterConfig] = useState({
        status: 'all',
        type: 'all',
        severity: 'all',
        hasLinkedRisks: 'all',
        reportedBy: 'all',
    });
    const [showCreateDialog, setShowCreateDialog] = useState(false);
    const [selectedIncident, setSelectedIncident] = useState(null);
    const [statistics, setStatistics] = useState(null);
    // Load incidents
    useEffect(() => {
        loadIncidentsData();
        loadStatistics();
    }, []);
    const loadIncidentsData = async () => {
        setLoading(true);
        const { data, error } = await loadIncidents();
        if (error) {
            console.error('Error loading incidents:', error);
        }
        else if (data) {
            setIncidents(data);
        }
        setLoading(false);
    };
    const loadStatistics = async () => {
        const { data, error } = await getIncidentStatistics();
        if (data) {
            setStatistics(data);
        }
    };
    // Get unique reporter names for filter
    const uniqueReporters = useMemo(() => {
        const reporters = Array.from(new Set(incidents.map(inc => inc.reported_by).filter(Boolean)));
        return reporters.sort();
    }, [incidents]);
    // Filter and sort incidents
    const filteredAndSortedIncidents = useMemo(() => {
        let filtered = incidents;
        // Search filter
        if (searchQuery) {
            const query = searchQuery.toLowerCase();
            filtered = filtered.filter(inc => inc.title.toLowerCase().includes(query) ||
                inc.description.toLowerCase().includes(query) ||
                inc.incident_code.toLowerCase().includes(query) ||
                inc.reported_by?.toLowerCase().includes(query));
        }
        // Status filter
        if (filterConfig.status !== 'all') {
            filtered = filtered.filter(inc => inc.status === filterConfig.status);
        }
        // Type filter
        if (filterConfig.type !== 'all') {
            filtered = filtered.filter(inc => inc.incident_type === filterConfig.type);
        }
        // Severity filter
        if (filterConfig.severity !== 'all') {
            filtered = filtered.filter(inc => inc.severity === filterConfig.severity);
        }
        // Reported By filter
        if (filterConfig.reportedBy !== 'all') {
            filtered = filtered.filter(inc => inc.reported_by === filterConfig.reportedBy);
        }
        // Linked risks filter
        if (filterConfig.hasLinkedRisks === true) {
            filtered = filtered.filter(inc => inc.linked_risk_codes && inc.linked_risk_codes.length > 0);
        }
        else if (filterConfig.hasLinkedRisks === false) {
            filtered = filtered.filter(inc => !inc.linked_risk_codes || inc.linked_risk_codes.length === 0);
        }
        // Date range filter
        if (filterConfig.dateFrom) {
            filtered = filtered.filter(inc => new Date(inc.incident_date) >= new Date(filterConfig.dateFrom));
        }
        if (filterConfig.dateTo) {
            filtered = filtered.filter(inc => new Date(inc.incident_date) <= new Date(filterConfig.dateTo));
        }
        // Sort
        const sorted = [...filtered].sort((a, b) => {
            const aVal = a[sortConfig.key];
            const bVal = b[sortConfig.key];
            if (sortConfig.key === 'severity') {
                return sortConfig.direction === 'asc' ? a.severity - b.severity : b.severity - a.severity;
            }
            if (typeof aVal === 'string' && typeof bVal === 'string') {
                return sortConfig.direction === 'asc'
                    ? aVal.localeCompare(bVal)
                    : bVal.localeCompare(aVal);
            }
            if (typeof aVal === 'number' && typeof bVal === 'number') {
                return sortConfig.direction === 'asc' ? aVal - bVal : bVal - aVal;
            }
            return 0;
        });
        return sorted;
    }, [incidents, searchQuery, filterConfig, sortConfig]);
    // Handle incident created/updated
    const handleIncidentSaved = () => {
        setShowCreateDialog(false);
        setSelectedIncident(null);
        loadIncidentsData();
        loadStatistics();
    };
    // Export to CSV
    const handleExport = () => {
        const headers = ['Code', 'Title', 'Reported By', 'Date', 'Type', 'Severity', 'Status', 'Financial Impact', 'Linked Risks'];
        const rows = filteredAndSortedIncidents.map(inc => [
            inc.incident_code,
            inc.title,
            inc.reported_by,
            formatDate(inc.incident_date),
            inc.incident_type,
            inc.severity.toString(),
            inc.status,
            inc.financial_impact ? formatCurrency(inc.financial_impact) : 'N/A',
            inc.linked_risk_codes.join(', ') || 'None',
        ]);
        const csvContent = [headers, ...rows].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `incidents-${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
    };
    if (loading) {
        return (_jsx("div", { className: "flex items-center justify-center h-64", children: _jsxs("div", { className: "text-center", children: [_jsx("div", { className: "animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4" }), _jsx("p", { className: "text-gray-600", children: "Loading incidents..." })] }) }));
    }
    return (_jsxs("div", { className: "space-y-6", children: [statistics && (_jsxs("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4", children: [_jsx(Card, { children: _jsx(CardContent, { className: "pt-6", children: _jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm font-medium text-gray-600", children: "Total Incidents" }), _jsx("p", { className: "text-3xl font-bold text-gray-900", children: statistics.total })] }), _jsx(AlertTriangle, { className: "h-10 w-10 text-yellow-500" })] }) }) }), _jsx(Card, { children: _jsx(CardContent, { className: "pt-6", children: _jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm font-medium text-gray-600", children: "Open/In Progress" }), _jsx("p", { className: "text-3xl font-bold text-blue-600", children: (statistics.by_status['Reported'] || 0) + (statistics.by_status['Under Investigation'] || 0) })] }), _jsx(Clock, { className: "h-10 w-10 text-blue-500" })] }) }) }), _jsx(Card, { children: _jsx(CardContent, { className: "pt-6", children: _jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm font-medium text-gray-600", children: "High Severity" }), _jsx("p", { className: "text-3xl font-bold text-red-600", children: (statistics.by_severity[5] || 0) + (statistics.by_severity[4] || 0) })] }), _jsx(TrendingUp, { className: "h-10 w-10 text-red-500" })] }) }) }), _jsx(Card, { children: _jsx(CardContent, { className: "pt-6", children: _jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { children: [_jsx("p", { className: "text-sm font-medium text-gray-600", children: "Financial Impact" }), _jsx("p", { className: "text-2xl font-bold text-green-600", children: formatCurrency(statistics.total_financial_impact) })] }), _jsx(DollarSign, { className: "h-10 w-10 text-green-500" })] }) }) })] })), _jsxs(Card, { children: [_jsx(CardHeader, { children: _jsxs("div", { className: "flex items-center justify-between", children: [_jsxs(CardTitle, { className: "flex items-center gap-2", children: [_jsx(AlertTriangle, { className: "h-5 w-5" }), "Incidents Log"] }), _jsxs("div", { className: "flex gap-2", children: [_jsxs(Button, { onClick: handleExport, variant: "outline", size: "sm", children: [_jsx(Download, { className: "mr-2 h-4 w-4" }), "Export"] }), _jsxs(Dialog, { open: showCreateDialog, onOpenChange: setShowCreateDialog, children: [_jsx(DialogTrigger, { asChild: true, children: _jsxs(Button, { size: "sm", children: [_jsx(Plus, { className: "mr-2 h-4 w-4" }), "New Incident"] }) }), _jsxs(DialogContent, { className: "max-w-4xl max-h-[90vh] overflow-y-auto", children: [_jsx(DialogHeader, { children: _jsx(DialogTitle, { children: "Report New Incident" }) }), _jsx(IncidentForm, { onSaved: handleIncidentSaved, onCancel: () => setShowCreateDialog(false) })] })] })] })] }) }), _jsxs(CardContent, { className: "space-y-4", children: [_jsxs("div", { className: "flex flex-wrap gap-4", children: [_jsx("div", { className: "flex-1 min-w-[200px]", children: _jsxs("div", { className: "relative", children: [_jsx(Search, { className: "absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" }), _jsx(Input, { placeholder: "Search incidents...", value: searchQuery, onChange: e => setSearchQuery(e.target.value), className: "pl-10" })] }) }), _jsxs(Select, { value: filterConfig.status, onValueChange: v => setFilterConfig({ ...filterConfig, status: v }), children: [_jsx(SelectTrigger, { className: "w-40", children: _jsx(SelectValue, { placeholder: "Status" }) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "all", children: "All Status" }), _jsx(SelectItem, { value: "Reported", children: "Reported" }), _jsx(SelectItem, { value: "Under Investigation", children: "Investigating" }), _jsx(SelectItem, { value: "Resolved", children: "Resolved" }), _jsx(SelectItem, { value: "Closed", children: "Closed" })] })] }), _jsxs(Select, { value: filterConfig.type, onValueChange: v => setFilterConfig({ ...filterConfig, type: v }), children: [_jsx(SelectTrigger, { className: "w-40", children: _jsx(SelectValue, { placeholder: "Type" }) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "all", children: "All Types" }), _jsx(SelectItem, { value: "Loss Event", children: "Loss Event" }), _jsx(SelectItem, { value: "Near Miss", children: "Near Miss" }), _jsx(SelectItem, { value: "Control Failure", children: "Control Failure" }), _jsx(SelectItem, { value: "Breach", children: "Breach" }), _jsx(SelectItem, { value: "Other", children: "Other" })] })] }), _jsxs(Select, { value: filterConfig.severity === 'all' ? 'all' : filterConfig.severity.toString(), onValueChange: v => setFilterConfig({ ...filterConfig, severity: v === 'all' ? 'all' : parseInt(v) }), children: [_jsx(SelectTrigger, { className: "w-40", children: _jsx(SelectValue, { placeholder: "Severity" }) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "all", children: "All Severity" }), _jsx(SelectItem, { value: "5", children: "Critical (5)" }), _jsx(SelectItem, { value: "4", children: "High (4)" }), _jsx(SelectItem, { value: "3", children: "Medium (3)" }), _jsx(SelectItem, { value: "2", children: "Low (2)" }), _jsx(SelectItem, { value: "1", children: "Minimal (1)" })] })] }), _jsxs(Select, { value: filterConfig.reportedBy, onValueChange: v => setFilterConfig({ ...filterConfig, reportedBy: v }), children: [_jsx(SelectTrigger, { className: "w-48", children: _jsx(SelectValue, { placeholder: "Reported By" }) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "all", children: "All Reporters" }), uniqueReporters.map(reporter => (_jsx(SelectItem, { value: reporter, children: reporter }, reporter)))] })] })] }), _jsxs("div", { className: "flex items-center justify-between text-sm text-gray-600", children: [_jsxs("span", { children: ["Showing ", filteredAndSortedIncidents.length, " of ", incidents.length, " incidents"] }), (searchQuery || filterConfig.status !== 'all' || filterConfig.type !== 'all' || filterConfig.severity !== 'all' || filterConfig.reportedBy !== 'all') && (_jsx(Button, { variant: "ghost", size: "sm", onClick: () => {
                                            setSearchQuery('');
                                            setFilterConfig({ status: 'all', type: 'all', severity: 'all', hasLinkedRisks: 'all', reportedBy: 'all' });
                                        }, children: "Clear Filters" }))] }), _jsx("div", { className: "border rounded-lg overflow-hidden", children: _jsx("div", { className: "overflow-x-auto", children: _jsxs("table", { className: "w-full", children: [_jsx("thead", { className: "bg-gray-50 border-b", children: _jsxs("tr", { children: [_jsx("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Code" }), _jsx("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Title" }), _jsx("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Reported By" }), _jsx("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Date" }), _jsx("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Type" }), _jsx("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Severity" }), _jsx("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Status" }), _jsx("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Impact" }), _jsx("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Linked Risks" })] }) }), _jsx("tbody", { className: "bg-white divide-y divide-gray-200", children: filteredAndSortedIncidents.length === 0 ? (_jsx("tr", { children: _jsx("td", { colSpan: 9, className: "px-4 py-8 text-center text-gray-500", children: incidents.length === 0 ? (_jsxs("div", { className: "space-y-2", children: [_jsx(AlertTriangle, { className: "h-12 w-12 text-gray-300 mx-auto" }), _jsx("p", { className: "font-medium", children: "No incidents reported yet" }), _jsx("p", { className: "text-sm", children: "Click \"New Incident\" to report your first incident" })] })) : ('No incidents match your filters') }) })) : (filteredAndSortedIncidents.map(incident => (_jsxs("tr", { className: "hover:bg-gray-50 cursor-pointer transition-colors", onClick: () => setSelectedIncident(incident), children: [_jsx("td", { className: "px-4 py-3 whitespace-nowrap", children: _jsx("span", { className: "text-sm font-medium text-blue-600", children: incident.incident_code }) }), _jsxs("td", { className: "px-4 py-3", children: [_jsx("div", { className: "text-sm font-medium text-gray-900 truncate max-w-xs", children: incident.title }), incident.department && (_jsx("div", { className: "text-xs text-gray-500", children: incident.department }))] }), _jsx("td", { className: "px-4 py-3 whitespace-nowrap", children: _jsx("div", { className: "text-sm text-gray-900", children: incident.reported_by }) }), _jsx("td", { className: "px-4 py-3 whitespace-nowrap text-sm text-gray-500", children: formatDate(incident.incident_date) }), _jsx("td", { className: "px-4 py-3 whitespace-nowrap", children: _jsx("span", { className: "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800", children: incident.incident_type }) }), _jsx("td", { className: "px-4 py-3 whitespace-nowrap", children: _jsx("span", { className: `inline-flex items-center px-2 py-1 rounded-full text-xs font-bold ${getSeverityColor(incident.severity)}`, children: incident.severity }) }), _jsx("td", { className: "px-4 py-3 whitespace-nowrap", children: _jsxs("div", { className: "flex items-center gap-1", children: [getStatusIcon(incident.status), _jsx("span", { className: "text-sm text-gray-700", children: incident.status })] }) }), _jsx("td", { className: "px-4 py-3 whitespace-nowrap text-sm text-gray-700", children: incident.financial_impact ? formatCurrency(incident.financial_impact) : '-' }), _jsx("td", { className: "px-4 py-3 whitespace-nowrap", children: incident.linked_risk_codes && incident.linked_risk_codes.length > 0 ? (_jsxs("div", { className: "flex items-center gap-1 text-sm", children: [_jsx(LinkIcon, { className: "h-3 w-3 text-blue-500" }), _jsx("span", { className: "text-blue-600 font-medium", children: incident.linked_risk_codes.length })] })) : (_jsx("span", { className: "text-gray-400 text-sm", children: "-" })) })] }, incident.id)))) })] }) }) })] })] }), selectedIncident && (_jsx(IncidentDetailDialog, { incident: selectedIncident, open: !!selectedIncident, onClose: () => setSelectedIncident(null), onUpdate: loadIncidentsData, onRisksUpdate: onRisksUpdate, isAdmin: isAdmin }))] }));
}
