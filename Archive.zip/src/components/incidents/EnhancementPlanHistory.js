import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// src/components/incidents/EnhancementPlanHistory.tsx
// Shows saved Control Enhancement Plans for an incident
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Loader2, FileText, CheckCircle2, XCircle, Clock, ChevronRight } from 'lucide-react';
import { loadEnhancementPlans, } from '../../lib/controlEnhancements';
import { format } from 'date-fns';
export function EnhancementPlanHistory({ incidentId, onSelectPlan }) {
    const [plans, setPlans] = useState([]);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        loadPlans();
    }, [incidentId]);
    const loadPlans = async () => {
        setLoading(true);
        const { data, error } = await loadEnhancementPlans(incidentId);
        if (!error && data) {
            setPlans(data);
        }
        else {
            console.error('Error loading enhancement plans:', error);
        }
        setLoading(false);
    };
    const getStatusBadge = (status) => {
        switch (status) {
            case 'pending':
                return (_jsxs(Badge, { variant: "outline", className: "bg-yellow-50 text-yellow-700 border-yellow-300", children: [_jsx(Clock, { className: "h-3 w-3 mr-1" }), "Pending Review"] }));
            case 'partially_accepted':
                return (_jsxs(Badge, { variant: "outline", className: "bg-blue-50 text-blue-700 border-blue-300", children: [_jsx(CheckCircle2, { className: "h-3 w-3 mr-1" }), "Partially Accepted"] }));
            case 'fully_accepted':
                return (_jsxs(Badge, { variant: "outline", className: "bg-green-50 text-green-700 border-green-300", children: [_jsx(CheckCircle2, { className: "h-3 w-3 mr-1" }), "Fully Accepted"] }));
            case 'rejected':
                return (_jsxs(Badge, { variant: "outline", className: "bg-red-50 text-red-700 border-red-300", children: [_jsx(XCircle, { className: "h-3 w-3 mr-1" }), "Rejected"] }));
            default:
                return _jsx(Badge, { variant: "outline", children: status });
        }
    };
    const getRecommendationStats = (plan) => {
        const accepted = plan.recommendations.filter(r => r.status === 'accepted').length;
        const rejected = plan.recommendations.filter(r => r.status === 'rejected').length;
        const implemented = plan.recommendations.filter(r => r.status === 'implemented').length;
        const pending = plan.recommendations.filter(r => r.status === 'pending').length;
        const total = plan.recommendations.length;
        return { accepted, rejected, implemented, pending, total };
    };
    if (loading) {
        return (_jsxs("div", { className: "flex items-center justify-center py-8", children: [_jsx(Loader2, { className: "h-6 w-6 animate-spin text-gray-400" }), _jsx("span", { className: "ml-2 text-sm text-gray-500", children: "Loading assessment history..." })] }));
    }
    if (plans.length === 0) {
        return (_jsxs("div", { className: "text-center py-8", children: [_jsx(FileText, { className: "h-12 w-12 text-gray-300 mx-auto mb-3" }), _jsx("p", { className: "text-sm text-gray-500", children: "No saved control assessments yet" }), _jsx("p", { className: "text-xs text-gray-400 mt-1", children: "Run the AI Control Assessment and save it to see history here" })] }));
    }
    return (_jsxs("div", { className: "space-y-3", children: [_jsx("div", { className: "flex items-center justify-between mb-4", children: _jsxs("h4", { className: "text-sm font-medium text-gray-700", children: ["Saved Assessments (", plans.length, ")"] }) }), plans.map(plan => {
                const stats = getRecommendationStats(plan);
                return (_jsxs(Card, { className: "hover:shadow-md transition-shadow cursor-pointer", onClick: () => onSelectPlan?.(plan), children: [_jsx(CardHeader, { className: "pb-3", children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { className: "flex-1", children: [_jsxs(CardTitle, { className: "text-sm font-medium text-gray-900", children: ["Assessment from ", format(new Date(plan.assessment_date), 'MMM d, yyyy h:mm a')] }), _jsxs("p", { className: "text-xs text-gray-500 mt-1", children: [stats.total, " recommendation", stats.total !== 1 ? 's' : ''] })] }), _jsxs("div", { className: "flex items-center gap-2", children: [getStatusBadge(plan.status), _jsx(ChevronRight, { className: "h-4 w-4 text-gray-400" })] })] }) }), _jsxs(CardContent, { className: "pt-0", children: [_jsxs("div", { className: "mb-3", children: [_jsxs("div", { className: "flex items-center justify-between text-xs mb-1", children: [_jsx("span", { className: "text-gray-600", children: "Overall Adequacy" }), _jsxs("span", { className: "font-medium text-gray-900", children: [plan.overall_adequacy_score, "/10"] })] }), _jsx("div", { className: "h-2 bg-gray-100 rounded-full overflow-hidden", children: _jsx("div", { className: `h-full rounded-full transition-all ${plan.overall_adequacy_score >= 7
                                                    ? 'bg-green-500'
                                                    : plan.overall_adequacy_score >= 4
                                                        ? 'bg-yellow-500'
                                                        : 'bg-red-500'}`, style: { width: `${(plan.overall_adequacy_score / 10) * 100}%` } }) })] }), _jsxs("div", { className: "flex items-center gap-3 text-xs", children: [stats.accepted > 0 && (_jsxs("div", { className: "flex items-center text-green-600", children: [_jsx(CheckCircle2, { className: "h-3 w-3 mr-1" }), stats.accepted, " accepted"] })), stats.implemented > 0 && (_jsxs("div", { className: "flex items-center text-blue-600", children: [_jsx(CheckCircle2, { className: "h-3 w-3 mr-1" }), stats.implemented, " implemented"] })), stats.pending > 0 && (_jsxs("div", { className: "flex items-center text-yellow-600", children: [_jsx(Clock, { className: "h-3 w-3 mr-1" }), stats.pending, " pending"] })), stats.rejected > 0 && (_jsxs("div", { className: "flex items-center text-red-600", children: [_jsx(XCircle, { className: "h-3 w-3 mr-1" }), stats.rejected, " rejected"] }))] }), plan.linked_risks_snapshot.length > 0 && (_jsx("div", { className: "mt-3 pt-3 border-t", children: _jsxs("p", { className: "text-xs text-gray-500", children: ["Analyzed against ", plan.linked_risks_snapshot.length, " risk", plan.linked_risks_snapshot.length !== 1 ? 's' : ''] }) }))] })] }, plan.id));
            })] }));
}
