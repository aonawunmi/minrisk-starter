import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// src/components/incidents/IncidentDetailDialog.tsx
// Detail view and edit dialog for incidents with risk linking
import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Edit, Link as LinkIcon, Unlink, AlertTriangle, CheckCircle, Clock, XCircle, DollarSign, Calendar, User, Building, FileText, Sparkles, Search, Loader2, Plus, Trash2, Save, History, } from 'lucide-react';
import { linkIncidentToRisks, unlinkIncidentFromRisk, deleteIncident } from '@/lib/incidents';
import { loadRisks } from '@/lib/database';
import { suggestRisksForIncident, assessControlAdequacy } from '@/lib/ai';
import { IncidentForm } from './IncidentForm';
import { EnhancementPlanHistory } from './EnhancementPlanHistory';
import { EnhancementPlanReviewDialog } from './EnhancementPlanReviewDialog';
import { saveEnhancementPlan } from '@/lib/controlEnhancements';
// =====================================================
// HELPER FUNCTIONS
// =====================================================
const getSeverityBadge = (severity) => {
    const colors = {
        5: 'bg-red-600 text-white',
        4: 'bg-orange-500 text-white',
        3: 'bg-yellow-400 text-gray-900',
        2: 'bg-blue-400 text-white',
        1: 'bg-green-400 text-white',
    };
    return colors[severity] || 'bg-gray-400 text-white';
};
const getStatusIcon = (status) => {
    switch (status) {
        case 'Reported': return _jsx(AlertTriangle, { className: "h-4 w-4 text-yellow-600" });
        case 'Under Investigation': return _jsx(Clock, { className: "h-4 w-4 text-blue-600" });
        case 'Resolved': return _jsx(CheckCircle, { className: "h-4 w-4 text-green-600" });
        case 'Closed': return _jsx(XCircle, { className: "h-4 w-4 text-gray-600" });
        default: return null;
    }
};
const formatCurrency = (amount) => {
    if (!amount)
        return 'Not specified';
    return new Intl.NumberFormat('en-NG', {
        style: 'currency',
        currency: 'NGN',
        minimumFractionDigits: 0,
    }).format(amount);
};
const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
    });
};
// =====================================================
// MAIN COMPONENT
// =====================================================
export function IncidentDetailDialog({ incident, open, onClose, onUpdate, onRisksUpdate, isAdmin = false }) {
    const [isEditing, setIsEditing] = useState(false);
    const [activeTab, setActiveTab] = useState('details');
    const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);
    // Risk linking state
    const [allRisks, setAllRisks] = useState([]);
    const [linkedRisks, setLinkedRisks] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [isLinking, setIsLinking] = useState(false);
    const [linkingRiskCode, setLinkingRiskCode] = useState(null);
    // AI suggestion state
    const [aiSuggestions, setAiSuggestions] = useState([]);
    const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);
    const [selectedSuggestions, setSelectedSuggestions] = useState(new Set());
    // AI control assessment state
    const [controlAssessment, setControlAssessment] = useState(null);
    const [isLoadingAssessment, setIsLoadingAssessment] = useState(false);
    // Enhancement plan state
    const [selectedPlan, setSelectedPlan] = useState(null);
    const [showPlanReview, setShowPlanReview] = useState(false);
    const [isSavingPlan, setIsSavingPlan] = useState(false);
    const [planHistoryKey, setPlanHistoryKey] = useState(0); // For refreshing history
    // Load risks
    useEffect(() => {
        loadAllRisks();
    }, []);
    // Update linked risks when incident changes
    useEffect(() => {
        if (allRisks.length > 0 && incident.linked_risk_codes) {
            const linked = allRisks.filter(r => incident.linked_risk_codes.includes(r.risk_code));
            setLinkedRisks(linked);
        }
    }, [allRisks, incident.linked_risk_codes]);
    const loadAllRisks = async () => {
        const risks = await loadRisks();
        if (risks && risks.length > 0) {
            setAllRisks(risks);
        }
    };
    // Handle delete incident
    const handleDelete = async () => {
        setIsDeleting(true);
        const { success, error } = await deleteIncident(incident.id);
        if (success) {
            onClose();
            onUpdate();
            if (onRisksUpdate) {
                onRisksUpdate(); // Refresh Risk Register to update incident counts
            }
        }
        else {
            alert('Failed to delete incident. Please try again.');
            console.error(error);
            setIsDeleting(false);
            setShowDeleteConfirm(false);
        }
    };
    // Handle link risk
    const handleLinkRisk = async (riskCode) => {
        setLinkingRiskCode(riskCode);
        const { success, error } = await linkIncidentToRisks(incident.id, [riskCode]);
        if (success) {
            console.log('✅ Link successful, waiting 1 second for trigger to complete...');
            // Wait for database trigger to update incident counts
            await new Promise(resolve => setTimeout(resolve, 1000));
            console.log('🔄 Now refreshing data...');
            onUpdate(); // Refresh incidents
            if (onRisksUpdate) {
                onRisksUpdate(); // Refresh Risk Register
            }
        }
        else {
            alert('Failed to link risk. Please try again.');
            console.error(error);
        }
        setLinkingRiskCode(null);
    };
    // Handle unlink risk
    const handleUnlinkRisk = async (riskCode) => {
        setLinkingRiskCode(riskCode);
        const { success, error } = await unlinkIncidentFromRisk(incident.id, riskCode);
        if (success) {
            onUpdate(); // Refresh incidents
            if (onRisksUpdate) {
                onRisksUpdate(); // Refresh Risk Register
            }
        }
        else {
            alert('Failed to unlink risk. Please try again.');
            console.error(error);
        }
        setLinkingRiskCode(null);
    };
    // Get AI suggestions for risk linking
    const handleGetAISuggestions = async () => {
        setIsLoadingSuggestions(true);
        setSelectedSuggestions(new Set()); // Clear previous selections
        try {
            const suggestions = await suggestRisksForIncident({
                title: incident.title,
                description: incident.description,
                incident_type: incident.incident_type,
                severity: incident.severity,
                impact_description: incident.impact_description,
                division: incident.division,
                department: incident.department,
            }, allRisks.map(r => ({
                risk_code: r.risk_code,
                risk_title: r.risk_title,
                risk_description: r.risk_description,
                category: r.category,
                division: r.division,
                department: r.department,
            })));
            setAiSuggestions(suggestions);
        }
        catch (error) {
            alert(`Failed to get AI suggestions: ${error.message}`);
            console.error(error);
        }
        finally {
            setIsLoadingSuggestions(false);
        }
    };
    // Toggle suggestion selection
    const toggleSuggestionSelection = (riskCode) => {
        const newSelected = new Set(selectedSuggestions);
        if (newSelected.has(riskCode)) {
            newSelected.delete(riskCode);
        }
        else {
            newSelected.add(riskCode);
        }
        setSelectedSuggestions(newSelected);
    };
    // Link all selected suggestions
    const handleLinkSelectedSuggestions = async () => {
        if (selectedSuggestions.size === 0)
            return;
        setIsLinking(true);
        try {
            const riskCodesToLink = Array.from(selectedSuggestions);
            const { success, error } = await linkIncidentToRisks(incident.id, riskCodesToLink);
            if (success) {
                console.log('✅ Link successful, waiting 1 second for trigger to complete...');
                await new Promise(resolve => setTimeout(resolve, 1000));
                console.log('🔄 Now refreshing data...');
                onUpdate(); // Refresh incidents
                if (onRisksUpdate) {
                    onRisksUpdate(); // Refresh Risk Register
                }
                setSelectedSuggestions(new Set()); // Clear selections
            }
            else {
                alert('Failed to link risks. Please try again.');
                console.error(error);
            }
        }
        catch (error) {
            alert(`Failed to link risks: ${error.message}`);
            console.error(error);
        }
        finally {
            setIsLinking(false);
        }
    };
    // Get AI control adequacy assessment
    const handleGetControlAssessment = async () => {
        if (linkedRisks.length === 0) {
            alert('Please link at least one risk to this incident before assessing controls.');
            return;
        }
        setIsLoadingAssessment(true);
        try {
            const assessment = await assessControlAdequacy({
                title: incident.title,
                description: incident.description,
                incident_type: incident.incident_type,
                severity: incident.severity,
                impact_description: incident.impact_description,
                root_cause: incident.root_cause,
                corrective_actions: incident.corrective_actions,
            }, linkedRisks.map(r => ({
                risk_code: r.risk_code,
                risk_title: r.risk_title,
                risk_description: r.risk_description,
                category: r.category,
                controls: r.controls,
            })));
            setControlAssessment(assessment);
        }
        catch (error) {
            alert(`Failed to assess controls: ${error.message}`);
            console.error(error);
        }
        finally {
            setIsLoadingAssessment(false);
        }
    };
    // Save assessment as enhancement plan
    const handleSaveAssessment = async () => {
        if (!controlAssessment) {
            alert('No assessment to save. Please run the control assessment first.');
            return;
        }
        setIsSavingPlan(true);
        try {
            // Map the assessment to enhancement plan format
            // Convert adequacy_level to score: Adequate=8, Partially Adequate=5, Inadequate=3
            const adequacyScoreMap = { 'Adequate': 8, 'Partially Adequate': 5, 'Inadequate': 3 };
            const planData = {
                incident_id: incident.id,
                overall_adequacy_score: adequacyScoreMap[controlAssessment.adequacy_level] || 5,
                findings: [controlAssessment.overall_reasoning],
                recommendations: controlAssessment.control_improvements.map(imp => ({
                    type: 'improvement',
                    description: imp.reasoning,
                    priority: controlAssessment.priority.toLowerCase(),
                    risk_code: imp.risk_code,
                })),
                linked_risks_snapshot: linkedRisks.map(risk => ({
                    risk_code: risk.risk_code,
                    risk_title: risk.risk_title,
                    category: risk.category,
                    likelihood_inherent: risk.likelihood_inherent,
                    impact_inherent: risk.impact_inherent,
                })),
            };
            const { data, error } = await saveEnhancementPlan(planData);
            if (error || !data) {
                throw new Error(error || 'Failed to save plan');
            }
            alert('Assessment saved successfully! You can review it in the Enhancement Plans tab.');
            setPlanHistoryKey(prev => prev + 1); // Refresh history
            setActiveTab('plans'); // Switch to plans tab
        }
        catch (error) {
            alert(`Failed to save assessment: ${error.message}`);
            console.error(error);
        }
        finally {
            setIsSavingPlan(false);
        }
    };
    // Filter available risks (not already linked)
    const availableRisks = allRisks.filter(r => {
        const isNotLinked = !incident.linked_risk_codes.includes(r.risk_code);
        const matchesSearch = searchQuery === '' ||
            r.risk_code.toLowerCase().includes(searchQuery.toLowerCase()) ||
            r.risk_title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            r.category.toLowerCase().includes(searchQuery.toLowerCase());
        return isNotLinked && matchesSearch;
    });
    if (isEditing) {
        return (_jsx(Dialog, { open: open, onOpenChange: () => setIsEditing(false), children: _jsxs(DialogContent, { className: "max-w-4xl max-h-[90vh] overflow-y-auto", children: [_jsx(DialogHeader, { children: _jsx(DialogTitle, { children: "Edit Incident" }) }), _jsx(IncidentForm, { incident: incident, onSaved: () => {
                            setIsEditing(false);
                            onUpdate();
                        }, onCancel: () => setIsEditing(false) })] }) }));
    }
    return (_jsx(Dialog, { open: open, onOpenChange: onClose, children: _jsxs(DialogContent, { className: "max-w-5xl max-h-[90vh] overflow-hidden flex flex-col", children: [_jsx(DialogHeader, { className: "flex-shrink-0", children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { className: "space-y-1", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(DialogTitle, { children: incident.title }), _jsxs(Badge, { className: getSeverityBadge(incident.severity), children: ["Severity ", incident.severity] })] }), _jsxs("p", { className: "text-sm text-gray-500", children: ["Incident Code: ", incident.incident_code] })] }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsxs(Button, { variant: "outline", size: "sm", onClick: () => setIsEditing(true), children: [_jsx(Edit, { className: "h-4 w-4 mr-2" }), "Edit"] }), isAdmin && !showDeleteConfirm && (_jsxs(Button, { variant: "outline", size: "sm", onClick: () => setShowDeleteConfirm(true), className: "text-red-600 hover:bg-red-50 hover:text-red-700", children: [_jsx(Trash2, { className: "h-4 w-4 mr-2" }), "Delete"] })), isAdmin && showDeleteConfirm && (_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("span", { className: "text-sm text-red-600 font-medium", children: "Confirm delete?" }), _jsx(Button, { variant: "destructive", size: "sm", onClick: handleDelete, disabled: isDeleting, children: isDeleting ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 mr-2 animate-spin" }), "Deleting..."] })) : ('Yes, Delete') }), _jsx(Button, { variant: "outline", size: "sm", onClick: () => setShowDeleteConfirm(false), disabled: isDeleting, children: "Cancel" })] }))] })] }) }), _jsxs(Tabs, { value: activeTab, onValueChange: setActiveTab, className: "flex-1 overflow-hidden flex flex-col", children: [_jsxs(TabsList, { className: "flex-shrink-0", children: [_jsx(TabsTrigger, { value: "details", children: "Details" }), _jsxs(TabsTrigger, { value: "risks", children: ["Linked Risks (", linkedRisks.length, ")"] }), _jsxs(TabsTrigger, { value: "ai", children: [_jsx(Sparkles, { className: "h-4 w-4 mr-2" }), "Control Assessment"] }), _jsxs(TabsTrigger, { value: "plans", children: [_jsx(History, { className: "h-4 w-4 mr-2" }), "Enhancement Plans"] })] }), _jsxs(TabsContent, { value: "details", className: "flex-1 overflow-y-auto mt-4 space-y-6", children: [_jsxs("div", { className: "grid grid-cols-2 gap-4", children: [_jsxs("div", { className: "space-y-2", children: [_jsx("p", { className: "text-sm font-medium text-gray-500", children: "Status" }), _jsxs("div", { className: "flex items-center gap-2", children: [getStatusIcon(incident.status), _jsx("span", { className: "font-medium", children: incident.status })] })] }), _jsxs("div", { className: "space-y-2", children: [_jsx("p", { className: "text-sm font-medium text-gray-500", children: "Incident Type" }), _jsx(Badge, { variant: "outline", children: incident.incident_type })] })] }), _jsxs("div", { className: "space-y-2", children: [_jsxs("p", { className: "text-sm font-medium text-gray-500 flex items-center gap-2", children: [_jsx(FileText, { className: "h-4 w-4" }), "Description"] }), _jsx("p", { className: "text-sm text-gray-700 whitespace-pre-wrap bg-gray-50 p-3 rounded-lg", children: incident.description })] }), _jsxs("div", { className: "grid grid-cols-2 gap-4", children: [_jsxs("div", { className: "space-y-2", children: [_jsxs("p", { className: "text-sm font-medium text-gray-500 flex items-center gap-2", children: [_jsx(Calendar, { className: "h-4 w-4" }), "Incident Date"] }), _jsx("p", { className: "text-sm", children: formatDate(incident.incident_date) })] }), _jsxs("div", { className: "space-y-2", children: [_jsxs("p", { className: "text-sm font-medium text-gray-500 flex items-center gap-2", children: [_jsx(User, { className: "h-4 w-4" }), "Reported By"] }), _jsx("p", { className: "text-sm", children: incident.reported_by }), incident.reporter_email && (_jsx("p", { className: "text-xs text-gray-500", children: incident.reporter_email }))] })] }), (incident.division || incident.department) && (_jsxs("div", { className: "grid grid-cols-2 gap-4", children: [incident.division && (_jsxs("div", { className: "space-y-2", children: [_jsxs("p", { className: "text-sm font-medium text-gray-500 flex items-center gap-2", children: [_jsx(Building, { className: "h-4 w-4" }), "Division"] }), _jsx("p", { className: "text-sm", children: incident.division })] })), incident.department && (_jsxs("div", { className: "space-y-2", children: [_jsx("p", { className: "text-sm font-medium text-gray-500", children: "Department" }), _jsx("p", { className: "text-sm", children: incident.department })] }))] })), incident.financial_impact && (_jsxs("div", { className: "space-y-2", children: [_jsxs("p", { className: "text-sm font-medium text-gray-500 flex items-center gap-2", children: [_jsx(DollarSign, { className: "h-4 w-4" }), "Financial Impact"] }), _jsx("p", { className: "text-lg font-semibold text-red-600", children: formatCurrency(incident.financial_impact) })] })), incident.impact_description && (_jsxs("div", { className: "space-y-2", children: [_jsx("p", { className: "text-sm font-medium text-gray-500", children: "Impact Description" }), _jsx("p", { className: "text-sm text-gray-700 whitespace-pre-wrap bg-gray-50 p-3 rounded-lg", children: incident.impact_description })] })), incident.root_cause && (_jsxs("div", { className: "space-y-2", children: [_jsx("p", { className: "text-sm font-medium text-gray-500", children: "Root Cause Analysis" }), _jsx("p", { className: "text-sm text-gray-700 whitespace-pre-wrap bg-gray-50 p-3 rounded-lg", children: incident.root_cause })] })), incident.corrective_actions && (_jsxs("div", { className: "space-y-2", children: [_jsx("p", { className: "text-sm font-medium text-gray-500", children: "Corrective Actions" }), _jsx("p", { className: "text-sm text-gray-700 whitespace-pre-wrap bg-gray-50 p-3 rounded-lg", children: incident.corrective_actions })] })), _jsxs("div", { className: "border-t pt-4 text-xs text-gray-500 space-y-1", children: [_jsxs("p", { children: ["Created: ", formatDate(incident.created_at)] }), _jsxs("p", { children: ["Last Updated: ", formatDate(incident.updated_at)] }), incident.resolved_at && _jsxs("p", { children: ["Resolved: ", formatDate(incident.resolved_at)] }), incident.closed_at && _jsxs("p", { children: ["Closed: ", formatDate(incident.closed_at)] })] })] }), _jsxs(TabsContent, { value: "risks", className: "flex-1 overflow-y-auto mt-4 space-y-4", children: [_jsxs("div", { children: [_jsxs("h4", { className: "text-sm font-semibold text-gray-700 mb-3", children: ["Linked Risks (", linkedRisks.length, ")"] }), linkedRisks.length === 0 ? (_jsxs("div", { className: "text-center py-8 text-gray-500", children: [_jsx(LinkIcon, { className: "h-12 w-12 mx-auto mb-2 text-gray-300" }), _jsx("p", { className: "text-sm", children: "No risks linked to this incident yet" }), _jsx("p", { className: "text-xs", children: "Link risks below to track the relationship" })] })) : (_jsx("div", { className: "space-y-2", children: linkedRisks.map(risk => (_jsxs("div", { className: "flex items-start justify-between gap-3 p-3 bg-blue-50 border border-blue-200 rounded-lg", children: [_jsxs("div", { className: "flex-1 min-w-0", children: [_jsxs("p", { className: "font-medium text-sm", children: ["[", risk.risk_code, "] ", risk.risk_title] }), risk.risk_description && (_jsx("p", { className: "text-xs text-gray-700 mt-1 line-clamp-2", children: risk.risk_description })), _jsxs("p", { className: "text-xs text-gray-600 mt-1", children: [risk.category, " \u2022 ", risk.department] })] }), _jsx(Button, { variant: "ghost", size: "sm", onClick: () => handleUnlinkRisk(risk.risk_code), disabled: linkingRiskCode === risk.risk_code, className: "flex-shrink-0", children: linkingRiskCode === risk.risk_code ? (_jsx(Loader2, { className: "h-4 w-4 animate-spin" })) : (_jsx(Unlink, { className: "h-4 w-4 text-red-500" })) })] }, risk.risk_code))) }))] }), _jsxs("div", { className: "border-t pt-4", children: [_jsxs("div", { className: "flex items-center justify-between mb-3", children: [_jsxs("h4", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: [_jsx(Sparkles, { className: "h-4 w-4 text-purple-600" }), "AI Risk Suggestions"] }), _jsxs("div", { className: "flex gap-2", children: [aiSuggestions.length > 0 && selectedSuggestions.size > 0 && (_jsx(Button, { variant: "default", size: "sm", onClick: handleLinkSelectedSuggestions, disabled: isLinking, className: "flex items-center gap-2 bg-purple-600 hover:bg-purple-700", children: isLinking ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 animate-spin" }), "Linking..."] })) : (_jsxs(_Fragment, { children: [_jsx(LinkIcon, { className: "h-4 w-4" }), "Link Selected (", selectedSuggestions.size, ")"] })) })), _jsx(Button, { variant: "outline", size: "sm", onClick: handleGetAISuggestions, disabled: isLoadingSuggestions || allRisks.length === 0, className: "flex items-center gap-2", children: isLoadingSuggestions ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 animate-spin" }), "Analyzing..."] })) : (_jsxs(_Fragment, { children: [_jsx(Sparkles, { className: "h-4 w-4" }), "Get Suggestions"] })) })] })] }), aiSuggestions.length > 0 && (_jsx("div", { className: "space-y-2 mb-4", children: aiSuggestions.map(suggestion => {
                                                const isAlreadyLinked = incident.linked_risk_codes.includes(suggestion.risk_code);
                                                const isSelected = selectedSuggestions.has(suggestion.risk_code);
                                                return (_jsx("div", { className: `p-3 rounded-lg border cursor-pointer transition-all ${isAlreadyLinked
                                                        ? 'bg-gray-100 border-gray-300'
                                                        : isSelected
                                                            ? 'bg-gradient-to-r from-purple-100 to-blue-100 border-purple-400 shadow-sm'
                                                            : 'bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200 hover:border-purple-300'}`, onClick: () => !isAlreadyLinked && toggleSuggestionSelection(suggestion.risk_code), children: _jsxs("div", { className: "flex items-start gap-3", children: [!isAlreadyLinked && (_jsx("input", { type: "checkbox", checked: isSelected, onChange: () => toggleSuggestionSelection(suggestion.risk_code), onClick: (e) => e.stopPropagation(), className: "mt-1 h-4 w-4 rounded border-gray-300 text-purple-600 focus:ring-purple-500" })), _jsxs("div", { className: "flex-1 min-w-0", children: [_jsxs("div", { className: "flex items-center gap-2 mb-1", children: [_jsxs("p", { className: "font-medium text-sm", children: ["[", suggestion.risk_code, "] ", suggestion.risk_title] }), _jsxs(Badge, { variant: "outline", className: `text-xs ${suggestion.confidence >= 0.9
                                                                                    ? 'bg-green-100 text-green-800 border-green-300'
                                                                                    : suggestion.confidence >= 0.75
                                                                                        ? 'bg-blue-100 text-blue-800 border-blue-300'
                                                                                        : 'bg-yellow-100 text-yellow-800 border-yellow-300'}`, children: [Math.round(suggestion.confidence * 100), "% match"] })] }), _jsx("p", { className: "text-xs text-gray-700 mb-2", children: suggestion.reasoning })] }), isAlreadyLinked && (_jsx(Badge, { variant: "outline", className: "bg-gray-200 text-gray-600 flex-shrink-0", children: "Already Linked" }))] }) }, suggestion.risk_code));
                                            }) })), aiSuggestions.length === 0 && !isLoadingSuggestions && (_jsx("p", { className: "text-xs text-gray-500 mb-4 p-3 bg-gray-50 rounded-lg border border-gray-200", children: "Click \"Get Suggestions\" to use AI to analyze this incident and recommend which risks should be linked." }))] }), _jsxs("div", { className: "border-t pt-4", children: [_jsx("h4", { className: "text-sm font-semibold text-gray-700 mb-3", children: "Or Search Manually" }), _jsxs("div", { className: "relative mb-3", children: [_jsx(Search, { className: "absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" }), _jsx(Input, { placeholder: "Search risks by code, title, or category...", value: searchQuery, onChange: e => setSearchQuery(e.target.value), className: "pl-10" })] }), _jsx("div", { className: "space-y-2 max-h-64 overflow-y-auto", children: availableRisks.length === 0 ? (_jsx("p", { className: "text-sm text-gray-500 text-center py-4", children: searchQuery ? 'No risks match your search' : 'All risks are already linked' })) : (availableRisks.map(risk => (_jsxs("div", { className: "flex items-start justify-between gap-3 p-3 bg-gray-50 border border-gray-200 rounded-lg hover:bg-gray-100 transition-colors", children: [_jsxs("div", { className: "flex-1 min-w-0", children: [_jsxs("p", { className: "font-medium text-sm", children: ["[", risk.risk_code, "] ", risk.risk_title] }), risk.risk_description && (_jsx("p", { className: "text-xs text-gray-700 mt-1 line-clamp-2", children: risk.risk_description })), _jsxs("p", { className: "text-xs text-gray-600 mt-1", children: [risk.category, " \u2022 ", risk.department] })] }), _jsx(Button, { variant: "outline", size: "sm", onClick: () => handleLinkRisk(risk.risk_code), disabled: linkingRiskCode === risk.risk_code, className: "flex-shrink-0", children: linkingRiskCode === risk.risk_code ? (_jsx(Loader2, { className: "h-4 w-4 animate-spin" })) : (_jsxs(_Fragment, { children: [_jsx(LinkIcon, { className: "h-4 w-4 mr-2" }), "Link"] })) })] }, risk.risk_code)))) })] })] }), _jsxs(TabsContent, { value: "ai", className: "flex-1 overflow-y-auto mt-4 space-y-4", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { children: [_jsxs("h4", { className: "text-sm font-semibold text-gray-900 flex items-center gap-2", children: [_jsx(Sparkles, { className: "h-5 w-5 text-purple-600" }), "AI Control Adequacy Assessment"] }), _jsx("p", { className: "text-xs text-gray-600 mt-1", children: "Analyze if existing controls were adequate to prevent this incident" })] }), _jsxs("div", { className: "flex gap-2", children: [_jsx(Button, { variant: "outline", size: "sm", onClick: handleGetControlAssessment, disabled: isLoadingAssessment || linkedRisks.length === 0, className: "flex items-center gap-2", children: isLoadingAssessment ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 animate-spin" }), "Analyzing..."] })) : (_jsxs(_Fragment, { children: [_jsx(Sparkles, { className: "h-4 w-4" }), "Assess Controls"] })) }), controlAssessment && (_jsx(Button, { size: "sm", onClick: handleSaveAssessment, disabled: isSavingPlan, className: "flex items-center gap-2", children: isSavingPlan ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 animate-spin" }), "Saving..."] })) : (_jsxs(_Fragment, { children: [_jsx(Save, { className: "h-4 w-4" }), "Save Assessment"] })) }))] })] }), linkedRisks.length === 0 && (_jsxs("div", { className: "text-center py-8 bg-gray-50 rounded-lg border border-gray-200", children: [_jsx(LinkIcon, { className: "h-12 w-12 mx-auto mb-2 text-gray-300" }), _jsx("p", { className: "text-sm text-gray-500", children: "No risks linked yet" }), _jsx("p", { className: "text-xs text-gray-400 mt-1", children: "Link risks to this incident first to assess control adequacy" })] })), controlAssessment && (_jsxs("div", { className: "space-y-4", children: [_jsxs("div", { className: `p-4 rounded-lg border-2 ${controlAssessment.adequacy_level === 'Adequate'
                                                ? 'bg-green-50 border-green-300'
                                                : controlAssessment.adequacy_level === 'Inadequate'
                                                    ? 'bg-red-50 border-red-300'
                                                    : 'bg-yellow-50 border-yellow-300'}`, children: [_jsxs("div", { className: "flex items-start justify-between mb-2", children: [_jsx("h5", { className: "font-semibold text-gray-900", children: "Overall Assessment" }), _jsxs("div", { className: "flex gap-2", children: [_jsx(Badge, { className: controlAssessment.adequacy_level === 'Adequate'
                                                                        ? 'bg-green-600'
                                                                        : controlAssessment.adequacy_level === 'Inadequate'
                                                                            ? 'bg-red-600'
                                                                            : 'bg-yellow-600', children: controlAssessment.adequacy_level }), _jsxs(Badge, { variant: "outline", className: controlAssessment.priority === 'High'
                                                                        ? 'border-red-500 text-red-700'
                                                                        : controlAssessment.priority === 'Medium'
                                                                            ? 'border-yellow-500 text-yellow-700'
                                                                            : 'border-blue-500 text-blue-700', children: [controlAssessment.priority, " Priority"] })] })] }), _jsx("p", { className: "text-sm text-gray-700", children: controlAssessment.overall_reasoning })] }), controlAssessment.control_improvements.length > 0 && (_jsxs("div", { children: [_jsxs("h5", { className: "font-semibold text-gray-900 mb-3 flex items-center gap-2", children: [_jsx(AlertTriangle, { className: "h-4 w-4 text-orange-600" }), "Recommended Control Improvements (", controlAssessment.control_improvements.length, ")"] }), _jsx("div", { className: "space-y-3", children: controlAssessment.control_improvements.map((improvement, idx) => (_jsxs("div", { className: "p-3 bg-white border border-gray-200 rounded-lg", children: [_jsx("div", { className: "flex items-start justify-between mb-2", children: _jsxs("div", { className: "flex-1", children: [_jsxs("p", { className: "text-sm font-medium text-gray-900", children: ["[", improvement.risk_code, "] ", improvement.risk_title] }), _jsx("p", { className: "text-xs text-gray-600 mt-1", children: improvement.control_description })] }) }), _jsxs("div", { className: "flex items-center gap-3 mt-2", children: [_jsx(Badge, { variant: "outline", className: "text-xs", children: improvement.dimension }), _jsxs("div", { className: "text-xs text-gray-600 flex items-center gap-2", children: [_jsxs("span", { className: "text-red-600 font-medium", children: ["Current: ", improvement.current_score] }), _jsx("span", { children: "\u2192" }), _jsxs("span", { className: "text-green-600 font-medium", children: ["Suggested: ", improvement.suggested_score] })] })] }), _jsx("p", { className: "text-xs text-gray-700 mt-2 italic", children: improvement.reasoning })] }, idx))) })] })), controlAssessment.new_control_suggestions.length > 0 && (_jsxs("div", { children: [_jsxs("h5", { className: "font-semibold text-gray-900 mb-3 flex items-center gap-2", children: [_jsx(Plus, { className: "h-4 w-4 text-green-600" }), "New Control Recommendations (", controlAssessment.new_control_suggestions.length, ")"] }), _jsx("div", { className: "space-y-3", children: controlAssessment.new_control_suggestions.map((suggestion, idx) => (_jsxs("div", { className: "p-3 bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 rounded-lg", children: [_jsx("div", { className: "flex items-start justify-between mb-2", children: _jsxs("div", { className: "flex-1", children: [_jsxs("p", { className: "text-sm font-medium text-gray-900", children: ["[", suggestion.risk_code, "] ", suggestion.risk_title] }), _jsx("p", { className: "text-sm text-gray-800 mt-1", children: suggestion.control_description })] }) }), _jsxs("div", { className: "flex items-center gap-2 mt-2", children: [_jsx(Badge, { variant: "outline", className: "text-xs bg-white", children: suggestion.control_type }), _jsxs(Badge, { variant: "outline", className: "text-xs bg-white", children: ["Targets: ", suggestion.target] })] }), _jsx("p", { className: "text-xs text-gray-700 mt-2 italic", children: suggestion.reasoning })] }, idx))) })] }))] })), !controlAssessment && linkedRisks.length > 0 && !isLoadingAssessment && (_jsxs("div", { className: "text-center py-8 bg-gray-50 rounded-lg border border-gray-200", children: [_jsx(Sparkles, { className: "h-12 w-12 mx-auto mb-2 text-gray-300" }), _jsx("p", { className: "text-sm text-gray-500", children: "Ready to assess controls" }), _jsx("p", { className: "text-xs text-gray-400 mt-1", children: "Click \"Assess Controls\" to analyze if existing controls were adequate" })] }))] }), _jsx(TabsContent, { value: "plans", className: "flex-1 overflow-y-auto mt-4", children: _jsx(EnhancementPlanHistory, { incidentId: incident.id, onSelectPlan: plan => {
                                    setSelectedPlan(plan);
                                    setShowPlanReview(true);
                                } }, planHistoryKey) })] }), _jsx(EnhancementPlanReviewDialog, { plan: selectedPlan, open: showPlanReview, onClose: () => {
                        setShowPlanReview(false);
                        setSelectedPlan(null);
                    }, onUpdate: () => {
                        setPlanHistoryKey(prev => prev + 1); // Refresh history
                    } })] }) }));
}
