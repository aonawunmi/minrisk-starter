import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// src/components/incidents/IncidentForm.tsx
// Form for creating/editing incidents
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertCircle, Loader2, Save, X } from 'lucide-react';
import { createIncident, updateIncident } from '@/lib/incidents';
import { loadConfig } from '@/lib/database';
// =====================================================
// HELPER FUNCTIONS
// =====================================================
const incidentTypes = ['Loss Event', 'Near Miss', 'Control Failure', 'Breach', 'Other'];
const incidentStatuses = ['Reported', 'Under Investigation', 'Resolved', 'Closed'];
const severityLevels = [
    { value: 5, label: 'Critical (5)', color: 'text-red-600' },
    { value: 4, label: 'High (4)', color: 'text-orange-600' },
    { value: 3, label: 'Medium (3)', color: 'text-yellow-600' },
    { value: 2, label: 'Low (2)', color: 'text-blue-600' },
    { value: 1, label: 'Minimal (1)', color: 'text-green-600' },
];
// =====================================================
// MAIN COMPONENT
// =====================================================
export function IncidentForm({ incident, onSaved, onCancel }) {
    const isEditing = !!incident;
    // State
    const [config, setConfig] = useState(null);
    const [loading, setLoading] = useState(false);
    const [errors, setErrors] = useState({});
    // Get current user email
    const [currentUserEmail, setCurrentUserEmail] = useState('');
    useEffect(() => {
        const loadUserAndConfig = async () => {
            // Load config for divisions/departments
            const configData = await loadConfig();
            if (configData) {
                setConfig(configData);
            }
            // Get current user email
            const { supabase } = await import('@/lib/supabase');
            const { data: { user } } = await supabase.auth.getUser();
            if (user?.email) {
                setCurrentUserEmail(user.email);
            }
        };
        loadUserAndConfig();
    }, []);
    // Form data with defaults
    const [formData, setFormData] = useState({
        title: incident?.title || '',
        description: incident?.description || '',
        incident_date: incident?.incident_date ? new Date(incident.incident_date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
        reported_by: incident?.reported_by || currentUserEmail || '',
        reporter_email: incident?.reporter_email || currentUserEmail || '',
        division: incident?.division || '',
        department: incident?.department || '',
        incident_type: incident?.incident_type || 'Other',
        severity: incident?.severity || 3,
        financial_impact: incident?.financial_impact ? incident.financial_impact.toString() : '',
        impact_description: incident?.impact_description || '',
        status: incident?.status || 'Reported',
        root_cause: incident?.root_cause || '',
        corrective_actions: incident?.corrective_actions || '',
    });
    // Update reported_by when currentUserEmail loads
    useEffect(() => {
        if (currentUserEmail && !isEditing) {
            setFormData(prev => ({
                ...prev,
                reported_by: prev.reported_by || currentUserEmail,
                reporter_email: prev.reporter_email || currentUserEmail,
            }));
        }
    }, [currentUserEmail, isEditing]);
    // Validation
    const validateForm = () => {
        const newErrors = {};
        if (!formData.title.trim()) {
            newErrors.title = 'Title is required';
        }
        if (!formData.description.trim()) {
            newErrors.description = 'Description is required';
        }
        if (!formData.incident_date) {
            newErrors.incident_date = 'Incident date is required';
        }
        if (!formData.reported_by.trim()) {
            newErrors.reported_by = 'Reporter name is required';
        }
        if (!formData.incident_type) {
            newErrors.incident_type = 'Incident type is required';
        }
        if (formData.financial_impact && isNaN(parseFloat(formData.financial_impact))) {
            newErrors.financial_impact = 'Must be a valid number';
        }
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };
    // Handle submit
    const handleSubmit = async () => {
        if (!validateForm()) {
            return;
        }
        setLoading(true);
        try {
            const incidentData = {
                title: formData.title.trim(),
                description: formData.description.trim(),
                incident_date: new Date(formData.incident_date).toISOString(),
                reported_by: formData.reported_by.trim(),
                reporter_email: formData.reporter_email.trim() || undefined,
                division: formData.division || undefined,
                department: formData.department || undefined,
                incident_type: formData.incident_type,
                severity: formData.severity,
                financial_impact: formData.financial_impact ? parseFloat(formData.financial_impact) : undefined,
                impact_description: formData.impact_description.trim() || undefined,
                status: formData.status,
                root_cause: formData.root_cause.trim() || undefined,
                corrective_actions: formData.corrective_actions.trim() || undefined,
                linked_risk_codes: incident?.linked_risk_codes || [],
                ai_suggested_risks: incident?.ai_suggested_risks || [],
                ai_control_recommendations: incident?.ai_control_recommendations || {},
                manual_risk_links: incident?.manual_risk_links || [],
            };
            if (isEditing && incident) {
                const { data, error } = await updateIncident(incident.id, incidentData);
                if (error) {
                    console.error('Error updating incident:', error);
                    alert('Failed to update incident. Please try again.');
                    return;
                }
            }
            else {
                const { data, error } = await createIncident(incidentData);
                if (error) {
                    console.error('Error creating incident:', error);
                    alert('Failed to create incident. Please try again.');
                    return;
                }
            }
            onSaved();
        }
        catch (error) {
            console.error('Error saving incident:', error);
            alert('An unexpected error occurred. Please try again.');
        }
        finally {
            setLoading(false);
        }
    };
    // Handle field change
    const handleChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
        // Clear error for this field
        if (errors[field]) {
            setErrors(prev => {
                const newErrors = { ...prev };
                delete newErrors[field];
                return newErrors;
            });
        }
    };
    if (!config) {
        return (_jsx("div", { className: "flex items-center justify-center p-8", children: _jsx(Loader2, { className: "h-8 w-8 animate-spin text-blue-500" }) }));
    }
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx("h3", { className: "text-lg font-semibold text-gray-900", children: isEditing ? 'Edit Incident' : 'Report New Incident' }), isEditing && incident && (_jsxs("span", { className: "text-sm text-gray-500", children: ["Code: ", incident.incident_code] }))] }), _jsxs("div", { className: "space-y-4 max-h-[60vh] overflow-y-auto pr-2", children: [_jsxs("div", { children: [_jsx(Label, { htmlFor: "title", className: "required", children: "Incident Title" }), _jsx(Input, { id: "title", value: formData.title, onChange: e => handleChange('title', e.target.value), placeholder: "Brief description of the incident", className: errors.title ? 'border-red-500' : '' }), errors.title && (_jsxs("p", { className: "text-sm text-red-600 mt-1 flex items-center gap-1", children: [_jsx(AlertCircle, { className: "h-3 w-3" }), errors.title] }))] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "description", className: "required", children: "Description" }), _jsx(Textarea, { id: "description", value: formData.description, onChange: e => handleChange('description', e.target.value), placeholder: "Detailed description of what happened, when, where, and who was involved", rows: 4, className: errors.description ? 'border-red-500' : '' }), errors.description && (_jsxs("p", { className: "text-sm text-red-600 mt-1 flex items-center gap-1", children: [_jsx(AlertCircle, { className: "h-3 w-3" }), errors.description] }))] }), _jsxs("div", { className: "grid grid-cols-2 gap-4", children: [_jsxs("div", { children: [_jsx(Label, { htmlFor: "incident_date", className: "required", children: "Incident Date" }), _jsx(Input, { id: "incident_date", type: "date", value: formData.incident_date, onChange: e => handleChange('incident_date', e.target.value), max: new Date().toISOString().split('T')[0], className: errors.incident_date ? 'border-red-500' : '' }), errors.incident_date && (_jsx("p", { className: "text-sm text-red-600 mt-1", children: errors.incident_date }))] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "severity", className: "required", children: "Severity Level" }), _jsxs(Select, { value: formData.severity.toString(), onValueChange: v => handleChange('severity', parseInt(v)), children: [_jsx(SelectTrigger, { id: "severity", children: _jsx(SelectValue, {}) }), _jsx(SelectContent, { children: severityLevels.map(level => (_jsx(SelectItem, { value: level.value.toString(), children: _jsx("span", { className: level.color, children: level.label }) }, level.value))) })] })] })] }), _jsxs("div", { className: "grid grid-cols-2 gap-4", children: [_jsxs("div", { children: [_jsx(Label, { htmlFor: "incident_type", className: "required", children: "Incident Type" }), _jsxs(Select, { value: formData.incident_type, onValueChange: v => handleChange('incident_type', v), children: [_jsx(SelectTrigger, { id: "incident_type", children: _jsx(SelectValue, {}) }), _jsx(SelectContent, { children: incidentTypes.map(type => (_jsx(SelectItem, { value: type, children: type }, type))) })] })] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "status", children: "Status" }), _jsxs(Select, { value: formData.status, onValueChange: v => handleChange('status', v), children: [_jsx(SelectTrigger, { id: "status", children: _jsx(SelectValue, {}) }), _jsx(SelectContent, { children: incidentStatuses.map(status => (_jsx(SelectItem, { value: status, children: status }, status))) })] })] })] }), _jsxs("div", { className: "grid grid-cols-2 gap-4", children: [_jsxs("div", { children: [_jsx(Label, { htmlFor: "division", children: "Division" }), _jsxs(Select, { value: formData.division, onValueChange: v => handleChange('division', v), children: [_jsx(SelectTrigger, { id: "division", children: _jsx(SelectValue, { placeholder: "Select division..." }) }), _jsx(SelectContent, { children: config.divisions.map(div => (_jsx(SelectItem, { value: div, children: div }, div))) })] })] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "department", children: "Department" }), _jsxs(Select, { value: formData.department, onValueChange: v => handleChange('department', v), children: [_jsx(SelectTrigger, { id: "department", children: _jsx(SelectValue, { placeholder: "Select department..." }) }), _jsx(SelectContent, { children: config.departments.map(dept => (_jsx(SelectItem, { value: dept, children: dept }, dept))) })] })] })] }), _jsxs("div", { className: "grid grid-cols-2 gap-4", children: [_jsxs("div", { children: [_jsx(Label, { htmlFor: "reported_by", className: "required", children: "Reported By" }), _jsx(Input, { id: "reported_by", value: formData.reported_by, onChange: e => handleChange('reported_by', e.target.value), placeholder: "Your name", className: errors.reported_by ? 'border-red-500' : '' }), errors.reported_by && (_jsx("p", { className: "text-sm text-red-600 mt-1", children: errors.reported_by }))] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "reporter_email", children: "Reporter Email" }), _jsx(Input, { id: "reporter_email", type: "email", value: formData.reporter_email, onChange: e => handleChange('reporter_email', e.target.value), placeholder: "your.email@company.com" })] })] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "financial_impact", children: "Financial Impact (NGN)" }), _jsx(Input, { id: "financial_impact", type: "number", step: "0.01", value: formData.financial_impact, onChange: e => handleChange('financial_impact', e.target.value), placeholder: "0.00", className: errors.financial_impact ? 'border-red-500' : '' }), errors.financial_impact && (_jsx("p", { className: "text-sm text-red-600 mt-1", children: errors.financial_impact })), _jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Leave blank if not applicable or unknown" })] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "impact_description", children: "Impact Description" }), _jsx(Textarea, { id: "impact_description", value: formData.impact_description, onChange: e => handleChange('impact_description', e.target.value), placeholder: "Describe the impact on operations, customers, reputation, etc.", rows: 3 })] }), _jsx("div", { className: "border-t pt-4", children: _jsx("h4", { className: "text-sm font-semibold text-gray-700 mb-4", children: "Analysis & Resolution" }) }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "root_cause", children: "Root Cause Analysis" }), _jsx(Textarea, { id: "root_cause", value: formData.root_cause, onChange: e => handleChange('root_cause', e.target.value), placeholder: "What was the underlying cause of this incident?", rows: 3 }), _jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Can be filled in later during investigation" })] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "corrective_actions", children: "Corrective Actions" }), _jsx(Textarea, { id: "corrective_actions", value: formData.corrective_actions, onChange: e => handleChange('corrective_actions', e.target.value), placeholder: "What actions have been or will be taken to prevent recurrence?", rows: 3 }), _jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Can be filled in later when actions are identified" })] })] }), _jsxs("div", { className: "flex items-center justify-between pt-4 border-t", children: [_jsxs("p", { className: "text-xs text-gray-500", children: [_jsx("span", { className: "text-red-500", children: "*" }), " Required fields"] }), _jsxs("div", { className: "flex gap-2", children: [_jsxs(Button, { variant: "outline", onClick: onCancel, disabled: loading, children: [_jsx(X, { className: "mr-2 h-4 w-4" }), "Cancel"] }), _jsx(Button, { onClick: handleSubmit, disabled: loading, children: loading ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "mr-2 h-4 w-4 animate-spin" }), "Saving..."] })) : (_jsxs(_Fragment, { children: [_jsx(Save, { className: "mr-2 h-4 w-4" }), isEditing ? 'Update Incident' : 'Create Incident'] })) })] })] })] }));
}
