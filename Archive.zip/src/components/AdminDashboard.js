import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { RefreshCw, Users, FileText, Shield, AlertTriangle, X, Archive, BookOpen, TrendingUp, Trash2, Loader2, Activity } from 'lucide-react';
import { clearAllOrganizationData, clearRiskRegisterData } from '@/lib/admin';
import ArchiveManagement from './ArchiveManagement';
import AuditTrail from './AuditTrail';
import HelpTab from './HelpTab';
import { VarScaleConfig } from './VarScaleConfig';
import AppetiteConfigManager from './risk-appetite/AppetiteConfigManager';
import AppetiteDashboard from './risk-appetite/AppetiteDashboard';
import { KRITabGroup } from './KRITabGroup';
export default function AdminDashboard({ config, showToast }) {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [stats, setStats] = useState({
        totalUsers: 0,
        totalRisks: 0,
        totalControls: 0,
        pendingUsers: 0,
    });
    const [clearingAll, setClearingAll] = useState(false);
    const [clearMessage, setClearMessage] = useState('');
    const [showClearDialog, setShowClearDialog] = useState(false);
    const [confirmText, setConfirmText] = useState('');
    const [clearingRisks, setClearingRisks] = useState(false);
    const [clearRisksMessage, setClearRisksMessage] = useState('');
    const [showClearRisksDialog, setShowClearRisksDialog] = useState(false);
    const [confirmRisksText, setConfirmRisksText] = useState('');
    const loadAdminData = async () => {
        setLoading(true);
        console.log('📊 Loading admin dashboard data...');
        try {
            // Get all users from the admin view (includes emails)
            const { data: adminUsers, error: usersError } = await supabase
                .from('admin_users_view')
                .select('*')
                .order('created_at', { ascending: false });
            if (usersError) {
                console.error('Error loading users:', usersError);
                return;
            }
            const userData = adminUsers?.map(user => ({
                id: user.id,
                email: user.email,
                full_name: user.full_name,
                role: user.role,
                status: user.status,
                organization_id: user.organization_id,
                risk_count: user.risk_count || 0,
                control_count: user.control_count || 0,
                created_at: user.created_at,
                approved_at: user.approved_at,
            })) || [];
            setUsers(userData);
            // Calculate stats
            const { data: risks } = await supabase.from('risks').select('id');
            const { data: controls } = await supabase.from('controls').select('id');
            setStats({
                totalUsers: userData.length,
                totalRisks: risks?.length || 0,
                totalControls: controls?.length || 0,
                pendingUsers: userData.filter(u => u.status === 'pending').length,
            });
            console.log('✅ Admin data loaded:', userData.length, 'users');
        }
        catch (error) {
            console.error('❌ Failed to load admin data:', error);
        }
        finally {
            setLoading(false);
        }
    };
    const approveUser = async (userId, role) => {
        try {
            const { error } = await supabase.rpc('approve_user', {
                target_user_id: userId,
                new_role: role,
            });
            if (error)
                throw error;
            console.log('✅ User approved:', userId);
            await loadAdminData();
        }
        catch (error) {
            console.error('❌ Failed to approve user:', error);
            alert('Failed to approve user: ' + error.message);
        }
    };
    const rejectUser = async (userId) => {
        try {
            const { error } = await supabase.rpc('reject_user', {
                target_user_id: userId,
            });
            if (error)
                throw error;
            console.log('✅ User rejected:', userId);
            await loadAdminData();
        }
        catch (error) {
            console.error('❌ Failed to reject user:', error);
            alert('Failed to reject user: ' + error.message);
        }
    };
    const changeUserRole = async (userId, newRole) => {
        try {
            const { error } = await supabase.rpc('change_user_role', {
                target_user_id: userId,
                new_role: newRole,
            });
            if (error)
                throw error;
            console.log('✅ User role changed:', userId, 'to', newRole);
            await loadAdminData();
        }
        catch (error) {
            console.error('❌ Failed to change user role:', error);
            alert('Failed to change user role: ' + error.message);
        }
    };
    const deleteUser = async (userId, userEmail) => {
        if (!confirm(`Are you sure you want to delete user ${userEmail}? This will delete all their risks and controls. This action cannot be undone.`)) {
            return;
        }
        try {
            const { error } = await supabase.rpc('delete_user', {
                target_user_id: userId,
            });
            if (error)
                throw error;
            console.log('✅ User deleted:', userId);
            await loadAdminData();
        }
        catch (error) {
            console.error('❌ Failed to delete user:', error);
            alert('Failed to delete user: ' + error.message);
        }
    };
    const handleClearAllData = async () => {
        if (confirmText !== 'DELETE') {
            return; // Button should be disabled anyway
        }
        setShowClearDialog(false);
        setClearingAll(true);
        setClearMessage('Clearing all data...');
        const { success, deleted, error } = await clearAllOrganizationData();
        if (success) {
            setClearMessage(`Successfully cleared:\n• ${deleted.alerts} intelligence alerts\n• ${deleted.events} external events`);
            showToast(`Cleared ${deleted.alerts} alerts and ${deleted.events} events`, 'success');
        }
        else {
            const errorMsg = `Failed to clear data: ${error}`;
            setClearMessage(errorMsg);
            showToast(errorMsg, 'error');
        }
        setTimeout(() => {
            setClearMessage('');
            setConfirmText('');
        }, 10000); // Show message for 10 seconds
        setClearingAll(false);
    };
    const handleClearRiskRegister = async () => {
        if (confirmRisksText !== 'DELETE RISKS') {
            return;
        }
        setShowClearRisksDialog(false);
        setClearingRisks(true);
        setClearRisksMessage('Clearing risk register...');
        const { success, deleted, error } = await clearRiskRegisterData();
        if (success) {
            setClearRisksMessage(`Successfully cleared:\n• ${deleted.risks} risks\n• ${deleted.controls} controls\n• ${deleted.incidents} incidents\n• ${deleted.history} history records`);
            showToast(`Cleared ${deleted.risks} risks and ${deleted.history} history records`, 'success');
            await loadAdminData(); // Refresh stats
        }
        else {
            const errorMsg = `Failed to clear risk register: ${error}`;
            setClearRisksMessage(errorMsg);
            showToast(errorMsg, 'error');
        }
        setTimeout(() => {
            setClearRisksMessage('');
            setConfirmRisksText('');
        }, 10000);
        setClearingRisks(false);
    };
    useEffect(() => {
        loadAdminData();
    }, []);
    if (loading) {
        return (_jsx("div", { className: "flex items-center justify-center p-8", children: _jsx(RefreshCw, { className: "h-8 w-8 animate-spin text-gray-400" }) }));
    }
    return (_jsxs(Tabs, { defaultValue: "users", className: "space-y-6", children: [_jsxs(TabsList, { className: "grid w-full grid-cols-7 max-w-5xl", children: [_jsxs(TabsTrigger, { value: "users", children: [_jsx(Users, { className: "h-4 w-4 mr-2" }), "Users"] }), _jsxs(TabsTrigger, { value: "appetite", children: [_jsx(Shield, { className: "h-4 w-4 mr-2" }), "Risk Appetite"] }), _jsxs(TabsTrigger, { value: "kri", children: [_jsx(Activity, { className: "h-4 w-4 mr-2" }), "KRI Module"] }), _jsxs(TabsTrigger, { value: "var_config", children: [_jsx(TrendingUp, { className: "h-4 w-4 mr-2" }), "VaR Config"] }), _jsxs(TabsTrigger, { value: "archive", children: [_jsx(Archive, { className: "h-4 w-4 mr-2" }), "Archive"] }), _jsxs(TabsTrigger, { value: "audit", children: [_jsx(FileText, { className: "h-4 w-4 mr-2" }), "Audit Trail"] }), _jsxs(TabsTrigger, { value: "help", children: [_jsx(BookOpen, { className: "h-4 w-4 mr-2" }), "Help"] })] }), _jsxs(TabsContent, { value: "users", className: "space-y-6", children: [_jsxs("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4", children: [_jsxs(Card, { children: [_jsxs(CardHeader, { className: "flex flex-row items-center justify-between space-y-0 pb-2", children: [_jsx(CardTitle, { className: "text-sm font-medium", children: "Total Users" }), _jsx(Users, { className: "h-4 w-4 text-gray-500" })] }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-2xl font-bold", children: stats.totalUsers }), _jsxs("p", { className: "text-xs text-gray-500", children: [stats.pendingUsers, " pending approval"] })] })] }), _jsxs(Card, { children: [_jsxs(CardHeader, { className: "flex flex-row items-center justify-between space-y-0 pb-2", children: [_jsx(CardTitle, { className: "text-sm font-medium", children: "Total Risks" }), _jsx(AlertTriangle, { className: "h-4 w-4 text-gray-500" })] }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-2xl font-bold", children: stats.totalRisks }), _jsx("p", { className: "text-xs text-gray-500", children: "Across all users" })] })] }), _jsxs(Card, { children: [_jsxs(CardHeader, { className: "flex flex-row items-center justify-between space-y-0 pb-2", children: [_jsx(CardTitle, { className: "text-sm font-medium", children: "Total Controls" }), _jsx(Shield, { className: "h-4 w-4 text-gray-500" })] }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-2xl font-bold", children: stats.totalControls }), _jsx("p", { className: "text-xs text-gray-500", children: "Control measures" })] })] }), _jsxs(Card, { children: [_jsxs(CardHeader, { className: "flex flex-row items-center justify-between space-y-0 pb-2", children: [_jsx(CardTitle, { className: "text-sm font-medium", children: "Avg per User" }), _jsx(FileText, { className: "h-4 w-4 text-gray-500" })] }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-2xl font-bold", children: stats.totalUsers > 0 ? Math.round(stats.totalRisks / stats.totalUsers) : 0 }), _jsx("p", { className: "text-xs text-gray-500", children: "Risks per user" })] })] })] }), _jsxs(Card, { className: "border-red-200 bg-red-50", children: [_jsxs(CardHeader, { children: [_jsx(CardTitle, { className: "text-red-600", children: "\u26A0\uFE0F Danger Zone - Intelligence Data" }), _jsx(CardDescription, { className: "text-red-800", children: "Clear all intelligence alerts and external events for your organization. This action cannot be undone." })] }), _jsxs(CardContent, { children: [_jsx(Button, { variant: "destructive", onClick: () => setShowClearDialog(true), disabled: clearingAll, children: clearingAll ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 mr-2 animate-spin" }), "Clearing..."] })) : (_jsxs(_Fragment, { children: [_jsx(Trash2, { className: "h-4 w-4 mr-2" }), "CLEAR INTELLIGENCE DATA"] })) }), clearMessage && (_jsx("div", { className: "mt-4 p-3 bg-white border border-red-200 rounded-lg text-sm whitespace-pre-line", children: clearMessage }))] })] }), _jsxs(Card, { className: "border-red-200 bg-red-50", children: [_jsxs(CardHeader, { children: [_jsx(CardTitle, { className: "text-red-600", children: "\u26A0\uFE0F Danger Zone - Risk Register" }), _jsx(CardDescription, { className: "text-red-800", children: "Clear all risks, controls, incidents, and My Risk History for your organization. This action cannot be undone." })] }), _jsxs(CardContent, { children: [_jsx(Button, { variant: "destructive", onClick: () => setShowClearRisksDialog(true), disabled: clearingRisks, children: clearingRisks ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 mr-2 animate-spin" }), "Clearing..."] })) : (_jsxs(_Fragment, { children: [_jsx(Trash2, { className: "h-4 w-4 mr-2" }), "CLEAR RISK REGISTER"] })) }), clearRisksMessage && (_jsx("div", { className: "mt-4 p-3 bg-white border border-red-200 rounded-lg text-sm whitespace-pre-line", children: clearRisksMessage }))] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { children: _jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { children: [_jsx(CardTitle, { children: "All Users" }), _jsx(CardDescription, { children: "Manage and view all registered users" })] }), _jsxs(Button, { variant: "outline", size: "sm", onClick: loadAdminData, children: [_jsx(RefreshCw, { className: "h-4 w-4 mr-2" }), "Refresh"] })] }) }), _jsx(CardContent, { children: _jsxs("div", { className: "overflow-x-auto", children: [_jsxs("table", { className: "w-full text-sm", children: [_jsx("thead", { children: _jsxs("tr", { className: "border-b", children: [_jsx("th", { className: "text-left p-2 font-medium", children: "User" }), _jsx("th", { className: "text-left p-2 font-medium", children: "Email" }), _jsx("th", { className: "text-left p-2 font-medium", children: "Status" }), _jsx("th", { className: "text-left p-2 font-medium", children: "Role" }), _jsx("th", { className: "text-right p-2 font-medium", children: "Risks" }), _jsx("th", { className: "text-right p-2 font-medium", children: "Controls" }), _jsx("th", { className: "text-left p-2 font-medium", children: "Created" }), _jsx("th", { className: "text-center p-2 font-medium", children: "Actions" })] }) }), _jsx("tbody", { children: users.map((user) => (_jsxs("tr", { className: "border-b hover:bg-gray-50", children: [_jsx("td", { className: "p-2", children: _jsxs("div", { children: [_jsx("div", { className: "font-medium", children: user.full_name || user.email?.split('@')[0] || 'Anonymous' }), _jsxs("div", { className: "text-xs text-gray-500 font-mono", children: [user.id.slice(0, 8), "..."] })] }) }), _jsx("td", { className: "p-2 text-gray-600", children: user.email || _jsx("span", { className: "text-gray-400 italic", children: "No email" }) }), _jsx("td", { className: "p-2", children: _jsxs("span", { className: `inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${user.status === 'pending'
                                                                        ? 'bg-yellow-100 text-yellow-800'
                                                                        : user.status === 'approved'
                                                                            ? 'bg-green-100 text-green-800'
                                                                            : 'bg-red-100 text-red-800'}`, children: [user.status === 'pending' && '⏳ ', user.status === 'approved' && '✓ ', user.status === 'rejected' && '✗ ', user.status.charAt(0).toUpperCase() + user.status.slice(1)] }) }), _jsx("td", { className: "p-2", children: _jsx("span", { className: `text-xs font-medium px-2 py-1 rounded ${user.role === 'admin' ? 'bg-purple-100 text-purple-800' :
                                                                        user.role === 'edit' ? 'bg-blue-100 text-blue-800' :
                                                                            'bg-gray-100 text-gray-800'}`, children: user.role === 'view_only' ? 'View Only' : user.role.toUpperCase() }) }), _jsx("td", { className: "p-2 text-right font-medium", children: user.risk_count }), _jsx("td", { className: "p-2 text-right font-medium", children: user.control_count }), _jsx("td", { className: "p-2 text-gray-600 text-xs", children: new Date(user.created_at).toLocaleDateString() }), _jsx("td", { className: "p-2", children: user.status === 'pending' ? (_jsxs("div", { className: "flex items-center justify-center gap-2", children: [_jsxs(Select, { onValueChange: (role) => approveUser(user.id, role), children: [_jsx(SelectTrigger, { className: "w-32 h-8 text-xs", children: _jsx(SelectValue, { placeholder: "Approve as..." }) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "view_only", children: "View Only" }), _jsx(SelectItem, { value: "edit", children: "Edit" }), _jsx(SelectItem, { value: "admin", children: "Admin" })] })] }), _jsx(Button, { size: "sm", variant: "destructive", onClick: () => rejectUser(user.id), className: "h-8", children: _jsx(X, { className: "h-3 w-3" }) })] })) : user.status === 'approved' ? (_jsxs("div", { className: "flex items-center justify-center gap-2", children: [_jsxs(Select, { value: user.role, onValueChange: (role) => changeUserRole(user.id, role), children: [_jsx(SelectTrigger, { className: "w-32 h-8 text-xs", children: _jsx(SelectValue, { placeholder: "Change role..." }) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "view_only", children: "View Only" }), _jsx(SelectItem, { value: "edit", children: "Edit" }), _jsx(SelectItem, { value: "admin", children: "Admin" })] })] }), _jsx(Button, { size: "sm", variant: "ghost", onClick: () => deleteUser(user.id, user.email || 'Unknown'), className: "h-8 text-red-600 hover:text-red-700 hover:bg-red-50", title: "Delete user", children: _jsx(X, { className: "h-4 w-4" }) })] })) : (_jsxs("div", { className: "flex items-center justify-center gap-2", children: [_jsx("span", { className: "text-xs text-gray-500", children: "\u2717 Rejected" }), _jsx(Button, { size: "sm", variant: "ghost", onClick: () => deleteUser(user.id, user.email || 'Unknown'), className: "h-8 text-red-600 hover:text-red-700 hover:bg-red-50", title: "Delete user", children: _jsx(X, { className: "h-4 w-4" }) })] })) })] }, user.id))) })] }), users.length === 0 && (_jsx("div", { className: "text-center py-8 text-gray-500", children: "No users found" }))] }) })] })] }), _jsx(TabsContent, { value: "appetite", className: "space-y-6", children: _jsxs(Tabs, { defaultValue: "config", children: [_jsxs(TabsList, { children: [_jsx(TabsTrigger, { value: "config", children: "Configuration" }), _jsx(TabsTrigger, { value: "dashboard", children: "Dashboard" })] }), _jsx(TabsContent, { value: "config", children: _jsx(AppetiteConfigManager, { config: config, showToast: showToast }) }), _jsx(TabsContent, { value: "dashboard", children: _jsx(AppetiteDashboard, { showToast: showToast }) })] }) }), _jsx(TabsContent, { value: "kri", className: "space-y-6", children: _jsx(KRITabGroup, { showToast: showToast }) }), _jsx(TabsContent, { value: "archive", children: _jsx(ArchiveManagement, {}) }), _jsx(TabsContent, { value: "audit", children: _jsx(AuditTrail, {}) }), _jsx(TabsContent, { value: "var_config", children: _jsx(VarScaleConfig, { showToast: showToast, matrixSize: config.matrixSize }) }), _jsx(TabsContent, { value: "help", children: _jsx(HelpTab, {}) }), _jsx(Dialog, { open: showClearDialog, onOpenChange: setShowClearDialog, children: _jsxs(DialogContent, { children: [_jsxs(DialogHeader, { children: [_jsx(DialogTitle, { children: "\u26A0\uFE0F WARNING: Clear Intelligence Data" }), _jsxs(DialogDescription, { className: "space-y-3", children: [_jsx("p", { children: "This will permanently delete:" }), _jsxs("ul", { className: "list-disc list-inside text-sm", children: [_jsx("li", { children: "All intelligence alerts (pending, accepted, rejected)" }), _jsx("li", { children: "All external events" })] }), _jsx("p", { className: "font-semibold text-red-600", children: "This action CANNOT be undone and only affects data for your organization." }), _jsxs("p", { children: ["Type ", _jsx("code", { className: "bg-gray-100 px-1 rounded", children: "DELETE" }), " to confirm:"] })] })] }), _jsx(Input, { value: confirmText, onChange: (e) => setConfirmText(e.target.value), placeholder: "Type DELETE to confirm", className: "font-mono" }), _jsxs(DialogFooter, { children: [_jsx(Button, { variant: "outline", onClick: () => {
                                        setShowClearDialog(false);
                                        setConfirmText('');
                                    }, children: "Cancel" }), _jsx(Button, { variant: "destructive", onClick: handleClearAllData, disabled: confirmText !== 'DELETE', children: "Confirm Deletion" })] })] }) }), _jsx(Dialog, { open: showClearRisksDialog, onOpenChange: setShowClearRisksDialog, children: _jsxs(DialogContent, { children: [_jsxs(DialogHeader, { children: [_jsx(DialogTitle, { children: "\u26A0\uFE0F WARNING: Clear Risk Register" }), _jsxs(DialogDescription, { className: "space-y-3", children: [_jsx("p", { children: "This will permanently delete:" }), _jsxs("ul", { className: "list-disc list-inside text-sm", children: [_jsx("li", { children: "All risks" }), _jsx("li", { children: "All controls" }), _jsx("li", { children: "All incidents" }), _jsx("li", { children: "All My Risk History records" })] }), _jsx("p", { className: "font-semibold text-red-600", children: "This action CANNOT be undone and only affects data for your organization." }), _jsxs("p", { children: ["Type ", _jsx("code", { className: "bg-gray-100 px-1 rounded", children: "DELETE RISKS" }), " to confirm:"] })] })] }), _jsx(Input, { value: confirmRisksText, onChange: (e) => setConfirmRisksText(e.target.value), placeholder: "Type DELETE RISKS to confirm", className: "font-mono" }), _jsxs(DialogFooter, { children: [_jsx(Button, { variant: "outline", onClick: () => {
                                        setShowClearRisksDialog(false);
                                        setConfirmRisksText('');
                                    }, children: "Cancel" }), _jsx(Button, { variant: "destructive", onClick: handleClearRiskRegister, disabled: confirmRisksText !== 'DELETE RISKS', children: "Confirm Deletion" })] })] }) })] }));
}
