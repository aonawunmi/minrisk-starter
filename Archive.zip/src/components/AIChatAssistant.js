import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useState, useRef, useEffect } from 'react';
import { X, Send, Loader2, Sparkles } from 'lucide-react';
import { askClaude } from '../lib/ai';
export function AIChatAssistant() {
    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef(null);
    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };
    useEffect(() => {
        scrollToBottom();
    }, [messages]);
    const handleSend = async () => {
        if (!input.trim() || isLoading)
            return;
        const userMessage = input.trim();
        setInput('');
        // Add user message
        const newMessages = [...messages, { role: 'user', content: userMessage }];
        setMessages(newMessages);
        setIsLoading(true);
        try {
            // Call Claude with conversation history
            const response = await askClaude(userMessage, messages);
            // Add assistant response
            setMessages([...newMessages, { role: 'assistant', content: response }]);
        }
        catch (error) {
            console.error('Chat error:', error);
            setMessages([
                ...newMessages,
                {
                    role: 'assistant',
                    content: `I'm sorry, I encountered an error: ${error.message}. Please make sure your Anthropic API key is configured correctly.`
                }
            ]);
        }
        finally {
            setIsLoading(false);
        }
    };
    const handleKeyPress = (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };
    return (_jsxs(_Fragment, { children: [!isOpen && (_jsx("button", { onClick: () => setIsOpen(true), className: "fixed bottom-6 right-6 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full p-4 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110 z-50", title: "Open AI Assistant", children: _jsx(Sparkles, { className: "h-6 w-6" }) })), isOpen && (_jsxs("div", { className: "fixed bottom-6 right-6 w-96 h-[600px] bg-white rounded-lg shadow-2xl flex flex-col z-50 border border-gray-200", children: [_jsxs("div", { className: "bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 rounded-t-lg flex items-center justify-between", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Sparkles, { className: "h-5 w-5" }), _jsxs("div", { children: [_jsx("h3", { className: "font-semibold", children: "AI Risk Assistant" }), _jsx("p", { className: "text-xs opacity-90", children: "Powered by Claude AI" })] })] }), _jsx("button", { onClick: () => setIsOpen(false), className: "hover:bg-white/20 rounded p-1 transition-colors", children: _jsx(X, { className: "h-5 w-5" }) })] }), _jsxs("div", { className: "flex-1 overflow-y-auto p-4 space-y-4", children: [messages.length === 0 && (_jsxs("div", { className: "text-center text-gray-500 mt-8", children: [_jsx(Sparkles, { className: "h-12 w-12 mx-auto mb-4 text-purple-400" }), _jsx("p", { className: "font-medium mb-2", children: "Welcome to AI Risk Assistant!" }), _jsx("p", { className: "text-sm px-4", children: "Ask me anything about risk management, compliance, or get help with creating risk assessments." })] })), messages.map((msg, idx) => (_jsx("div", { className: `flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`, children: _jsx("div", { className: `max-w-[80%] rounded-lg p-3 ${msg.role === 'user'
                                        ? 'bg-blue-600 text-white'
                                        : 'bg-gray-100 text-gray-900'}`, children: _jsx("p", { className: "text-sm whitespace-pre-wrap", children: msg.content }) }) }, idx))), isLoading && (_jsx("div", { className: "flex justify-start", children: _jsx("div", { className: "bg-gray-100 rounded-lg p-3", children: _jsx(Loader2, { className: "h-5 w-5 animate-spin text-purple-600" }) }) })), _jsx("div", { ref: messagesEndRef })] }), _jsxs("div", { className: "border-t border-gray-200 p-4", children: [_jsxs("div", { className: "flex gap-2", children: [_jsx("textarea", { value: input, onChange: (e) => setInput(e.target.value), onKeyPress: handleKeyPress, placeholder: "Ask about risks, compliance, controls...", className: "flex-1 border border-gray-300 rounded-lg px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-purple-500", rows: 2, disabled: isLoading }), _jsx("button", { onClick: handleSend, disabled: isLoading || !input.trim(), className: "bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg px-4 hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-opacity", children: _jsx(Send, { className: "h-5 w-5" }) })] }), _jsx("p", { className: "text-xs text-gray-400 mt-2", children: "Press Enter to send, Shift+Enter for new line" })] })] }))] }));
}
