import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// src/components/risk-appetite/AppetiteConfigManager.tsx
// Admin UI for managing Risk Appetite configurations (Phase 5A)
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Plus, Edit, Trash2, Save, X, AlertCircle, TrendingUp, Shield } from 'lucide-react';
import { loadAppetiteConfigs, saveAppetiteConfig, updateAppetiteConfig, deleteAppetiteConfig, getDefaultAppetiteThresholds, } from '@/lib/risk-appetite';
export default function AppetiteConfigManager({ config, showToast }) {
    const [configs, setConfigs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showDialog, setShowDialog] = useState(false);
    const [editingConfig, setEditingConfig] = useState(null);
    const [formData, setFormData] = useState({
        category: '',
        appetite_threshold: 15,
        tolerance_min: 12,
        tolerance_max: 18,
        rationale: '',
        effective_from: new Date().toISOString().split('T')[0],
    });
    const [errors, setErrors] = useState({});
    // Load appetite configurations
    useEffect(() => {
        loadConfigs();
    }, []);
    const loadConfigs = async () => {
        setLoading(true);
        try {
            const data = await loadAppetiteConfigs();
            setConfigs(data);
        }
        catch (error) {
            console.error('Error loading appetite configs:', error);
            showToast('Failed to load appetite configurations', 'error');
        }
        finally {
            setLoading(false);
        }
    };
    // Validation
    const validateForm = () => {
        const newErrors = {};
        if (!formData.category) {
            newErrors.category = 'Category is required';
        }
        if (formData.appetite_threshold < 1 || formData.appetite_threshold > 30) {
            newErrors.appetite_threshold = 'Appetite threshold must be between 1 and 30';
        }
        if (formData.tolerance_min < 1) {
            newErrors.tolerance_min = 'Minimum tolerance must be at least 1';
        }
        if (formData.tolerance_max > 30) {
            newErrors.tolerance_max = 'Maximum tolerance cannot exceed 30';
        }
        if (formData.tolerance_min > formData.appetite_threshold) {
            newErrors.tolerance_min = 'Minimum tolerance cannot exceed appetite threshold';
        }
        if (formData.appetite_threshold > formData.tolerance_max) {
            newErrors.tolerance_max = 'Appetite threshold cannot exceed maximum tolerance';
        }
        if (!formData.effective_from) {
            newErrors.effective_from = 'Effective from date is required';
        }
        if (formData.effective_to && formData.effective_to <= formData.effective_from) {
            newErrors.effective_to = 'Effective to date must be after effective from date';
        }
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };
    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validateForm()) {
            return;
        }
        try {
            if (editingConfig) {
                // Update existing config
                await updateAppetiteConfig(editingConfig.id, formData);
                showToast('Appetite configuration updated successfully', 'success');
            }
            else {
                // Create new config
                await saveAppetiteConfig(formData);
                showToast('Appetite configuration created successfully', 'success');
            }
            setShowDialog(false);
            resetForm();
            loadConfigs();
        }
        catch (error) {
            console.error('Error saving appetite config:', error);
            showToast('Failed to save appetite configuration', 'error');
        }
    };
    // Handle delete
    const handleDelete = async (id) => {
        if (!confirm('Are you sure you want to delete this appetite configuration?')) {
            return;
        }
        try {
            await deleteAppetiteConfig(id);
            showToast('Appetite configuration deleted successfully', 'success');
            loadConfigs();
        }
        catch (error) {
            console.error('Error deleting appetite config:', error);
            showToast('Failed to delete appetite configuration', 'error');
        }
    };
    // Handle edit
    const handleEdit = (configItem) => {
        setEditingConfig(configItem);
        setFormData({
            category: configItem.category,
            appetite_threshold: configItem.appetite_threshold,
            tolerance_min: configItem.tolerance_min,
            tolerance_max: configItem.tolerance_max,
            rationale: configItem.rationale || '',
            effective_from: configItem.effective_from,
            effective_to: configItem.effective_to,
        });
        setShowDialog(true);
    };
    // Handle new config
    const handleNew = () => {
        resetForm();
        setEditingConfig(null);
        setShowDialog(true);
    };
    // Reset form
    const resetForm = () => {
        setFormData({
            category: '',
            appetite_threshold: 15,
            tolerance_min: 12,
            tolerance_max: 18,
            rationale: '',
            effective_from: new Date().toISOString().split('T')[0],
        });
        setErrors({});
    };
    // Load default thresholds for a category
    const loadDefaults = () => {
        const defaults = getDefaultAppetiteThresholds();
        const categoryDefault = defaults[formData.category];
        if (categoryDefault) {
            setFormData({
                ...formData,
                appetite_threshold: categoryDefault.threshold,
                tolerance_min: categoryDefault.min,
                tolerance_max: categoryDefault.max,
                rationale: categoryDefault.rationale,
            });
            showToast('Default thresholds loaded', 'success');
        }
        else {
            showToast('No defaults available for this category', 'error');
        }
    };
    // Get status badge color
    const getStatusColor = (effectiveFrom, effectiveTo) => {
        const today = new Date().toISOString().split('T')[0];
        const from = effectiveFrom;
        const to = effectiveTo;
        if (today < from) {
            return 'bg-blue-100 text-blue-800';
        }
        else if (to && today > to) {
            return 'bg-gray-100 text-gray-800';
        }
        else {
            return 'bg-green-100 text-green-800';
        }
    };
    const getStatusText = (effectiveFrom, effectiveTo) => {
        const today = new Date().toISOString().split('T')[0];
        const from = effectiveFrom;
        const to = effectiveTo;
        if (today < from) {
            return 'Future';
        }
        else if (to && today > to) {
            return 'Expired';
        }
        else {
            return 'Active';
        }
    };
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { children: [_jsxs("h2", { className: "text-2xl font-bold flex items-center gap-2", children: [_jsx(Shield, { className: "h-6 w-6" }), "Risk Appetite Configuration"] }), _jsx("p", { className: "text-gray-600 mt-1", children: "Define risk appetite thresholds by category" })] }), _jsxs(Button, { onClick: handleNew, className: "flex items-center gap-2", children: [_jsx(Plus, { className: "h-4 w-4" }), "New Configuration"] })] }), _jsx(Card, { className: "border-blue-200 bg-blue-50", children: _jsx(CardContent, { className: "pt-6", children: _jsxs("div", { className: "flex gap-2", children: [_jsx(AlertCircle, { className: "h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" }), _jsxs("div", { className: "text-sm text-blue-800", children: [_jsx("strong", { children: "Risk Appetite Framework:" }), " Set thresholds that define your organization's acceptable risk levels. Appetite is the target level, while tolerance defines the acceptable range. Risks exceeding tolerance require exception approval."] })] }) }) }), _jsxs(Card, { children: [_jsxs(CardHeader, { children: [_jsx(CardTitle, { children: "Current Configurations" }), _jsxs(CardDescription, { children: [configs.length, " configuration", configs.length !== 1 ? 's' : '', " defined"] })] }), _jsx(CardContent, { children: loading ? (_jsx("div", { className: "flex justify-center py-8", children: _jsx("div", { className: "text-gray-500", children: "Loading configurations..." }) })) : configs.length === 0 ? (_jsxs("div", { className: "flex flex-col items-center justify-center py-12 text-gray-500", children: [_jsx(Shield, { className: "h-12 w-12 mb-4 opacity-20" }), _jsx("p", { className: "text-lg font-medium", children: "No appetite configurations defined" }), _jsx("p", { className: "text-sm", children: "Click \"New Configuration\" to get started" })] })) : (_jsx("div", { className: "overflow-x-auto", children: _jsxs("table", { className: "w-full", children: [_jsx("thead", { className: "border-b", children: _jsxs("tr", { className: "text-left", children: [_jsx("th", { className: "pb-2 font-medium", children: "Category" }), _jsx("th", { className: "pb-2 font-medium", children: "Appetite" }), _jsx("th", { className: "pb-2 font-medium", children: "Tolerance Range" }), _jsx("th", { className: "pb-2 font-medium", children: "Effective Period" }), _jsx("th", { className: "pb-2 font-medium", children: "Status" }), _jsx("th", { className: "pb-2 font-medium", children: "Actions" })] }) }), _jsx("tbody", { children: configs.map((configItem) => (_jsxs("tr", { className: "border-b", children: [_jsx("td", { className: "py-3 font-medium", children: configItem.category }), _jsx("td", { className: "py-3", children: _jsxs("span", { className: "inline-flex items-center gap-1 px-2 py-1 bg-orange-100 text-orange-800 rounded text-sm font-medium", children: [_jsx(TrendingUp, { className: "h-3 w-3" }), configItem.appetite_threshold] }) }), _jsx("td", { className: "py-3", children: _jsxs("span", { className: "text-sm text-gray-600", children: [configItem.tolerance_min, " - ", configItem.tolerance_max] }) }), _jsxs("td", { className: "py-3 text-sm", children: [_jsx("div", { children: configItem.effective_from }), configItem.effective_to && (_jsxs("div", { className: "text-gray-500", children: ["to ", configItem.effective_to] }))] }), _jsx("td", { className: "py-3", children: _jsx("span", { className: `inline-flex px-2 py-1 rounded text-xs font-medium ${getStatusColor(configItem.effective_from, configItem.effective_to)}`, children: getStatusText(configItem.effective_from, configItem.effective_to) }) }), _jsx("td", { className: "py-3", children: _jsxs("div", { className: "flex gap-2", children: [_jsx(Button, { variant: "outline", size: "sm", onClick: () => handleEdit(configItem), children: _jsx(Edit, { className: "h-3 w-3" }) }), _jsx(Button, { variant: "outline", size: "sm", onClick: () => handleDelete(configItem.id), children: _jsx(Trash2, { className: "h-3 w-3" }) })] }) })] }, configItem.id))) })] }) })) })] }), _jsx(Dialog, { open: showDialog, onOpenChange: setShowDialog, children: _jsxs(DialogContent, { className: "max-w-2xl", children: [_jsxs(DialogHeader, { children: [_jsx(DialogTitle, { children: editingConfig ? 'Edit Appetite Configuration' : 'New Appetite Configuration' }), _jsx(DialogDescription, { children: "Define the risk appetite threshold and tolerance range for a category" })] }), _jsxs("form", { onSubmit: handleSubmit, className: "space-y-4", children: [_jsxs("div", { children: [_jsx(Label, { htmlFor: "category", children: "Risk Category" }), _jsxs("div", { className: "flex gap-2", children: [_jsxs("select", { id: "category", className: "flex-1 border border-gray-300 rounded-md px-3 py-2", value: formData.category, onChange: (e) => setFormData({ ...formData, category: e.target.value }), disabled: !!editingConfig, children: [_jsx("option", { value: "", children: "Select a category..." }), config.categories.map((cat) => (_jsx("option", { value: cat, children: cat }, cat)))] }), _jsx(Button, { type: "button", variant: "outline", onClick: loadDefaults, disabled: !formData.category, children: "Load Defaults" })] }), errors.category && (_jsx("p", { className: "text-sm text-red-600 mt-1", children: errors.category }))] }), _jsxs("div", { className: "grid grid-cols-3 gap-4", children: [_jsxs("div", { children: [_jsx(Label, { htmlFor: "tolerance_min", children: "Minimum Tolerance" }), _jsx(Input, { id: "tolerance_min", type: "number", min: "1", max: "30", value: formData.tolerance_min, onChange: (e) => setFormData({ ...formData, tolerance_min: parseInt(e.target.value) }) }), errors.tolerance_min && (_jsx("p", { className: "text-sm text-red-600 mt-1", children: errors.tolerance_min }))] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "appetite_threshold", children: "Appetite Threshold" }), _jsx(Input, { id: "appetite_threshold", type: "number", min: "1", max: "30", value: formData.appetite_threshold, onChange: (e) => setFormData({ ...formData, appetite_threshold: parseInt(e.target.value) }) }), errors.appetite_threshold && (_jsx("p", { className: "text-sm text-red-600 mt-1", children: errors.appetite_threshold }))] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "tolerance_max", children: "Maximum Tolerance" }), _jsx(Input, { id: "tolerance_max", type: "number", min: "1", max: "30", value: formData.tolerance_max, onChange: (e) => setFormData({ ...formData, tolerance_max: parseInt(e.target.value) }) }), errors.tolerance_max && (_jsx("p", { className: "text-sm text-red-600 mt-1", children: errors.tolerance_max }))] })] }), _jsxs("div", { className: "bg-gray-50 p-4 rounded-lg", children: [_jsx("div", { className: "text-sm font-medium mb-2", children: "Visual Guide:" }), _jsx("div", { className: "h-8 flex items-center", children: _jsxs("div", { className: "flex-1 h-full bg-gradient-to-r from-green-400 via-yellow-400 to-red-400 rounded relative", children: [_jsx("div", { className: "absolute h-full w-0.5 bg-blue-600", style: { left: `${(formData.tolerance_min / 30) * 100}%` }, children: _jsx("span", { className: "absolute -top-6 -left-2 text-xs text-blue-600", children: "Min" }) }), _jsx("div", { className: "absolute h-full w-0.5 bg-orange-600", style: { left: `${(formData.appetite_threshold / 30) * 100}%` }, children: _jsx("span", { className: "absolute -bottom-6 -left-4 text-xs text-orange-600", children: "Appetite" }) }), _jsx("div", { className: "absolute h-full w-0.5 bg-blue-600", style: { left: `${(formData.tolerance_max / 30) * 100}%` }, children: _jsx("span", { className: "absolute -top-6 -left-2 text-xs text-blue-600", children: "Max" }) })] }) })] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "rationale", children: "Rationale" }), _jsx(Textarea, { id: "rationale", placeholder: "Explain why these thresholds are appropriate for this risk category...", value: formData.rationale, onChange: (e) => setFormData({ ...formData, rationale: e.target.value }), rows: 3 })] }), _jsxs("div", { className: "grid grid-cols-2 gap-4", children: [_jsxs("div", { children: [_jsx(Label, { htmlFor: "effective_from", children: "Effective From" }), _jsx(Input, { id: "effective_from", type: "date", value: formData.effective_from, onChange: (e) => setFormData({ ...formData, effective_from: e.target.value }) }), errors.effective_from && (_jsx("p", { className: "text-sm text-red-600 mt-1", children: errors.effective_from }))] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "effective_to", children: "Effective To (Optional)" }), _jsx(Input, { id: "effective_to", type: "date", value: formData.effective_to || '', onChange: (e) => setFormData({ ...formData, effective_to: e.target.value || undefined }) }), errors.effective_to && (_jsx("p", { className: "text-sm text-red-600 mt-1", children: errors.effective_to }))] })] }), _jsxs(DialogFooter, { children: [_jsxs(Button, { type: "button", variant: "outline", onClick: () => {
                                                setShowDialog(false);
                                                resetForm();
                                            }, children: [_jsx(X, { className: "h-4 w-4 mr-2" }), "Cancel"] }), _jsxs(Button, { type: "submit", children: [_jsx(Save, { className: "h-4 w-4 mr-2" }), editingConfig ? 'Update' : 'Create', " Configuration"] })] })] })] }) })] }));
}
