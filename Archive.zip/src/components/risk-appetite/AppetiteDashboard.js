import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// src/components/risk-appetite/AppetiteDashboard.tsx
// Executive Dashboard for Risk Appetite Monitoring (Phase 5A)
import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RefreshCw, TrendingUp, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { calculateAppetiteUtilization, loadAppetiteHistory, loadAppetiteExceptions, generateAppetiteSnapshot, } from '@/lib/risk-appetite';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
export default function AppetiteDashboard({ showToast }) {
    const [utilization, setUtilization] = useState(null);
    const [history, setHistory] = useState([]);
    const [exceptions, setExceptions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    useEffect(() => {
        loadData();
    }, []);
    const loadData = async () => {
        setLoading(true);
        try {
            const [utilizationData, historyData, exceptionsData] = await Promise.all([
                calculateAppetiteUtilization(),
                loadAppetiteHistory(30),
                loadAppetiteExceptions('pending'),
            ]);
            setUtilization(utilizationData);
            setHistory(historyData);
            setExceptions(exceptionsData);
        }
        catch (error) {
            console.error('Error loading appetite dashboard:', error);
            showToast('Failed to load appetite dashboard', 'error');
        }
        finally {
            setLoading(false);
        }
    };
    const handleRefresh = async () => {
        setRefreshing(true);
        try {
            await generateAppetiteSnapshot();
            await loadData();
            showToast('Dashboard refreshed successfully', 'success');
        }
        catch (error) {
            console.error('Error refreshing dashboard:', error);
            showToast('Failed to refresh dashboard', 'error');
        }
        finally {
            setRefreshing(false);
        }
    };
    // Gauge chart component
    const AppetiteGauge = ({ value, max = 100 }) => {
        const percentage = Math.min((value / max) * 100, 100);
        const rotation = (percentage / 100) * 180 - 90;
        const getColor = () => {
            if (percentage <= 50)
                return 'text-green-600';
            if (percentage <= 75)
                return 'text-yellow-600';
            return 'text-red-600';
        };
        const getLabel = () => {
            if (percentage <= 50)
                return 'Within Appetite';
            if (percentage <= 75)
                return 'Approaching Limit';
            return 'Over Appetite';
        };
        return (_jsxs("div", { className: "flex flex-col items-center", children: [_jsx("div", { className: "relative w-48 h-24", children: _jsxs("svg", { viewBox: "0 0 200 100", className: "w-full h-full", children: [_jsx("path", { d: "M 20 80 A 80 80 0 0 1 180 80", fill: "none", stroke: "#e5e7eb", strokeWidth: "20", strokeLinecap: "round" }), _jsx("path", { d: "M 20 80 A 80 80 0 0 1 100 20", fill: "none", stroke: "#10b981", strokeWidth: "20", strokeLinecap: "round" }), _jsx("path", { d: "M 100 20 A 80 80 0 0 1 140 35", fill: "none", stroke: "#fbbf24", strokeWidth: "20", strokeLinecap: "round" }), _jsx("path", { d: "M 140 35 A 80 80 0 0 1 180 80", fill: "none", stroke: "#ef4444", strokeWidth: "20", strokeLinecap: "round" }), _jsxs("g", { transform: `rotate(${rotation}, 100, 80)`, children: [_jsx("line", { x1: "100", y1: "80", x2: "100", y2: "30", stroke: "#1f2937", strokeWidth: "3", strokeLinecap: "round" }), _jsx("circle", { cx: "100", cy: "80", r: "5", fill: "#1f2937" })] })] }) }), _jsxs("div", { className: "text-center mt-2", children: [_jsxs("div", { className: `text-3xl font-bold ${getColor()}`, children: [value.toFixed(1), "%"] }), _jsx("div", { className: "text-sm text-gray-600 mt-1", children: getLabel() })] })] }));
    };
    // Format history data for chart
    const chartData = history.map((item) => ({
        date: new Date(item.snapshot_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        utilization: item.appetite_utilization,
        within: item.risks_within_appetite,
        over: item.risks_over_appetite,
    })).reverse();
    if (loading) {
        return (_jsx("div", { className: "flex justify-center items-center py-12", children: _jsx("div", { className: "text-gray-500", children: "Loading appetite dashboard..." }) }));
    }
    if (!utilization) {
        return (_jsxs("div", { className: "flex flex-col items-center justify-center py-12 text-gray-500", children: [_jsx(AlertTriangle, { className: "h-12 w-12 mb-4 opacity-20" }), _jsx("p", { className: "text-lg font-medium", children: "No appetite data available" }), _jsx("p", { className: "text-sm", children: "Configure appetite thresholds to start monitoring" })] }));
    }
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { children: [_jsxs("h2", { className: "text-2xl font-bold flex items-center gap-2", children: [_jsx(TrendingUp, { className: "h-6 w-6" }), "Risk Appetite Dashboard"] }), _jsx("p", { className: "text-gray-600 mt-1", children: "Real-time monitoring of organizational risk appetite utilization" })] }), _jsxs(Button, { onClick: handleRefresh, disabled: refreshing, className: "flex items-center gap-2", children: [_jsx(RefreshCw, { className: `h-4 w-4 ${refreshing ? 'animate-spin' : ''}` }), "Refresh"] })] }), _jsxs("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4", children: [_jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardDescription, { children: "Total Risks" }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-3xl font-bold", children: utilization.total_risks }), _jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Active risks in portfolio" })] })] }), _jsxs(Card, { className: "border-green-200 bg-green-50", children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardDescription, { children: "Within Appetite" }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-3xl font-bold text-green-700", children: utilization.risks_within_appetite }), _jsxs("p", { className: "text-xs text-gray-600 mt-1", children: [utilization.total_risks > 0
                                                ? `${((utilization.risks_within_appetite / utilization.total_risks) * 100).toFixed(1)}%`
                                                : '0%', " of total"] })] })] }), _jsxs(Card, { className: "border-red-200 bg-red-50", children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardDescription, { children: "Over Appetite" }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-3xl font-bold text-red-700", children: utilization.risks_over_appetite }), _jsxs("p", { className: "text-xs text-gray-600 mt-1", children: [utilization.total_risks > 0
                                                ? `${((utilization.risks_over_appetite / utilization.total_risks) * 100).toFixed(1)}%`
                                                : '0%', " of total"] })] })] }), _jsxs(Card, { className: "border-orange-200 bg-orange-50", children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardDescription, { children: "Average Risk Score" }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-3xl font-bold text-orange-700", children: utilization.avg_score.toFixed(1) }), _jsx("p", { className: "text-xs text-gray-600 mt-1", children: "Out of 30.0" })] })] })] }), _jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [_jsxs(Card, { children: [_jsxs(CardHeader, { children: [_jsx(CardTitle, { children: "Appetite Utilization" }), _jsx(CardDescription, { children: "Overall risk appetite consumption" })] }), _jsx(CardContent, { className: "flex justify-center py-6", children: _jsx(AppetiteGauge, { value: utilization.utilization }) })] }), _jsxs(Card, { children: [_jsxs(CardHeader, { children: [_jsxs(CardTitle, { className: "flex items-center gap-2", children: [_jsx(Clock, { className: "h-5 w-5" }), "Pending Exceptions"] }), _jsxs(CardDescription, { children: [exceptions.length, " exception", exceptions.length !== 1 ? 's' : '', " awaiting approval"] })] }), _jsx(CardContent, { children: exceptions.length === 0 ? (_jsxs("div", { className: "flex flex-col items-center justify-center py-8 text-gray-500", children: [_jsx(CheckCircle, { className: "h-12 w-12 mb-2 opacity-20" }), _jsx("p", { className: "text-sm", children: "No pending exceptions" })] })) : (_jsxs("div", { className: "space-y-2 max-h-64 overflow-y-auto", children: [exceptions.slice(0, 5).map((exception) => (_jsx("div", { className: "p-3 bg-gray-50 rounded-lg border border-gray-200", children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { className: "flex-1", children: [_jsxs("div", { className: "font-medium text-sm", children: ["Risk ID: ", exception.risk_id.slice(0, 8), "..."] }), _jsxs("div", { className: "text-xs text-gray-600 mt-1", children: ["Review: ", new Date(exception.review_date).toLocaleDateString()] })] }), _jsx("span", { className: "inline-flex items-center px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs font-medium", children: "Pending" })] }) }, exception.id))), exceptions.length > 5 && (_jsx("div", { className: "text-center pt-2", children: _jsxs(Button, { variant: "outline", size: "sm", children: ["View All ", exceptions.length, " Exceptions"] }) }))] })) })] })] }), history.length > 0 && (_jsxs(Card, { children: [_jsxs(CardHeader, { children: [_jsx(CardTitle, { children: "Appetite Utilization Trend" }), _jsx(CardDescription, { children: "Last 30 days of appetite monitoring" })] }), _jsx(CardContent, { children: _jsx(ResponsiveContainer, { width: "100%", height: 300, children: _jsxs(LineChart, { data: chartData, children: [_jsx(CartesianGrid, { strokeDasharray: "3 3" }), _jsx(XAxis, { dataKey: "date", tick: { fontSize: 12 }, angle: -45, textAnchor: "end", height: 60 }), _jsx(YAxis, { tick: { fontSize: 12 }, label: { value: 'Utilization (%)', angle: -90, position: 'insideLeft' } }), _jsx(Tooltip, {}), _jsx(Legend, {}), _jsx(Line, { type: "monotone", dataKey: "utilization", stroke: "#f97316", strokeWidth: 2, name: "Utilization %", dot: { r: 3 } })] }) }) })] })), history.length > 0 && (_jsxs(Card, { children: [_jsxs(CardHeader, { children: [_jsx(CardTitle, { children: "Risk Distribution Trend" }), _jsx(CardDescription, { children: "Within vs. Over Appetite comparison" })] }), _jsx(CardContent, { children: _jsx(ResponsiveContainer, { width: "100%", height: 300, children: _jsxs(LineChart, { data: chartData, children: [_jsx(CartesianGrid, { strokeDasharray: "3 3" }), _jsx(XAxis, { dataKey: "date", tick: { fontSize: 12 }, angle: -45, textAnchor: "end", height: 60 }), _jsx(YAxis, { tick: { fontSize: 12 }, label: { value: 'Number of Risks', angle: -90, position: 'insideLeft' } }), _jsx(Tooltip, {}), _jsx(Legend, {}), _jsx(Line, { type: "monotone", dataKey: "within", stroke: "#10b981", strokeWidth: 2, name: "Within Appetite", dot: { r: 3 } }), _jsx(Line, { type: "monotone", dataKey: "over", stroke: "#ef4444", strokeWidth: 2, name: "Over Appetite", dot: { r: 3 } })] }) }) })] })), _jsx(Card, { className: "border-blue-200 bg-blue-50", children: _jsx(CardContent, { className: "pt-6", children: _jsxs("div", { className: "flex gap-2", children: [_jsx(AlertTriangle, { className: "h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" }), _jsxs("div", { className: "text-sm text-blue-800", children: [_jsx("strong", { children: "Dashboard Updates:" }), " This dashboard displays real-time appetite utilization. Click \"Refresh\" to generate a new snapshot and update historical trends. Pending exceptions require admin approval before risks can exceed tolerance thresholds."] })] }) }) })] }));
}
