import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// src/components/intelligence/TreatmentLog.tsx
// Treatment Log - Track and apply accepted alerts to risk register
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { FileCheck, CheckCircle2, Clock, TrendingUp, TrendingDown, Loader2, AlertTriangle, Calendar, } from 'lucide-react';
import { loadRiskAlerts, applyAlertTreatment } from '../../lib/riskIntelligence';
import { format } from 'date-fns';
// Helper function for likelihood change indicator
const getLikelihoodChangeIndicator = (change) => {
    if (change > 0) {
        return (_jsxs("div", { className: "flex items-center gap-1 text-red-600", children: [_jsx(TrendingUp, { className: "h-4 w-4" }), _jsxs("span", { className: "text-sm font-medium", children: ["+", change] })] }));
    }
    else if (change < 0) {
        return (_jsxs("div", { className: "flex items-center gap-1 text-green-600", children: [_jsx(TrendingDown, { className: "h-4 w-4" }), _jsx("span", { className: "text-sm font-medium", children: change })] }));
    }
    return null;
};
const TreatmentCard = ({ alert, isPending, treatmentNotes, setTreatmentNotes, handleApplyTreatment, applyingId }) => (_jsxs(Card, { className: "hover:shadow-md transition-shadow", children: [_jsx(CardHeader, { className: "pb-3", children: _jsx("div", { className: "flex items-start justify-between gap-4", children: _jsxs("div", { className: "flex-1 space-y-2", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Badge, { variant: "outline", className: "font-mono text-xs", children: alert.risk_code }), getLikelihoodChangeIndicator(alert.suggested_likelihood_change), !isPending && (_jsxs(Badge, { className: "bg-green-600", children: [_jsx(CheckCircle2, { className: "h-3 w-3 mr-1" }), "Applied"] })), isPending && (_jsxs(Badge, { variant: "outline", className: "bg-orange-50 text-orange-700 border-orange-300", children: [_jsx(Clock, { className: "h-3 w-3 mr-1" }), "Pending Application"] }))] }), _jsx("h3", { className: "font-semibold text-sm", children: alert.risk_title || alert.risk_code }), alert.risk_description && (_jsx("p", { className: "text-xs text-gray-600 line-clamp-2", children: alert.risk_description }))] }) }) }), _jsxs(CardContent, { className: "space-y-4", children: [_jsxs("div", { className: "space-y-2", children: [_jsx("h4", { className: "text-xs font-medium text-gray-500 uppercase", children: "Triggering Event" }), _jsx("p", { className: "text-sm font-medium", children: alert.event.title }), _jsx("p", { className: "text-xs text-gray-600 line-clamp-2", children: alert.event.description })] }), _jsxs("div", { className: "space-y-2", children: [_jsx("h4", { className: "text-xs font-medium text-gray-500 uppercase", children: "AI Analysis" }), _jsx("p", { className: "text-sm text-gray-700", children: alert.reasoning })] }), _jsxs("div", { className: "space-y-2", children: [_jsx("h4", { className: "text-xs font-medium text-gray-500 uppercase", children: "Impact Assessment" }), _jsx("p", { className: "text-sm text-gray-700", children: alert.impact_assessment })] }), alert.suggested_controls && alert.suggested_controls.length > 0 && (_jsxs("div", { className: "space-y-2", children: [_jsx("h4", { className: "text-xs font-medium text-gray-500 uppercase", children: "Suggested Controls" }), _jsx("ul", { className: "text-sm space-y-1", children: alert.suggested_controls.map((control, idx) => (_jsxs("li", { className: "flex items-start gap-2", children: [_jsx("span", { className: "text-blue-600 mt-0.5", children: "\u2022" }), _jsx("span", { className: "text-gray-700", children: control })] }, idx))) })] })), !isPending && (_jsxs("div", { className: "pt-4 border-t space-y-2", children: [_jsxs("div", { className: "flex items-center gap-2 text-xs text-gray-600", children: [_jsx(Calendar, { className: "h-3 w-3" }), _jsxs("span", { children: ["Applied: ", alert.applied_at ? format(new Date(alert.applied_at), 'PPp') : 'Unknown'] })] }), alert.treatment_notes && (_jsxs("div", { className: "space-y-1", children: [_jsx("h4", { className: "text-xs font-medium text-gray-500 uppercase", children: "Treatment Notes" }), _jsx("p", { className: "text-sm text-gray-700 bg-gray-50 p-2 rounded border", children: alert.treatment_notes })] }))] })), isPending && (_jsxs("div", { className: "pt-4 border-t space-y-3", children: [_jsxs("div", { className: "space-y-2", children: [_jsx(Label, { htmlFor: `notes-${alert.id}`, className: "text-sm font-medium", children: "Treatment Notes (Optional)" }), _jsx(Textarea, { id: `notes-${alert.id}`, placeholder: "Document how you applied this alert to the risk register (e.g., updated likelihood, added controls, notified stakeholders...)", value: treatmentNotes[alert.id] || '', onChange: (e) => setTreatmentNotes(prev => ({ ...prev, [alert.id]: e.target.value })), rows: 4, className: "text-sm resize-none" })] }), _jsx("div", { className: "bg-blue-50 border border-blue-200 rounded-lg p-3", children: _jsxs("p", { className: "text-xs text-blue-900", children: [_jsx("strong", { children: "Note:" }), " This will update the risk's likelihood by ", _jsxs("strong", { children: [alert.suggested_likelihood_change > 0 ? '+' : '', alert.suggested_likelihood_change] }), " and mark the alert as applied. If multiple events affect the same risk, each likelihood change will be applied independently when you apply each alert."] }) }), _jsx(Button, { onClick: () => handleApplyTreatment(alert.id), disabled: applyingId === alert.id, className: "w-full", size: "sm", children: applyingId === alert.id ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 mr-2 animate-spin" }), "Applying..."] })) : (_jsxs(_Fragment, { children: [_jsx(CheckCircle2, { className: "h-4 w-4 mr-2" }), "Apply to Risk Register"] })) })] }))] })] }, alert.id));
export function TreatmentLog() {
    const [pendingAlerts, setPendingAlerts] = useState([]);
    const [appliedAlerts, setAppliedAlerts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('pending');
    const [treatmentNotes, setTreatmentNotes] = useState({});
    const [applyingId, setApplyingId] = useState(null);
    useEffect(() => {
        loadTreatmentData();
    }, []);
    const loadTreatmentData = async () => {
        setLoading(true);
        try {
            // Load all accepted alerts
            const { data: allAccepted } = await loadRiskAlerts('accepted');
            if (allAccepted) {
                // Filter by applied_to_risk status
                const pending = allAccepted.filter(a => !a.applied_to_risk);
                const applied = allAccepted.filter(a => a.applied_to_risk);
                setPendingAlerts(pending);
                setAppliedAlerts(applied);
            }
        }
        catch (error) {
            console.error('Error loading treatment data:', error);
        }
        finally {
            setLoading(false);
        }
    };
    const handleApplyTreatment = async (alertId) => {
        setApplyingId(alertId);
        try {
            const notes = treatmentNotes[alertId] || '';
            const result = await applyAlertTreatment(alertId, notes);
            if (result.success) {
                // Refresh data
                await loadTreatmentData();
                // Clear notes
                setTreatmentNotes(prev => {
                    const updated = { ...prev };
                    delete updated[alertId];
                    return updated;
                });
                // Switch to applied tab to see the result
                setActiveTab('applied');
            }
            else {
                alert(`Failed to apply treatment: ${result.error}`);
            }
        }
        catch (error) {
            console.error('Error applying treatment:', error);
            alert(`Error: ${error}`);
        }
        finally {
            setApplyingId(null);
        }
    };
    return (_jsxs("div", { className: "space-y-4", children: [_jsx("div", { className: "flex items-center justify-between", children: _jsxs("div", { className: "space-y-1", children: [_jsxs("h2", { className: "text-2xl font-bold flex items-center gap-2", children: [_jsx(FileCheck, { className: "h-6 w-6" }), "Treatment Log"] }), _jsx("p", { className: "text-sm text-gray-600", children: "Track and apply accepted alerts to your risk register" })] }) }), _jsxs(Tabs, { value: activeTab, onValueChange: setActiveTab, children: [_jsxs(TabsList, { className: "grid w-full grid-cols-2", children: [_jsxs(TabsTrigger, { value: "pending", className: "gap-2", children: [_jsx(Clock, { className: "h-4 w-4" }), "Pending Application", pendingAlerts.length > 0 && (_jsx(Badge, { variant: "secondary", className: "ml-1", children: pendingAlerts.length }))] }), _jsxs(TabsTrigger, { value: "applied", className: "gap-2", children: [_jsx(CheckCircle2, { className: "h-4 w-4" }), "Applied", appliedAlerts.length > 0 && (_jsx(Badge, { variant: "secondary", className: "ml-1", children: appliedAlerts.length }))] })] }), _jsx(TabsContent, { value: "pending", className: "space-y-4", children: loading ? (_jsx(Card, { children: _jsx(CardContent, { className: "flex items-center justify-center py-12", children: _jsx(Loader2, { className: "h-8 w-8 animate-spin text-gray-400" }) }) })) : pendingAlerts.length === 0 ? (_jsx(Card, { children: _jsxs(CardContent, { className: "flex flex-col items-center justify-center py-12 text-center", children: [_jsx(CheckCircle2, { className: "h-12 w-12 text-green-500 mb-4" }), _jsx("h3", { className: "text-lg font-semibold mb-2", children: "All Caught Up!" }), _jsx("p", { className: "text-sm text-gray-600", children: "No accepted alerts are pending application to the risk register." })] }) })) : (_jsxs("div", { className: "space-y-4", children: [_jsx("div", { className: "bg-orange-50 border border-orange-200 rounded-lg p-4", children: _jsxs("div", { className: "flex items-start gap-3", children: [_jsx(AlertTriangle, { className: "h-5 w-5 text-orange-600 mt-0.5" }), _jsxs("div", { className: "flex-1 space-y-1", children: [_jsx("h4", { className: "text-sm font-medium text-orange-900", children: "Action Required" }), _jsxs("p", { className: "text-sm text-orange-800", children: [pendingAlerts.length, " accepted ", pendingAlerts.length === 1 ? 'alert' : 'alerts', " waiting to be applied to the risk register. Review the details below and click \"Apply to Risk Register\" to update the corresponding risk."] })] })] }) }), pendingAlerts.map(alert => (_jsx(TreatmentCard, { alert: alert, isPending: true, treatmentNotes: treatmentNotes, setTreatmentNotes: setTreatmentNotes, handleApplyTreatment: handleApplyTreatment, applyingId: applyingId }, alert.id)))] })) }), _jsx(TabsContent, { value: "applied", className: "space-y-4", children: loading ? (_jsx(Card, { children: _jsx(CardContent, { className: "flex items-center justify-center py-12", children: _jsx(Loader2, { className: "h-8 w-8 animate-spin text-gray-400" }) }) })) : appliedAlerts.length === 0 ? (_jsx(Card, { children: _jsxs(CardContent, { className: "flex flex-col items-center justify-center py-12 text-center", children: [_jsx(FileCheck, { className: "h-12 w-12 text-gray-400 mb-4" }), _jsx("h3", { className: "text-lg font-semibold mb-2", children: "No Applied Treatments Yet" }), _jsx("p", { className: "text-sm text-gray-600", children: "Alerts you apply to the risk register will appear here with their treatment history." })] }) })) : (_jsx("div", { className: "space-y-4", children: appliedAlerts.map(alert => (_jsx(TreatmentCard, { alert: alert, isPending: false, treatmentNotes: treatmentNotes, setTreatmentNotes: setTreatmentNotes, handleApplyTreatment: handleApplyTreatment, applyingId: applyingId }, alert.id))) })) })] })] }));
}
