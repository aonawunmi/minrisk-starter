import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// src/components/intelligence/IntelligenceDashboard.tsx
// Main dashboard widget for Risk Intelligence Monitor
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../ui/dialog';
import { Checkbox } from '../ui/checkbox';
import { Label } from '../ui/label';
import { Switch } from '../ui/switch';
import { Slider } from '../ui/slider';
import { Brain, AlertTriangle, CheckCircle2, XCircle, Clock, Loader2, RefreshCw, TrendingUp, Rss, Database, Settings, Tag, Trash2, FileCheck, } from 'lucide-react';
import { loadRiskAlerts, getAlertsStatistics, bulkDeletePendingAlerts, } from '../../lib/riskIntelligence';
import { IntelligenceAlertCard } from './IntelligenceAlertCard';
import { AlertReviewDialog } from './AlertReviewDialog';
import { ScanResultsDialog } from './ScanResultsDialog';
import { EventBrowser } from './EventBrowser';
import { NewsSourcesManager } from './NewsSourcesManager';
import { RiskKeywordsManager } from './RiskKeywordsManager';
import { TreatmentLog } from './TreatmentLog';
import { supabase } from '../../lib/supabase';
import { loadConfig, saveConfig } from '../../lib/database';
export function IntelligenceDashboard({ riskCode }) {
    const [alerts, setAlerts] = useState([]);
    const [filteredAlerts, setFilteredAlerts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeFilter, setActiveFilter] = useState('all');
    const [selectedAlert, setSelectedAlert] = useState(null);
    const [showReviewDialog, setShowReviewDialog] = useState(false);
    const [scanning, setScanning] = useState(false);
    const [scanMessage, setScanMessage] = useState('');
    const [showScanResults, setShowScanResults] = useState(false);
    const [scanResults, setScanResults] = useState([]);
    const [scanStats, setScanStats] = useState(null);
    const [showEventBrowser, setShowEventBrowser] = useState(false);
    const [showSourcesManager, setShowSourcesManager] = useState(false);
    const [showKeywordsManager, setShowKeywordsManager] = useState(false);
    const [analyzing, setAnalyzing] = useState(false);
    const [analyzeMessage, setAnalyzeMessage] = useState('');
    const [resetting, setResetting] = useState(false);
    const [resetMessage, setResetMessage] = useState('');
    const [bulkDeleting, setBulkDeleting] = useState(false);
    const [bulkDeleteMessage, setBulkDeleteMessage] = useState('');
    const [statistics, setStatistics] = useState({
        total: 0,
        pending: 0,
        accepted: 0,
        rejected: 0,
        high_confidence: 0,
    });
    const [showKeywordDialog, setShowKeywordDialog] = useState(false);
    const [availableKeywords, setAvailableKeywords] = useState([]);
    const [selectedKeywords, setSelectedKeywords] = useState([]);
    const [loadingKeywords, setLoadingKeywords] = useState(false);
    // Scanner configuration state
    const [scannerMode, setScannerMode] = useState('ai');
    const [confidenceThreshold, setConfidenceThreshold] = useState(0.6);
    const [savingConfig, setSavingConfig] = useState(false);
    const [configMessage, setConfigMessage] = useState('');
    const [mainTab, setMainTab] = useState('alerts');
    useEffect(() => {
        loadData();
        loadStats();
        loadScannerConfig();
    }, [riskCode]);
    useEffect(() => {
        filterAlerts();
    }, [alerts, activeFilter]);
    const loadData = async () => {
        setLoading(true);
        const { data, error } = await loadRiskAlerts(undefined, riskCode);
        if (!error && data) {
            setAlerts(data);
        }
        else {
            console.error('Error loading alerts:', error);
        }
        setLoading(false);
    };
    const loadStats = async () => {
        const { data, error } = await getAlertsStatistics();
        if (!error && data) {
            setStatistics(data);
        }
    };
    const filterAlerts = () => {
        if (activeFilter === 'all') {
            setFilteredAlerts(alerts);
        }
        else {
            setFilteredAlerts(alerts.filter(a => a.status === activeFilter));
        }
    };
    const handleReview = (alert) => {
        setSelectedAlert(alert);
        setShowReviewDialog(true);
    };
    const handleUpdate = () => {
        loadData();
        loadStats();
    };
    const loadAvailableKeywords = async () => {
        setLoadingKeywords(true);
        try {
            const { data: { user } } = await supabase.auth.getUser();
            if (!user)
                return;
            // Get user's organization_id
            const { data: profile } = await supabase
                .from('user_profiles')
                .select('organization_id')
                .eq('id', user.id)
                .single();
            if (!profile)
                return;
            // Load active keywords for this organization
            const { data: keywords, error } = await supabase
                .from('risk_keywords')
                .select('id, keyword, category')
                .eq('organization_id', profile.organization_id)
                .eq('is_active', true)
                .order('category', { ascending: true })
                .order('keyword', { ascending: true });
            if (!error && keywords) {
                setAvailableKeywords(keywords);
                // Select all keywords by default
                setSelectedKeywords(keywords.map(k => k.keyword));
            }
        }
        catch (error) {
            console.error('Error loading keywords:', error);
        }
        finally {
            setLoadingKeywords(false);
        }
    };
    const handleOpenKeywordDialog = () => {
        loadAvailableKeywords();
        setShowKeywordDialog(true);
    };
    const loadScannerConfig = async () => {
        try {
            const config = await loadConfig();
            if (config) {
                setScannerMode(config.scanner_mode || 'ai');
                setConfidenceThreshold(config.scanner_confidence_threshold || 0.6);
            }
        }
        catch (error) {
            console.error('Error loading scanner config:', error);
        }
    };
    const handleSaveScannerConfig = async () => {
        setSavingConfig(true);
        setConfigMessage('Saving configuration...');
        try {
            const config = await loadConfig();
            if (!config) {
                setConfigMessage('❌ Failed to load configuration');
                setTimeout(() => setConfigMessage(''), 5000);
                setSavingConfig(false);
                return;
            }
            const updatedConfig = {
                ...config,
                scanner_mode: scannerMode,
                scanner_confidence_threshold: confidenceThreshold,
            };
            const result = await saveConfig(updatedConfig);
            if (result.success) {
                setConfigMessage('✅ Scanner configuration saved successfully');
            }
            else {
                setConfigMessage(`❌ Failed to save configuration: ${result.error}`);
            }
            setTimeout(() => setConfigMessage(''), 5000);
        }
        catch (error) {
            console.error('Error saving scanner config:', error);
            setConfigMessage(`❌ Error: ${error}`);
            setTimeout(() => setConfigMessage(''), 5000);
        }
        finally {
            setSavingConfig(false);
        }
    };
    const handleScanNews = async (keywordsToUse) => {
        setScanning(true);
        setScanMessage('Scanning news feeds...');
        try {
            // Get user session for auth
            const { data: { session } } = await supabase.auth.getSession();
            if (!session) {
                setScanMessage('❌ Not authenticated. Please log in.');
                setScanning(false);
                return;
            }
            // Call backend API endpoint instead of running scanner in browser
            const response = await fetch('/api/scan-news', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${session.access_token}`,
                },
                body: JSON.stringify({
                    selectedKeywords: keywordsToUse,
                }),
            });
            const result = await response.json();
            if (result.success) {
                // Store scan results and stats
                setScanResults(result.scanResults || []);
                setScanStats(result.stats);
                setScanMessage(`✅ Scan complete! Processed ${result.stats.feeds_processed} feeds, ` +
                    `found ${result.stats.events_found} events, ` +
                    `stored ${result.stats.events_stored} events, ` +
                    `created ${result.stats.alerts_created} alerts.`);
                // Show scan results dialog
                setShowScanResults(true);
                // Reload data after a short delay
                setTimeout(() => {
                    loadData();
                    loadStats();
                }, 1000);
            }
            else {
                setScanMessage(`❌ Scan failed: ${result.error || 'Unknown error'}`);
            }
        }
        catch (error) {
            console.error('Error running news scanner:', error);
            setScanMessage('❌ Error connecting to news scanner API. Check console for details.');
        }
        finally {
            setScanning(false);
        }
    };
    const getFilterCount = (filter) => {
        if (filter === 'all')
            return alerts.length;
        return alerts.filter(a => a.status === filter).length;
    };
    const handleRetainEvent = async (item) => {
        try {
            const response = await fetch('/api/scan-news', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'retain',
                    eventData: item,
                }),
            });
            const result = await response.json();
            if (result.success) {
                setScanMessage('✅ Event saved successfully!');
                setTimeout(() => setScanMessage(''), 3000);
                return true;
            }
            else {
                setScanMessage(`❌ Failed to save event: ${result.error}`);
                setTimeout(() => setScanMessage(''), 5000);
                return false;
            }
        }
        catch (error) {
            console.error('Error retaining event:', error);
            setScanMessage('❌ Error saving event. Check console for details.');
            setTimeout(() => setScanMessage(''), 5000);
            return false;
        }
    };
    const handleAnalyzeExisting = async () => {
        setAnalyzing(true);
        setAnalyzeMessage('Analyzing existing events...');
        try {
            // Get user session for auth
            const { data: { session } } = await supabase.auth.getSession();
            if (!session) {
                setAnalyzeMessage('❌ Not authenticated. Please log in.');
                setAnalyzing(false);
                return;
            }
            const response = await fetch('/api/scan-news', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${session.access_token}`,
                },
                body: JSON.stringify({
                    action: 'analyzeExisting',
                }),
            });
            const result = await response.json();
            if (result.success) {
                setAnalyzeMessage(`✅ Analysis complete! Analyzed ${result.events_analyzed} events, ` +
                    `created ${result.alerts_created} alerts.`);
                // Reload data after a short delay
                setTimeout(() => {
                    loadData();
                    loadStats();
                    setAnalyzeMessage('');
                }, 3000);
            }
            else {
                setAnalyzeMessage(`❌ Analysis failed: ${result.error || 'Unknown error'}`);
                setTimeout(() => setAnalyzeMessage(''), 5000);
            }
        }
        catch (error) {
            console.error('Error analyzing events:', error);
            setAnalyzeMessage('❌ Error analyzing events. Check console for details.');
            setTimeout(() => setAnalyzeMessage(''), 5000);
        }
        finally {
            setAnalyzing(false);
        }
    };
    const handleResetAnalysis = async () => {
        if (!confirm('This will reset all analyzed events so they can be re-analyzed. ' +
            'Use this if you\'ve added new risks and want to re-match existing events. Continue?'))
            return;
        setResetting(true);
        setResetMessage('Resetting analysis timestamps...');
        try {
            // Get user session for auth
            const { data: { session } } = await supabase.auth.getSession();
            if (!session) {
                setResetMessage('❌ Not authenticated. Please log in.');
                setResetting(false);
                return;
            }
            const response = await fetch('/api/scan-news', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${session.access_token}`,
                },
                body: JSON.stringify({
                    action: 'resetAnalysis',
                }),
            });
            const result = await response.json();
            if (result.success) {
                setResetMessage(`✅ Reset ${result.events_reset} events. Click "Analyze Events" to re-analyze.`);
                setTimeout(() => {
                    setResetMessage('');
                }, 5000);
            }
            else {
                setResetMessage(`❌ Reset failed: ${result.error || 'Unknown error'}`);
                setTimeout(() => setResetMessage(''), 5000);
            }
        }
        catch (error) {
            console.error('Error resetting analysis:', error);
            setResetMessage('❌ Error resetting analysis. Check console for details.');
            setTimeout(() => setResetMessage(''), 5000);
        }
        finally {
            setResetting(false);
        }
    };
    const handleBulkDeletePending = async () => {
        if (!confirm('This will delete ALL pending alerts. This action cannot be undone. Continue?'))
            return;
        setBulkDeleting(true);
        setBulkDeleteMessage('Deleting pending alerts...');
        const { success, count, error } = await bulkDeletePendingAlerts();
        if (success) {
            setBulkDeleteMessage(`✅ Deleted ${count} pending alerts`);
            setTimeout(() => {
                setBulkDeleteMessage('');
                loadData();
                loadStats();
            }, 2000);
        }
        else {
            setBulkDeleteMessage(`❌ Failed to delete alerts: ${error}`);
            setTimeout(() => setBulkDeleteMessage(''), 5000);
        }
        setBulkDeleting(false);
    };
    if (loading) {
        return (_jsx(Card, { children: _jsxs(CardContent, { className: "flex items-center justify-center py-12", children: [_jsx(Loader2, { className: "h-8 w-8 animate-spin text-gray-400" }), _jsx("span", { className: "ml-3 text-gray-500", children: "Loading intelligence alerts..." })] }) }));
    }
    return (_jsxs("div", { className: "space-y-4", children: [_jsxs(Card, { children: [_jsxs(CardHeader, { children: [_jsxs(CardTitle, { className: "text-lg flex items-center gap-2", children: [_jsx(Settings, { className: "h-5 w-5" }), "Scanner Configuration"] }), _jsx(CardDescription, { children: "Configure how the news scanner analyzes and filters events for risk intelligence" })] }), _jsxs(CardContent, { className: "space-y-6", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { className: "space-y-1", children: [_jsx(Label, { htmlFor: "scanner-mode", className: "text-base font-medium", children: "Scanning Mode" }), _jsx("p", { className: "text-sm text-gray-500", children: scannerMode === 'ai'
                                                    ? 'Claude AI analyzes events with confidence scoring'
                                                    : 'Simple keyword matching against your risk keywords' })] }), _jsxs("div", { className: "flex items-center gap-3", children: [_jsx("span", { className: `text-sm ${scannerMode === 'keyword' ? 'font-semibold text-blue-600' : 'text-gray-500'}`, children: "Keyword Matching" }), _jsx(Switch, { id: "scanner-mode", checked: scannerMode === 'ai', onCheckedChange: (checked) => setScannerMode(checked ? 'ai' : 'keyword') }), _jsx("span", { className: `text-sm ${scannerMode === 'ai' ? 'font-semibold text-purple-600' : 'text-gray-500'}`, children: "Claude AI" })] })] }), scannerMode === 'ai' && (_jsxs("div", { className: "space-y-3 pt-4 border-t", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsxs(Label, { htmlFor: "confidence-threshold", className: "text-base font-medium", children: ["AI Confidence Threshold: ", (confidenceThreshold * 100).toFixed(0), "%"] }), _jsxs("span", { className: "text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded", children: [confidenceThreshold <= 0.3 && 'Very Lenient', confidenceThreshold > 0.3 && confidenceThreshold <= 0.5 && 'Lenient', confidenceThreshold > 0.5 && confidenceThreshold <= 0.7 && 'Balanced', confidenceThreshold > 0.7 && confidenceThreshold <= 0.85 && 'Restrictive', confidenceThreshold > 0.85 && 'Very Restrictive'] })] }), _jsx("p", { className: "text-sm text-gray-500", children: "Lower values catch more events (more lenient), higher values only catch high-confidence events (more restrictive)" }), _jsxs("div", { className: "flex items-center gap-4", children: [_jsx("span", { className: "text-xs text-gray-400 whitespace-nowrap", children: "More Events" }), _jsx(Slider, { id: "confidence-threshold", min: 0, max: 1, step: 0.05, value: [confidenceThreshold], onValueChange: (value) => setConfidenceThreshold(value[0]), className: "flex-1" }), _jsx("span", { className: "text-xs text-gray-400 whitespace-nowrap", children: "Fewer Events" })] }), _jsxs("div", { className: "flex justify-between text-xs text-gray-400", children: [_jsx("span", { children: "0%" }), _jsx("span", { children: "25%" }), _jsx("span", { children: "50%" }), _jsx("span", { children: "75%" }), _jsx("span", { children: "100%" })] })] })), _jsxs("div", { className: "flex items-center gap-3 pt-4 border-t", children: [_jsx(Button, { onClick: handleSaveScannerConfig, disabled: savingConfig, size: "sm", children: savingConfig ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 mr-2 animate-spin" }), "Saving..."] })) : (_jsxs(_Fragment, { children: [_jsx(CheckCircle2, { className: "h-4 w-4 mr-2" }), "Save Configuration"] })) }), configMessage && (_jsx("span", { className: "text-sm text-gray-600", children: configMessage }))] })] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { children: _jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { className: "flex items-center gap-3", children: [_jsx("div", { className: "p-2 bg-purple-100 rounded-lg", children: _jsx(Brain, { className: "h-6 w-6 text-purple-600" }) }), _jsxs("div", { children: [_jsx(CardTitle, { className: "text-lg", children: "Risk Intelligence Monitor" }), _jsx("p", { className: "text-sm text-gray-500 mt-1", children: "AI-powered risk intelligence from global news sources" })] })] }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Button, { variant: "outline", size: "sm", onClick: () => setShowKeywordsManager(!showKeywordsManager), title: "Manage Risk Keywords", children: _jsx(Tag, { className: "h-4 w-4" }) }), _jsx(Button, { variant: "outline", size: "sm", onClick: () => setShowSourcesManager(!showSourcesManager), title: "Manage News Sources", children: _jsx(Settings, { className: "h-4 w-4" }) }), _jsx(Button, { variant: "outline", size: "sm", onClick: () => setShowEventBrowser(!showEventBrowser), title: "Browse Stored Events", children: _jsx(Database, { className: "h-4 w-4" }) }), _jsx(Button, { variant: "default", size: "sm", onClick: handleOpenKeywordDialog, disabled: scanning, children: scanning ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 mr-2 animate-spin" }), "Scanning..."] })) : (_jsxs(_Fragment, { children: [_jsx(Rss, { className: "h-4 w-4 mr-2" }), "Scan News"] })) }), _jsx(Button, { variant: "secondary", size: "sm", onClick: handleAnalyzeExisting, disabled: analyzing, title: "Analyze existing unanalyzed events for risk alerts", children: analyzing ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 mr-2 animate-spin" }), "Analyzing..."] })) : (_jsxs(_Fragment, { children: [_jsx(Brain, { className: "h-4 w-4 mr-2" }), "Analyze Events"] })) }), _jsx(Button, { variant: "outline", size: "sm", onClick: handleResetAnalysis, disabled: resetting, title: "Reset analyzed events to re-analyze them (useful after adding new risks)", children: resetting ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 mr-2 animate-spin" }), "Resetting..."] })) : (_jsxs(_Fragment, { children: [_jsx(RefreshCw, { className: "h-4 w-4 mr-2" }), "Reset Analysis"] })) }), _jsxs(Button, { variant: "outline", size: "sm", onClick: handleUpdate, children: [_jsx(RefreshCw, { className: "h-4 w-4 mr-2" }), "Refresh"] }), statistics.pending > 0 && (_jsx(Button, { variant: "destructive", size: "sm", onClick: handleBulkDeletePending, disabled: bulkDeleting, title: "Delete all pending alerts", children: bulkDeleting ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 mr-2 animate-spin" }), "Deleting..."] })) : (_jsxs(_Fragment, { children: [_jsx(Trash2, { className: "h-4 w-4 mr-2" }), "Delete All Pending"] })) }))] })] }) }), _jsxs(CardContent, { children: [_jsxs("div", { className: "grid grid-cols-2 md:grid-cols-5 gap-4", children: [_jsxs("div", { className: "flex flex-col", children: [_jsx("span", { className: "text-2xl font-bold text-gray-900", children: statistics.total }), _jsx("span", { className: "text-xs text-gray-500", children: "Total Alerts" })] }), _jsxs("div", { className: "flex flex-col", children: [_jsx("span", { className: "text-2xl font-bold text-yellow-600", children: statistics.pending }), _jsxs("span", { className: "text-xs text-gray-500 flex items-center gap-1", children: [_jsx(Clock, { className: "h-3 w-3" }), "Pending"] })] }), _jsxs("div", { className: "flex flex-col", children: [_jsx("span", { className: "text-2xl font-bold text-green-600", children: statistics.accepted }), _jsxs("span", { className: "text-xs text-gray-500 flex items-center gap-1", children: [_jsx(CheckCircle2, { className: "h-3 w-3" }), "Accepted"] })] }), _jsxs("div", { className: "flex flex-col", children: [_jsx("span", { className: "text-2xl font-bold text-red-600", children: statistics.rejected }), _jsxs("span", { className: "text-xs text-gray-500 flex items-center gap-1", children: [_jsx(XCircle, { className: "h-3 w-3" }), "Rejected"] })] }), _jsxs("div", { className: "flex flex-col", children: [_jsx("span", { className: "text-2xl font-bold text-blue-600", children: statistics.high_confidence }), _jsxs("span", { className: "text-xs text-gray-500 flex items-center gap-1", children: [_jsx(TrendingUp, { className: "h-3 w-3" }), "High Confidence"] })] })] }), scanMessage && (_jsx("div", { className: "mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg text-sm text-blue-900", children: scanMessage })), analyzeMessage && (_jsx("div", { className: "mt-4 p-3 bg-purple-50 border border-purple-200 rounded-lg text-sm text-purple-900", children: analyzeMessage })), resetMessage && (_jsx("div", { className: "mt-4 p-3 bg-orange-50 border border-orange-200 rounded-lg text-sm text-orange-900", children: resetMessage })), bulkDeleteMessage && (_jsx("div", { className: "mt-4 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-900", children: bulkDeleteMessage }))] })] }), _jsx(Card, { children: _jsx(CardHeader, { className: "pb-3", children: _jsxs(Tabs, { value: mainTab, onValueChange: (v) => setMainTab(v), children: [_jsxs(TabsList, { className: "grid w-full grid-cols-2", children: [_jsxs(TabsTrigger, { value: "alerts", className: "gap-2", children: [_jsx(Brain, { className: "h-4 w-4" }), "Intelligence Alerts", alerts.length > 0 && (_jsx(Badge, { variant: "secondary", className: "ml-1", children: alerts.length }))] }), _jsxs(TabsTrigger, { value: "treatment", className: "gap-2", children: [_jsx(FileCheck, { className: "h-4 w-4" }), "Treatment Log"] })] }), _jsxs(TabsContent, { value: "alerts", className: "mt-4 space-y-4", children: [_jsx(Tabs, { value: activeFilter, onValueChange: (v) => setActiveFilter(v), children: _jsxs(TabsList, { children: [_jsxs(TabsTrigger, { value: "all", className: "relative", children: ["All", getFilterCount('all') > 0 && (_jsx(Badge, { variant: "secondary", className: "ml-2 h-5 px-1.5 text-xs", children: getFilterCount('all') }))] }), _jsxs(TabsTrigger, { value: "pending", className: "relative", children: [_jsx(Clock, { className: "h-3 w-3 mr-1" }), "Pending", getFilterCount('pending') > 0 && (_jsx(Badge, { className: "ml-2 h-5 px-1.5 text-xs bg-yellow-600", children: getFilterCount('pending') }))] }), _jsxs(TabsTrigger, { value: "accepted", children: [_jsx(CheckCircle2, { className: "h-3 w-3 mr-1" }), "Accepted", getFilterCount('accepted') > 0 && (_jsx(Badge, { variant: "secondary", className: "ml-2 h-5 px-1.5 text-xs", children: getFilterCount('accepted') }))] }), _jsxs(TabsTrigger, { value: "rejected", children: [_jsx(XCircle, { className: "h-3 w-3 mr-1" }), "Rejected", getFilterCount('rejected') > 0 && (_jsx(Badge, { variant: "secondary", className: "ml-2 h-5 px-1.5 text-xs", children: getFilterCount('rejected') }))] })] }) }), _jsx("div", { className: "mt-4", children: filteredAlerts.length === 0 ? (_jsxs("div", { className: "text-center py-12 bg-gray-50 rounded-lg border border-gray-200", children: [_jsx(AlertTriangle, { className: "h-12 w-12 mx-auto mb-3 text-gray-300" }), _jsx("p", { className: "text-sm text-gray-500", children: activeFilter === 'all'
                                                        ? 'No intelligence alerts yet'
                                                        : `No ${activeFilter} alerts` }), _jsx("p", { className: "text-xs text-gray-400 mt-1", children: activeFilter === 'pending'
                                                        ? 'Alerts will appear here when events are detected'
                                                        : 'Check back later for updates' })] })) : (_jsx("div", { className: "space-y-3", children: filteredAlerts.map(alert => (_jsx(IntelligenceAlertCard, { alert: alert, onReview: handleReview }, alert.id))) })) })] }), _jsx(TabsContent, { value: "treatment", className: "mt-4", children: _jsx(TreatmentLog, {}) })] }) }) }), showEventBrowser && (_jsx(EventBrowser, {})), showSourcesManager && (_jsx(NewsSourcesManager, {})), showKeywordsManager && (_jsx(RiskKeywordsManager, {})), _jsx(AlertReviewDialog, { alert: selectedAlert, open: showReviewDialog, onClose: () => {
                    setShowReviewDialog(false);
                    setSelectedAlert(null);
                }, onUpdate: handleUpdate }), scanStats && (_jsx(ScanResultsDialog, { open: showScanResults, onClose: () => setShowScanResults(false), results: scanResults, stats: scanStats, onRetain: handleRetainEvent })), _jsx(Dialog, { open: showKeywordDialog, onOpenChange: setShowKeywordDialog, children: _jsxs(DialogContent, { className: "max-w-2xl max-h-[80vh] overflow-y-auto", children: [_jsxs(DialogHeader, { children: [_jsx(DialogTitle, { children: "Select Risk Keywords for Scanning" }), _jsx(DialogDescription, { children: "Choose which keywords to use when scanning news feeds. By default, all active keywords are selected." })] }), loadingKeywords ? (_jsxs("div", { className: "flex items-center justify-center py-8", children: [_jsx(Loader2, { className: "h-6 w-6 animate-spin text-gray-400 mr-2" }), _jsx("span", { className: "text-sm text-gray-500", children: "Loading keywords..." })] })) : (_jsxs("div", { className: "space-y-4", children: [_jsxs("div", { className: "flex items-center gap-4 pb-3 border-b", children: [_jsx(Button, { variant: "outline", size: "sm", onClick: () => setSelectedKeywords(availableKeywords.map(k => k.keyword)), children: "Select All" }), _jsx(Button, { variant: "outline", size: "sm", onClick: () => setSelectedKeywords([]), children: "Deselect All" }), _jsxs("span", { className: "text-sm text-gray-500 ml-auto", children: [selectedKeywords.length, " of ", availableKeywords.length, " selected"] })] }), availableKeywords.length === 0 ? (_jsx("div", { className: "text-center py-8 text-sm text-gray-500", children: "No active keywords found. Please add keywords in the Keywords Manager." })) : (_jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: Object.entries(availableKeywords.reduce((acc, kw) => {
                                        if (!acc[kw.category])
                                            acc[kw.category] = [];
                                        acc[kw.category].push(kw);
                                        return acc;
                                    }, {})).map(([category, keywords]) => (_jsxs("div", { className: "space-y-2", children: [_jsx("h4", { className: "font-semibold text-sm text-gray-700 capitalize", children: category }), _jsx("div", { className: "space-y-2 pl-2", children: keywords.map((kw) => (_jsxs("div", { className: "flex items-center space-x-2", children: [_jsx(Checkbox, { id: `kw-${kw.id}`, checked: selectedKeywords.includes(kw.keyword), onCheckedChange: (checked) => {
                                                                if (checked) {
                                                                    setSelectedKeywords([...selectedKeywords, kw.keyword]);
                                                                }
                                                                else {
                                                                    setSelectedKeywords(selectedKeywords.filter(k => k !== kw.keyword));
                                                                }
                                                            } }), _jsx(Label, { htmlFor: `kw-${kw.id}`, className: "text-sm cursor-pointer", children: kw.keyword })] }, kw.id))) })] }, category))) }))] })), _jsxs(DialogFooter, { children: [_jsx(Button, { variant: "outline", onClick: () => {
                                        setShowKeywordDialog(false);
                                        setSelectedKeywords([]);
                                    }, children: "Cancel" }), _jsxs(Button, { onClick: () => {
                                        setShowKeywordDialog(false);
                                        handleScanNews(selectedKeywords.length > 0 ? selectedKeywords : undefined);
                                    }, disabled: selectedKeywords.length === 0, children: [_jsx(Rss, { className: "h-4 w-4 mr-2" }), "Scan with ", selectedKeywords.length, " Keyword", selectedKeywords.length !== 1 ? 's' : ''] })] })] }) })] }));
}
