import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// src/components/intelligence/EventBrowser.tsx
// Browse and manage stored external events
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, } from '../ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, } from '../ui/dialog';
import { ExternalLink, Search, Trash2, Eye, Calendar, Globe, Tag, Loader2, RefreshCw, } from 'lucide-react';
import { supabase } from '../../lib/supabase';
export function EventBrowser() {
    const [events, setEvents] = useState([]);
    const [filteredEvents, setFilteredEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [categoryFilter, setCategoryFilter] = useState('all');
    const [sourceFilter, setSourceFilter] = useState('all');
    const [selectedEvent, setSelectedEvent] = useState(null);
    const [showDetailDialog, setShowDetailDialog] = useState(false);
    const [deleting, setDeleting] = useState(null);
    const [clearing, setClearing] = useState(false);
    const [clearMessage, setClearMessage] = useState('');
    useEffect(() => {
        loadEvents();
    }, []);
    useEffect(() => {
        filterEvents();
    }, [events, searchQuery, categoryFilter, sourceFilter]);
    const loadEvents = async () => {
        setLoading(true);
        try {
            // Get current user's organization_id
            const { data: profile } = await supabase
                .from('user_profiles')
                .select('organization_id')
                .eq('id', (await supabase.auth.getUser()).data.user?.id)
                .single();
            if (!profile) {
                console.error('User profile not found');
                setLoading(false);
                return;
            }
            const { data, error } = await supabase
                .from('external_events')
                .select('*')
                .eq('organization_id', profile.organization_id) // CRITICAL: Filter by organization
                .order('published_date', { ascending: false })
                .limit(100);
            if (error)
                throw error;
            setEvents(data || []);
        }
        catch (error) {
            console.error('Error loading events:', error);
        }
        finally {
            setLoading(false);
        }
    };
    const filterEvents = () => {
        let filtered = events;
        // Search filter
        if (searchQuery) {
            const query = searchQuery.toLowerCase();
            filtered = filtered.filter((e) => e.title.toLowerCase().includes(query) ||
                e.description.toLowerCase().includes(query) ||
                e.source_name.toLowerCase().includes(query));
        }
        // Category filter
        if (categoryFilter !== 'all') {
            filtered = filtered.filter((e) => e.event_category === categoryFilter);
        }
        // Source filter
        if (sourceFilter !== 'all') {
            filtered = filtered.filter((e) => e.source_name === sourceFilter);
        }
        setFilteredEvents(filtered);
    };
    const handleDelete = async (eventId) => {
        if (!confirm('Are you sure you want to delete this event?'))
            return;
        setDeleting(eventId);
        try {
            // Get current user's organization_id
            const { data: profile } = await supabase
                .from('user_profiles')
                .select('organization_id')
                .eq('id', (await supabase.auth.getUser()).data.user?.id)
                .single();
            if (!profile) {
                alert('User profile not found');
                setDeleting(null);
                return;
            }
            const { error } = await supabase
                .from('external_events')
                .delete()
                .eq('id', eventId)
                .eq('organization_id', profile.organization_id); // CRITICAL: Only delete from own org
            if (error)
                throw error;
            // Remove from local state
            setEvents(events.filter((e) => e.id !== eventId));
        }
        catch (error) {
            console.error('Error deleting event:', error);
            alert('Failed to delete event');
        }
        finally {
            setDeleting(null);
        }
    };
    const handleViewDetails = (event) => {
        setSelectedEvent(event);
        setShowDetailDialog(true);
    };
    const handleClearUnanalyzed = async () => {
        if (!confirm('This will delete all events that haven\'t been analyzed yet. ' +
            'Events that have been analyzed and created alerts will NOT be deleted. Continue?'))
            return;
        setClearing(true);
        setClearMessage('Clearing unanalyzed events...');
        try {
            // Get auth session
            const { data: { session } } = await supabase.auth.getSession();
            if (!session) {
                setClearMessage('❌ Not authenticated. Please log in.');
                setTimeout(() => setClearMessage(''), 5000);
                setClearing(false);
                return;
            }
            const response = await fetch('/api/scan-news', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${session.access_token}`,
                },
                body: JSON.stringify({
                    action: 'clearUnanalyzed',
                }),
            });
            const result = await response.json();
            if (result.success) {
                setClearMessage(`✅ Cleared ${result.events_cleared} unanalyzed events`);
                setTimeout(() => {
                    loadEvents();
                    setClearMessage('');
                }, 2000);
            }
            else {
                setClearMessage(`❌ Failed: ${result.error}`);
                setTimeout(() => setClearMessage(''), 5000);
            }
        }
        catch (error) {
            console.error('Error clearing events:', error);
            setClearMessage('❌ Error clearing events. Check console for details.');
            setTimeout(() => setClearMessage(''), 5000);
        }
        finally {
            setClearing(false);
        }
    };
    const handleClearAll = async () => {
        if (!confirm('⚠️ WARNING: This will delete ALL stored events, including analyzed ones. ' +
            'This action cannot be undone. Continue?'))
            return;
        setClearing(true);
        setClearMessage('Clearing all events...');
        try {
            // Get auth session
            const { data: { session } } = await supabase.auth.getSession();
            if (!session) {
                setClearMessage('❌ Not authenticated. Please log in.');
                setTimeout(() => setClearMessage(''), 5000);
                setClearing(false);
                return;
            }
            const response = await fetch('/api/scan-news', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${session.access_token}`,
                },
                body: JSON.stringify({
                    action: 'clearAll',
                }),
            });
            const result = await response.json();
            if (result.success) {
                setClearMessage(`✅ Cleared ${result.events_cleared} events`);
                setTimeout(() => {
                    loadEvents();
                    setClearMessage('');
                }, 2000);
            }
            else {
                setClearMessage(`❌ Failed: ${result.error}`);
                setTimeout(() => setClearMessage(''), 5000);
            }
        }
        catch (error) {
            console.error('Error clearing all events:', error);
            setClearMessage('❌ Error clearing events. Check console for details.');
            setTimeout(() => setClearMessage(''), 5000);
        }
        finally {
            setClearing(false);
        }
    };
    const uniqueSources = [...new Set(events.map((e) => e.source_name))].sort();
    const categories = ['all', 'cybersecurity', 'regulatory', 'market', 'environmental', 'operational', 'other'];
    const getCategoryColor = (category) => {
        const colors = {
            cybersecurity: 'bg-red-100 text-red-800',
            regulatory: 'bg-blue-100 text-blue-800',
            market: 'bg-green-100 text-green-800',
            environmental: 'bg-emerald-100 text-emerald-800',
            operational: 'bg-orange-100 text-orange-800',
            other: 'bg-gray-100 text-gray-800',
        };
        return colors[category] || colors.other;
    };
    if (loading) {
        return (_jsx(Card, { children: _jsxs(CardContent, { className: "flex items-center justify-center py-12", children: [_jsx(Loader2, { className: "h-8 w-8 animate-spin text-gray-400" }), _jsx("span", { className: "ml-3 text-gray-500", children: "Loading events..." })] }) }));
    }
    return (_jsxs(_Fragment, { children: [_jsxs(Card, { children: [_jsxs(CardHeader, { children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx(CardTitle, { children: "Event Browser" }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Button, { size: "sm", variant: "outline", onClick: handleClearUnanalyzed, disabled: clearing, title: "Delete all unanalyzed events (keeps analyzed events)", children: clearing ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 mr-2 animate-spin" }), "Clearing..."] })) : (_jsxs(_Fragment, { children: [_jsx(Trash2, { className: "h-4 w-4 mr-2" }), "Clear Unanalyzed"] })) }), _jsx(Button, { size: "sm", variant: "destructive", onClick: handleClearAll, disabled: clearing, title: "Delete ALL events (complete reset)", children: clearing ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 mr-2 animate-spin" }), "Clearing..."] })) : (_jsxs(_Fragment, { children: [_jsx(Trash2, { className: "h-4 w-4 mr-2" }), "Clear All"] })) }), _jsxs(Button, { size: "sm", variant: "outline", onClick: loadEvents, children: [_jsx(RefreshCw, { className: "h-4 w-4 mr-2" }), "Refresh"] })] })] }), _jsxs("p", { className: "text-sm text-gray-500 mt-2", children: ["Browse and manage stored news events (", filteredEvents.length, " of ", events.length, ")"] }), clearMessage && (_jsx("div", { className: "mt-3 p-3 bg-blue-50 border border-blue-200 rounded-lg text-sm text-blue-900", children: clearMessage }))] }), _jsxs(CardContent, { children: [_jsxs("div", { className: "flex flex-col md:flex-row gap-3 mb-4", children: [_jsxs("div", { className: "flex-1 relative", children: [_jsx(Search, { className: "absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" }), _jsx(Input, { placeholder: "Search events...", value: searchQuery, onChange: (e) => setSearchQuery(e.target.value), className: "pl-10" })] }), _jsxs(Select, { value: categoryFilter, onValueChange: setCategoryFilter, children: [_jsx(SelectTrigger, { className: "w-full md:w-48", children: _jsx(SelectValue, { placeholder: "Category" }) }), _jsx(SelectContent, { children: categories.map((cat) => (_jsx(SelectItem, { value: cat, children: cat === 'all' ? 'All Categories' : cat }, cat))) })] }), _jsxs(Select, { value: sourceFilter, onValueChange: setSourceFilter, children: [_jsx(SelectTrigger, { className: "w-full md:w-48", children: _jsx(SelectValue, { placeholder: "Source" }) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "all", children: "All Sources" }), uniqueSources.map((source) => (_jsx(SelectItem, { value: source, children: source }, source)))] })] })] }), _jsxs("div", { className: "space-y-3 max-h-[600px] overflow-y-auto pr-2", children: [filteredEvents.map((event) => (_jsxs("div", { className: "border rounded-lg p-4 hover:border-purple-300 transition-colors", children: [_jsxs("div", { className: "flex items-start justify-between gap-3 mb-2", children: [_jsxs("div", { className: "flex-1", children: [_jsx("h4", { className: "font-semibold text-sm text-gray-900 mb-1", children: event.title }), _jsxs("div", { className: "flex items-center gap-2 text-xs text-gray-500", children: [_jsx(Globe, { className: "h-3 w-3" }), _jsx("span", { children: event.source_name }), _jsx("span", { children: "\u2022" }), _jsx(Calendar, { className: "h-3 w-3" }), _jsx("span", { children: new Date(event.published_date).toLocaleDateString() }), _jsx("span", { children: "\u2022" }), _jsx("span", { children: event.country })] })] }), _jsxs("div", { className: "flex items-center gap-1", children: [_jsx(Button, { size: "sm", variant: "ghost", onClick: () => handleViewDetails(event), children: _jsx(Eye, { className: "h-4 w-4" }) }), _jsx(Button, { size: "sm", variant: "ghost", onClick: () => window.open(event.source_url, '_blank'), children: _jsx(ExternalLink, { className: "h-4 w-4" }) }), _jsx(Button, { size: "sm", variant: "ghost", onClick: () => handleDelete(event.id), disabled: deleting === event.id, children: deleting === event.id ? (_jsx(Loader2, { className: "h-4 w-4 animate-spin" })) : (_jsx(Trash2, { className: "h-4 w-4 text-red-600" })) })] })] }), _jsx("p", { className: "text-xs text-gray-600 mb-3 line-clamp-2", children: event.description }), _jsxs("div", { className: "flex items-center gap-2 flex-wrap", children: [_jsx(Badge, { className: getCategoryColor(event.event_category), children: event.event_category }), event.keywords && event.keywords.slice(0, 3).map((keyword) => (_jsxs(Badge, { variant: "outline", className: "text-xs", children: [_jsx(Tag, { className: "h-3 w-3 mr-1" }), keyword] }, keyword))), event.keywords && event.keywords.length > 3 && (_jsxs("span", { className: "text-xs text-gray-400", children: ["+", event.keywords.length - 3, " more"] }))] })] }, event.id))), filteredEvents.length === 0 && (_jsxs("div", { className: "text-center py-12 text-gray-500", children: [_jsx(Search, { className: "h-12 w-12 mx-auto mb-3 text-gray-300" }), _jsx("p", { children: "No events found" }), (searchQuery || categoryFilter !== 'all' || sourceFilter !== 'all') && (_jsx("p", { className: "text-xs mt-1", children: "Try adjusting your filters" }))] }))] })] })] }), _jsx(Dialog, { open: showDetailDialog, onOpenChange: setShowDetailDialog, children: _jsxs(DialogContent, { className: "max-w-3xl max-h-[90vh] overflow-y-auto", children: [_jsxs(DialogHeader, { children: [_jsx(DialogTitle, { children: selectedEvent?.title }), _jsx(DialogDescription, { children: _jsxs("div", { className: "flex items-center gap-2 mt-2", children: [_jsx(Globe, { className: "h-4 w-4" }), _jsx("span", { children: selectedEvent?.source_name }), _jsx("span", { children: "\u2022" }), _jsx(Calendar, { className: "h-4 w-4" }), _jsx("span", { children: selectedEvent?.published_date &&
                                                    new Date(selectedEvent.published_date).toLocaleDateString() }), _jsx("span", { children: "\u2022" }), _jsx("span", { children: selectedEvent?.country })] }) })] }), _jsxs("div", { className: "space-y-4", children: [_jsxs("div", { children: [_jsx("h4", { className: "text-sm font-semibold mb-2", children: "Category" }), _jsx(Badge, { className: getCategoryColor(selectedEvent?.event_category || ''), children: selectedEvent?.event_category })] }), _jsxs("div", { children: [_jsx("h4", { className: "text-sm font-semibold mb-2", children: "Description" }), _jsx("p", { className: "text-sm text-gray-700", children: selectedEvent?.description })] }), selectedEvent?.keywords && selectedEvent.keywords.length > 0 && (_jsxs("div", { children: [_jsx("h4", { className: "text-sm font-semibold mb-2", children: "Risk Keywords" }), _jsx("div", { className: "flex flex-wrap gap-2", children: selectedEvent.keywords.map((keyword) => (_jsx(Badge, { variant: "outline", children: keyword }, keyword))) })] })), selectedEvent?.source_url && (_jsxs("div", { children: [_jsx("h4", { className: "text-sm font-semibold mb-2", children: "Source" }), _jsxs(Button, { variant: "outline", size: "sm", onClick: () => window.open(selectedEvent.source_url, '_blank'), children: [_jsx(ExternalLink, { className: "h-4 w-4 mr-2" }), "View Original Article"] })] }))] }), _jsx(DialogFooter, { children: _jsx(Button, { variant: "outline", onClick: () => setShowDetailDialog(false), children: "Close" }) })] }) })] }));
}
