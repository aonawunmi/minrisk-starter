import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// src/components/intelligence/NewsSourcesManager.tsx
// Manage RSS news feed sources
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, } from '../ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, } from '../ui/dialog';
import { Plus, Trash2, Edit, Globe, Check, X, Loader2, RefreshCw, AlertCircle, } from 'lucide-react';
import { supabase } from '../../lib/supabase';
export function NewsSourcesManager() {
    const [sources, setSources] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showAddDialog, setShowAddDialog] = useState(false);
    const [editingSource, setEditingSource] = useState(null);
    const [deleting, setDeleting] = useState(null);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState(null);
    const [formData, setFormData] = useState({
        name: '',
        url: '',
        category: 'business',
        country: 'Nigeria',
    });
    const categories = [
        'regulatory',
        'market',
        'business',
        'cybersecurity',
        'environmental',
        'other',
    ];
    useEffect(() => {
        loadSources();
    }, []);
    const loadSources = async () => {
        setLoading(true);
        setError(null);
        try {
            const { data, error } = await supabase
                .from('news_sources')
                .select('*')
                .order('name');
            if (error)
                throw error;
            setSources(data || []);
        }
        catch (err) {
            console.error('Error loading sources:', err);
            setError(err.message);
        }
        finally {
            setLoading(false);
        }
    };
    const handleAdd = () => {
        setEditingSource(null);
        setFormData({
            name: '',
            url: '',
            category: 'business',
            country: 'Nigeria',
        });
        setShowAddDialog(true);
    };
    const handleEdit = (source) => {
        setEditingSource(source);
        setFormData({
            name: source.name,
            url: source.url,
            category: source.category,
            country: source.country,
        });
        setShowAddDialog(true);
    };
    const handleSave = async () => {
        // Validate
        if (!formData.name || !formData.url) {
            setError('Name and URL are required');
            return;
        }
        if (!formData.url.startsWith('http')) {
            setError('URL must start with http:// or https://');
            return;
        }
        setSaving(true);
        setError(null);
        try {
            // Get user's organization_id
            const { data: profile, error: profileError } = await supabase
                .from('user_profiles')
                .select('organization_id')
                .eq('id', (await supabase.auth.getUser()).data.user?.id)
                .single();
            if (profileError)
                throw profileError;
            if (editingSource) {
                // Update existing
                const { error } = await supabase
                    .from('news_sources')
                    .update({
                    name: formData.name,
                    url: formData.url,
                    category: formData.category,
                    country: formData.country,
                })
                    .eq('id', editingSource.id);
                if (error)
                    throw error;
            }
            else {
                // Insert new
                const { error } = await supabase
                    .from('news_sources')
                    .insert({
                    organization_id: profile.organization_id,
                    name: formData.name,
                    url: formData.url,
                    category: formData.category,
                    country: formData.country,
                    is_active: true,
                    is_default: false,
                });
                if (error)
                    throw error;
            }
            setShowAddDialog(false);
            loadSources();
        }
        catch (err) {
            console.error('Error saving source:', err);
            setError(err.message);
        }
        finally {
            setSaving(false);
        }
    };
    const handleToggleActive = async (source) => {
        try {
            const { error } = await supabase
                .from('news_sources')
                .update({ is_active: !source.is_active })
                .eq('id', source.id);
            if (error)
                throw error;
            loadSources();
        }
        catch (err) {
            console.error('Error toggling source:', err);
            setError(err.message);
        }
    };
    const handleDelete = async (sourceId) => {
        if (!confirm('Are you sure you want to delete this news source?'))
            return;
        setDeleting(sourceId);
        try {
            const { error } = await supabase
                .from('news_sources')
                .delete()
                .eq('id', sourceId);
            if (error)
                throw error;
            loadSources();
        }
        catch (err) {
            console.error('Error deleting source:', err);
            setError(err.message);
        }
        finally {
            setDeleting(null);
        }
    };
    const getCategoryColor = (category) => {
        const colors = {
            regulatory: 'bg-blue-100 text-blue-800',
            market: 'bg-green-100 text-green-800',
            business: 'bg-purple-100 text-purple-800',
            cybersecurity: 'bg-red-100 text-red-800',
            environmental: 'bg-emerald-100 text-emerald-800',
            other: 'bg-gray-100 text-gray-800',
        };
        return colors[category] || colors.other;
    };
    if (loading) {
        return (_jsx(Card, { children: _jsxs(CardContent, { className: "flex items-center justify-center py-12", children: [_jsx(Loader2, { className: "h-8 w-8 animate-spin text-gray-400" }), _jsx("span", { className: "ml-3 text-gray-500", children: "Loading sources..." })] }) }));
    }
    return (_jsxs(_Fragment, { children: [_jsxs(Card, { children: [_jsx(CardHeader, { children: _jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { children: [_jsxs(CardTitle, { children: ["News Sources (", sources.length, ")"] }), _jsx(CardDescription, { className: "mt-1", children: "Manage RSS feed URLs for news scanning. Only active sources are scanned." })] }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsxs(Button, { size: "sm", variant: "outline", onClick: loadSources, children: [_jsx(RefreshCw, { className: "h-4 w-4 mr-2" }), "Refresh"] }), _jsxs(Button, { size: "sm", onClick: handleAdd, children: [_jsx(Plus, { className: "h-4 w-4 mr-2" }), "Add Source"] })] })] }) }), _jsxs(CardContent, { children: [error && (_jsxs("div", { className: "mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2", children: [_jsx(AlertCircle, { className: "h-4 w-4 text-red-600" }), _jsx("span", { className: "text-sm text-red-800", children: error }), _jsx(Button, { size: "sm", variant: "ghost", onClick: () => setError(null), className: "ml-auto", children: _jsx(X, { className: "h-4 w-4" }) })] })), _jsxs("div", { className: "space-y-3 max-h-[500px] overflow-y-auto pr-2", children: [sources.map((source) => (_jsx("div", { className: `border rounded-lg p-4 transition-colors ${source.is_active
                                            ? 'border-purple-200 bg-white'
                                            : 'border-gray-200 bg-gray-50'}`, children: _jsxs("div", { className: "flex items-start justify-between gap-3", children: [_jsxs("div", { className: "flex-1", children: [_jsxs("div", { className: "flex items-center gap-2 mb-2", children: [_jsx("h4", { className: "font-semibold text-sm text-gray-900", children: source.name }), source.is_default && (_jsx(Badge, { variant: "outline", className: "text-xs", children: "Default" })), _jsx(Badge, { className: `text-xs ${source.is_active
                                                                        ? 'bg-green-100 text-green-800'
                                                                        : 'bg-gray-100 text-gray-600'}`, children: source.is_active ? (_jsxs(_Fragment, { children: [_jsx(Check, { className: "h-3 w-3 mr-1" }), "Active"] })) : (_jsxs(_Fragment, { children: [_jsx(X, { className: "h-3 w-3 mr-1" }), "Inactive"] })) })] }), _jsxs("div", { className: "flex items-center gap-2 text-xs text-gray-500 mb-2", children: [_jsx(Globe, { className: "h-3 w-3" }), _jsx("span", { className: "font-mono truncate max-w-md", children: source.url })] }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Badge, { className: getCategoryColor(source.category), children: source.category }), _jsx("span", { className: "text-xs text-gray-500", children: source.country })] })] }), _jsxs("div", { className: "flex items-center gap-1", children: [_jsx(Button, { size: "sm", variant: "ghost", onClick: () => handleToggleActive(source), title: source.is_active ? 'Deactivate' : 'Activate', children: source.is_active ? (_jsx(X, { className: "h-4 w-4 text-orange-600" })) : (_jsx(Check, { className: "h-4 w-4 text-green-600" })) }), _jsx(Button, { size: "sm", variant: "ghost", onClick: () => handleEdit(source), children: _jsx(Edit, { className: "h-4 w-4" }) }), !source.is_default && (_jsx(Button, { size: "sm", variant: "ghost", onClick: () => handleDelete(source.id), disabled: deleting === source.id, children: deleting === source.id ? (_jsx(Loader2, { className: "h-4 w-4 animate-spin text-red-600" })) : (_jsx(Trash2, { className: "h-4 w-4 text-red-600" })) }))] })] }) }, source.id))), sources.length === 0 && (_jsxs("div", { className: "text-center py-12 text-gray-500", children: [_jsx(Globe, { className: "h-12 w-12 mx-auto mb-3 text-gray-300" }), _jsx("p", { children: "No news sources configured" }), _jsx("p", { className: "text-xs mt-1", children: "Add your first RSS feed URL to get started" })] }))] })] })] }), _jsx(Dialog, { open: showAddDialog, onOpenChange: setShowAddDialog, children: _jsxs(DialogContent, { children: [_jsxs(DialogHeader, { children: [_jsx(DialogTitle, { children: editingSource ? 'Edit News Source' : 'Add News Source' }), _jsx(DialogDescription, { children: "Add an RSS feed URL to scan for risk-related news" })] }), _jsxs("div", { className: "space-y-4", children: [error && (_jsxs("div", { className: "p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2", children: [_jsx(AlertCircle, { className: "h-4 w-4 text-red-600" }), _jsx("span", { className: "text-sm text-red-800", children: error })] })), _jsxs("div", { children: [_jsx("label", { className: "text-sm font-medium mb-1 block", children: "Source Name *" }), _jsx(Input, { placeholder: "e.g., Bloomberg Markets", value: formData.name, onChange: (e) => setFormData({ ...formData, name: e.target.value }) })] }), _jsxs("div", { children: [_jsx("label", { className: "text-sm font-medium mb-1 block", children: "RSS Feed URL *" }), _jsx(Input, { placeholder: "https://example.com/feed.xml", value: formData.url, onChange: (e) => setFormData({ ...formData, url: e.target.value }) }), _jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Must be a valid RSS or Atom feed URL" })] }), _jsxs("div", { children: [_jsx("label", { className: "text-sm font-medium mb-1 block", children: "Category" }), _jsxs(Select, { value: formData.category, onValueChange: (value) => setFormData({ ...formData, category: value }), children: [_jsx(SelectTrigger, { children: _jsx(SelectValue, {}) }), _jsx(SelectContent, { children: categories.map((cat) => (_jsx(SelectItem, { value: cat, children: cat }, cat))) })] })] }), _jsxs("div", { children: [_jsx("label", { className: "text-sm font-medium mb-1 block", children: "Country" }), _jsx(Input, { placeholder: "e.g., Nigeria, Global", value: formData.country, onChange: (e) => setFormData({ ...formData, country: e.target.value }) })] })] }), _jsxs(DialogFooter, { children: [_jsx(Button, { variant: "outline", onClick: () => setShowAddDialog(false), disabled: saving, children: "Cancel" }), _jsx(Button, { onClick: handleSave, disabled: saving, children: saving ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 mr-2 animate-spin" }), "Saving..."] })) : ('Save Source') })] })] }) })] }));
}
