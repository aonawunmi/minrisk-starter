import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// src/components/intelligence/AlertReviewDialog.tsx
// Dialog for reviewing and accepting/rejecting risk intelligence alerts
import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, } from '../ui/dialog';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Textarea } from '../ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { CheckCircle2, XCircle, Loader2, TrendingUp, TrendingDown, AlertTriangle, ExternalLink, Globe, Calendar, Tag, Target, } from 'lucide-react';
import { updateAlertStatus } from '../../lib/riskIntelligence';
import { format } from 'date-fns';
export function AlertReviewDialog({ alert, open, onClose, onUpdate }) {
    const [reviewNotes, setReviewNotes] = useState('');
    const [processing, setProcessing] = useState(false);
    if (!alert)
        return null;
    const handleAccept = async () => {
        setProcessing(true);
        const { success, error } = await updateAlertStatus(alert.id, 'accepted', reviewNotes || 'Alert accepted');
        if (success) {
            onUpdate();
            onClose();
            setReviewNotes('');
        }
        else {
            window.alert(`Failed to accept alert: ${error}`);
            console.error(error);
        }
        setProcessing(false);
    };
    const handleReject = async () => {
        if (!reviewNotes.trim()) {
            window.alert('Please provide a reason for rejection');
            return;
        }
        setProcessing(true);
        const { success, error } = await updateAlertStatus(alert.id, 'rejected', reviewNotes);
        if (success) {
            onUpdate();
            onClose();
            setReviewNotes('');
        }
        else {
            window.alert(`Failed to reject alert: ${error}`);
            console.error(error);
        }
        setProcessing(false);
    };
    const getCategoryColor = (category) => {
        switch (category) {
            case 'cybersecurity':
                return 'bg-purple-100 text-purple-700 border-purple-300';
            case 'regulatory':
                return 'bg-blue-100 text-blue-700 border-blue-300';
            case 'market':
                return 'bg-orange-100 text-orange-700 border-orange-300';
            case 'environmental':
                return 'bg-green-100 text-green-700 border-green-300';
            case 'operational':
                return 'bg-gray-100 text-gray-700 border-gray-300';
            default:
                return 'bg-gray-100 text-gray-600 border-gray-300';
        }
    };
    return (_jsx(Dialog, { open: open, onOpenChange: onClose, children: _jsxs(DialogContent, { className: "max-w-4xl max-h-[90vh] overflow-y-auto", children: [_jsxs(DialogHeader, { children: [_jsx(DialogTitle, { children: "Review Risk Intelligence Alert" }), _jsx(DialogDescription, { children: "Accept alerts to add them to your treatment log for manual application to risks" })] }), _jsxs("div", { className: "space-y-6", children: [_jsx(Card, { children: _jsx(CardHeader, { children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsx("div", { children: _jsxs(CardTitle, { className: "text-lg flex items-center gap-2", children: [_jsx(AlertTriangle, { className: "h-5 w-5 text-orange-500" }), alert.risk_code] }) }), _jsxs("div", { className: "flex items-center gap-2", children: [alert.suggested_likelihood_change > 0 ? (_jsxs(Badge, { className: "bg-red-600", children: [_jsx(TrendingUp, { className: "h-3 w-3 mr-1" }), "+", alert.suggested_likelihood_change, " Likelihood"] })) : alert.suggested_likelihood_change < 0 ? (_jsxs(Badge, { className: "bg-green-600", children: [_jsx(TrendingDown, { className: "h-3 w-3 mr-1" }), alert.suggested_likelihood_change, " Likelihood"] })) : (_jsx(Badge, { variant: "outline", children: "No Change" })), _jsxs(Badge, { className: alert.confidence_score >= 0.8
                                                        ? 'bg-green-600'
                                                        : alert.confidence_score >= 0.6
                                                            ? 'bg-yellow-600'
                                                            : 'bg-gray-600', children: [Math.round(alert.confidence_score * 100), "% Confidence"] })] })] }) }) }), _jsxs(Card, { children: [_jsx(CardHeader, { children: _jsx(CardTitle, { className: "text-sm", children: "Event Details" }) }), _jsxs(CardContent, { className: "space-y-3", children: [_jsxs("div", { children: [_jsx("h4", { className: "font-medium text-gray-900 mb-2", children: alert.event.title }), _jsx("p", { className: "text-sm text-gray-700", children: alert.event.description })] }), _jsxs("div", { className: "flex flex-wrap items-center gap-3 text-sm", children: [_jsxs("div", { className: "flex items-center gap-1 text-gray-600", children: [_jsx(Globe, { className: "h-4 w-4" }), alert.event.source_name] }), _jsxs("div", { className: "flex items-center gap-1 text-gray-600", children: [_jsx(Calendar, { className: "h-4 w-4" }), format(new Date(alert.event.published_date), 'MMM d, yyyy h:mm a')] }), _jsxs(Badge, { variant: "outline", className: getCategoryColor(alert.event.event_category), children: [_jsx(Tag, { className: "h-3 w-3 mr-1" }), alert.event.event_category] }), alert.event.country && (_jsx(Badge, { variant: "outline", children: alert.event.country }))] }), alert.event.source_url && (_jsxs(Button, { variant: "outline", size: "sm", onClick: () => window.open(alert.event.source_url, '_blank'), children: [_jsx(ExternalLink, { className: "h-4 w-4 mr-2" }), "View Source"] })), alert.event.keywords && alert.event.keywords.length > 0 && (_jsxs("div", { children: [_jsx("p", { className: "text-xs font-medium text-gray-600 mb-2", children: "Keywords:" }), _jsx("div", { className: "flex flex-wrap gap-1", children: alert.event.keywords.map((keyword, idx) => (_jsx(Badge, { variant: "outline", className: "text-xs", children: keyword }, idx))) })] }))] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { children: _jsx(CardTitle, { className: "text-sm", children: "AI Analysis" }) }), _jsxs(CardContent, { className: "space-y-3", children: [_jsxs("div", { children: [_jsx("h5", { className: "text-xs font-medium text-gray-600 mb-1", children: "Reasoning:" }), _jsx("p", { className: "text-sm text-gray-700", children: alert.reasoning })] }), alert.impact_assessment && (_jsxs("div", { className: "p-3 bg-blue-50 rounded-lg border border-blue-200", children: [_jsx("h5", { className: "text-xs font-medium text-blue-900 mb-1", children: "Impact Assessment:" }), _jsx("p", { className: "text-sm text-blue-800", children: alert.impact_assessment })] })), alert.suggested_controls && alert.suggested_controls.length > 0 && (_jsxs("div", { children: [_jsxs("h5", { className: "text-xs font-medium text-gray-600 mb-2 flex items-center gap-1", children: [_jsx(Target, { className: "h-3 w-3" }), "Suggested Controls:"] }), _jsx("ul", { className: "space-y-2", children: alert.suggested_controls.map((control, idx) => (_jsxs("li", { className: "flex items-start gap-2 text-sm text-gray-700", children: [_jsx("span", { className: "text-gray-400 mt-1", children: "\u2022" }), _jsx("span", { children: control })] }, idx))) })] }))] })] }), alert.status === 'pending' && (_jsxs(Card, { children: [_jsx(CardHeader, { children: _jsx(CardTitle, { className: "text-sm", children: "Review Decision" }) }), _jsxs(CardContent, { className: "space-y-4", children: [_jsxs("div", { children: [_jsxs("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: ["Review Notes ", alert.status === 'pending' && '(required for rejection)'] }), _jsx(Textarea, { placeholder: "Add your review notes or reason for rejection...", value: reviewNotes, onChange: e => setReviewNotes(e.target.value), rows: 4, className: "text-sm" })] }), alert.suggested_likelihood_change !== 0 && (_jsxs("div", { className: "p-3 bg-blue-50 rounded-lg border border-blue-200", children: [_jsxs("p", { className: "text-sm font-medium text-blue-900", children: ["Suggested Likelihood Change: ", alert.suggested_likelihood_change > 0 ? '+' : '', alert.suggested_likelihood_change] }), _jsx("p", { className: "text-xs text-blue-700 mt-1", children: "Accepted alerts will be added to your treatment log. You can manually apply them to the risk register from the \"Accepted\" tab." })] })), _jsxs("div", { className: "flex items-center justify-end gap-3 pt-3 border-t", children: [_jsx(Button, { variant: "outline", onClick: onClose, disabled: processing, children: "Cancel" }), _jsx(Button, { variant: "outline", onClick: handleReject, disabled: processing, className: "text-red-600 hover:bg-red-50", children: processing ? (_jsx(Loader2, { className: "h-4 w-4 animate-spin" })) : (_jsxs(_Fragment, { children: [_jsx(XCircle, { className: "h-4 w-4 mr-2" }), "Reject"] })) }), _jsx(Button, { onClick: handleAccept, disabled: processing, children: processing ? (_jsx(Loader2, { className: "h-4 w-4 animate-spin" })) : (_jsxs(_Fragment, { children: [_jsx(CheckCircle2, { className: "h-4 w-4 mr-2" }), "Accept Alert"] })) })] })] })] })), alert.status !== 'pending' && (_jsxs(Card, { children: [_jsx(CardHeader, { children: _jsx(CardTitle, { className: "text-sm", children: "Review History" }) }), _jsx(CardContent, { children: _jsxs("div", { className: "space-y-2", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Badge, { variant: "outline", className: alert.status === 'accepted'
                                                            ? 'bg-green-50 text-green-700'
                                                            : 'bg-red-50 text-red-700', children: alert.status === 'accepted' ? 'Accepted' : 'Rejected' }), alert.reviewed_at && (_jsxs("span", { className: "text-sm text-gray-500", children: ["on ", format(new Date(alert.reviewed_at), 'MMM d, yyyy h:mm a')] }))] }), alert.review_notes && (_jsx("div", { className: "text-sm text-gray-700 bg-gray-50 p-3 rounded", children: alert.review_notes }))] }) })] }))] })] }) }));
}
