import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// src/components/intelligence/RiskKeywordsManager.tsx
// Manage custom risk-related keywords for news filtering
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, } from '../ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, } from '../ui/dialog';
import { Plus, Trash2, Tag, Check, X, Loader2, RefreshCw, AlertCircle, Search, } from 'lucide-react';
import { supabase } from '../../lib/supabase';
export function RiskKeywordsManager() {
    const [keywords, setKeywords] = useState([]);
    const [filteredKeywords, setFilteredKeywords] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showAddDialog, setShowAddDialog] = useState(false);
    const [deleting, setDeleting] = useState(null);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [categoryFilter, setCategoryFilter] = useState('all');
    const [formData, setFormData] = useState({
        keyword: '',
        category: 'general',
    });
    const categories = [
        'financial',
        'cyber',
        'compliance',
        'operational',
        'environmental',
        'general',
    ];
    useEffect(() => {
        loadKeywords();
    }, []);
    useEffect(() => {
        filterKeywords();
    }, [keywords, searchQuery, categoryFilter]);
    const loadKeywords = async () => {
        setLoading(true);
        setError(null);
        try {
            const { data, error } = await supabase
                .from('risk_keywords')
                .select('*')
                .order('keyword');
            if (error)
                throw error;
            setKeywords(data || []);
        }
        catch (err) {
            console.error('Error loading keywords:', err);
            setError(err.message);
        }
        finally {
            setLoading(false);
        }
    };
    const filterKeywords = () => {
        let filtered = keywords;
        if (searchQuery) {
            filtered = filtered.filter((k) => k.keyword.toLowerCase().includes(searchQuery.toLowerCase()));
        }
        if (categoryFilter !== 'all') {
            filtered = filtered.filter((k) => k.category === categoryFilter);
        }
        setFilteredKeywords(filtered);
    };
    const handleAdd = () => {
        setFormData({
            keyword: '',
            category: 'general',
        });
        setShowAddDialog(true);
    };
    const handleSave = async () => {
        // Validate
        if (!formData.keyword.trim()) {
            setError('Keyword is required');
            return;
        }
        setSaving(true);
        setError(null);
        try {
            // Get user's organization_id
            const { data: profile, error: profileError } = await supabase
                .from('user_profiles')
                .select('organization_id')
                .eq('id', (await supabase.auth.getUser()).data.user?.id)
                .single();
            if (profileError)
                throw profileError;
            const { error } = await supabase
                .from('risk_keywords')
                .insert({
                organization_id: profile.organization_id,
                keyword: formData.keyword.toLowerCase().trim(),
                category: formData.category,
                is_active: true,
                is_default: false,
            });
            if (error)
                throw error;
            setShowAddDialog(false);
            loadKeywords();
        }
        catch (err) {
            console.error('Error saving keyword:', err);
            if (err.code === '23505') {
                setError('This keyword already exists');
            }
            else {
                setError(err.message);
            }
        }
        finally {
            setSaving(false);
        }
    };
    const handleToggleActive = async (keyword) => {
        try {
            const { error } = await supabase
                .from('risk_keywords')
                .update({ is_active: !keyword.is_active })
                .eq('id', keyword.id);
            if (error)
                throw error;
            loadKeywords();
        }
        catch (err) {
            console.error('Error toggling keyword:', err);
            setError(err.message);
        }
    };
    const handleDelete = async (keywordId) => {
        if (!confirm('Are you sure you want to delete this keyword?'))
            return;
        setDeleting(keywordId);
        try {
            const { error } = await supabase
                .from('risk_keywords')
                .delete()
                .eq('id', keywordId);
            if (error)
                throw error;
            loadKeywords();
        }
        catch (err) {
            console.error('Error deleting keyword:', err);
            setError(err.message);
        }
        finally {
            setDeleting(null);
        }
    };
    const getCategoryColor = (category) => {
        const colors = {
            financial: 'bg-green-100 text-green-800',
            cyber: 'bg-red-100 text-red-800',
            compliance: 'bg-blue-100 text-blue-800',
            operational: 'bg-orange-100 text-orange-800',
            environmental: 'bg-emerald-100 text-emerald-800',
            general: 'bg-gray-100 text-gray-800',
        };
        return colors[category] || colors.general;
    };
    const getCategoryCount = (category) => {
        return keywords.filter((k) => k.category === category && k.is_active).length;
    };
    if (loading) {
        return (_jsx(Card, { children: _jsxs(CardContent, { className: "flex items-center justify-center py-12", children: [_jsx(Loader2, { className: "h-8 w-8 animate-spin text-gray-400" }), _jsx("span", { className: "ml-3 text-gray-500", children: "Loading keywords..." })] }) }));
    }
    return (_jsxs(_Fragment, { children: [_jsxs(Card, { children: [_jsx(CardHeader, { children: _jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { children: [_jsxs(CardTitle, { children: ["Risk Keywords (", keywords.filter(k => k.is_active).length, " active)"] }), _jsx(CardDescription, { className: "mt-1", children: "Customize keywords used to identify risk-related news. Only active keywords are used." })] }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsxs(Button, { size: "sm", variant: "outline", onClick: loadKeywords, children: [_jsx(RefreshCw, { className: "h-4 w-4 mr-2" }), "Refresh"] }), _jsxs(Button, { size: "sm", onClick: handleAdd, children: [_jsx(Plus, { className: "h-4 w-4 mr-2" }), "Add Keyword"] })] })] }) }), _jsxs(CardContent, { children: [error && (_jsxs("div", { className: "mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2", children: [_jsx(AlertCircle, { className: "h-4 w-4 text-red-600" }), _jsx("span", { className: "text-sm text-red-800", children: error }), _jsx(Button, { size: "sm", variant: "ghost", onClick: () => setError(null), className: "ml-auto", children: _jsx(X, { className: "h-4 w-4" }) })] })), _jsx("div", { className: "grid grid-cols-2 md:grid-cols-6 gap-2 mb-4", children: categories.map((cat) => (_jsxs("div", { className: "text-center p-2 border rounded-lg cursor-pointer hover:border-purple-300", onClick: () => setCategoryFilter(cat === categoryFilter ? 'all' : cat), children: [_jsx("div", { className: "text-lg font-bold", children: getCategoryCount(cat) }), _jsx("div", { className: "text-xs text-gray-500", children: cat })] }, cat))) }), _jsxs("div", { className: "flex flex-col md:flex-row gap-3 mb-4", children: [_jsxs("div", { className: "flex-1 relative", children: [_jsx(Search, { className: "absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" }), _jsx(Input, { placeholder: "Search keywords...", value: searchQuery, onChange: (e) => setSearchQuery(e.target.value), className: "pl-10" })] }), _jsxs(Select, { value: categoryFilter, onValueChange: setCategoryFilter, children: [_jsx(SelectTrigger, { className: "w-full md:w-48", children: _jsx(SelectValue, { placeholder: "Category" }) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "all", children: "All Categories" }), categories.map((cat) => (_jsxs(SelectItem, { value: cat, children: [cat, " (", getCategoryCount(cat), ")"] }, cat)))] })] })] }), _jsxs("div", { className: "flex flex-wrap gap-2 max-h-[400px] overflow-y-auto p-2", children: [filteredKeywords.map((keyword) => (_jsxs("div", { className: `inline-flex items-center gap-2 px-3 py-1.5 rounded-full border transition-colors ${keyword.is_active
                                            ? 'border-purple-200 bg-white'
                                            : 'border-gray-200 bg-gray-50'}`, children: [_jsx(Tag, { className: "h-3 w-3 text-gray-400" }), _jsx("span", { className: "text-sm font-medium", children: keyword.keyword }), _jsx(Badge, { className: `${getCategoryColor(keyword.category)} text-xs`, children: keyword.category }), keyword.is_default && (_jsx(Badge, { variant: "outline", className: "text-xs", children: "Default" })), _jsx("button", { onClick: () => handleToggleActive(keyword), className: "ml-1 hover:opacity-70", title: keyword.is_active ? 'Deactivate' : 'Activate', children: keyword.is_active ? (_jsx(Check, { className: "h-3 w-3 text-green-600" })) : (_jsx(X, { className: "h-3 w-3 text-gray-400" })) }), !keyword.is_default && (_jsx("button", { onClick: () => handleDelete(keyword.id), disabled: deleting === keyword.id, className: "ml-1 hover:opacity-70", children: deleting === keyword.id ? (_jsx(Loader2, { className: "h-3 w-3 animate-spin text-red-600" })) : (_jsx(Trash2, { className: "h-3 w-3 text-red-600" })) }))] }, keyword.id))), filteredKeywords.length === 0 && (_jsxs("div", { className: "w-full text-center py-12 text-gray-500", children: [_jsx(Tag, { className: "h-12 w-12 mx-auto mb-3 text-gray-300" }), _jsx("p", { children: "No keywords found" }), searchQuery && (_jsx("p", { className: "text-xs mt-1", children: "Try adjusting your search" }))] }))] })] })] }), _jsx(Dialog, { open: showAddDialog, onOpenChange: setShowAddDialog, children: _jsxs(DialogContent, { children: [_jsxs(DialogHeader, { children: [_jsx(DialogTitle, { children: "Add Risk Keyword" }), _jsx(DialogDescription, { children: "Add a custom keyword to identify risk-related news articles" })] }), _jsxs("div", { className: "space-y-4", children: [error && (_jsxs("div", { className: "p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2", children: [_jsx(AlertCircle, { className: "h-4 w-4 text-red-600" }), _jsx("span", { className: "text-sm text-red-800", children: error })] })), _jsxs("div", { children: [_jsx("label", { className: "text-sm font-medium mb-1 block", children: "Keyword *" }), _jsx(Input, { placeholder: "e.g., money laundering, insider trading", value: formData.keyword, onChange: (e) => setFormData({ ...formData, keyword: e.target.value }) }), _jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Use lowercase for better matching. Can be a phrase." })] }), _jsxs("div", { children: [_jsx("label", { className: "text-sm font-medium mb-1 block", children: "Category" }), _jsxs(Select, { value: formData.category, onValueChange: (value) => setFormData({ ...formData, category: value }), children: [_jsx(SelectTrigger, { children: _jsx(SelectValue, {}) }), _jsx(SelectContent, { children: categories.map((cat) => (_jsx(SelectItem, { value: cat, children: cat }, cat))) })] })] })] }), _jsxs(DialogFooter, { children: [_jsx(Button, { variant: "outline", onClick: () => setShowAddDialog(false), disabled: saving, children: "Cancel" }), _jsx(Button, { onClick: handleSave, disabled: saving, children: saving ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 mr-2 animate-spin" }), "Saving..."] })) : ('Add Keyword') })] })] }) })] }));
}
