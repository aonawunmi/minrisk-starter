import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// src/components/intelligence/ScanResultsDialog.tsx
// Dialog to show detailed scan results with option to retain filtered items
import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, } from '../ui/dialog';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsList, TabsTrigger } from '../ui/tabs';
import { CheckCircle2, XCircle, Filter, Copy, ExternalLink, Save, Loader2, } from 'lucide-react';
export function ScanResultsDialog({ open, onClose, results, stats, onRetain, }) {
    const [activeTab, setActiveTab] = useState('all');
    const [retaining, setRetaining] = useState(null);
    const filteredResults = results.filter((r) => {
        if (activeTab === 'all')
            return true;
        return r.status === activeTab;
    });
    const handleRetain = async (item) => {
        setRetaining(item.title);
        try {
            const success = await onRetain(item);
            if (success) {
                // Update the item status locally
                item.status = 'stored';
            }
        }
        finally {
            setRetaining(null);
        }
    };
    const getStatusBadge = (status) => {
        switch (status) {
            case 'stored':
                return (_jsxs(Badge, { className: "bg-green-600", children: [_jsx(CheckCircle2, { className: "h-3 w-3 mr-1" }), "Stored"] }));
            case 'filtered':
                return (_jsxs(Badge, { variant: "secondary", children: [_jsx(Filter, { className: "h-3 w-3 mr-1" }), "Filtered"] }));
            case 'duplicate':
                return (_jsxs(Badge, { variant: "outline", children: [_jsx(Copy, { className: "h-3 w-3 mr-1" }), "Duplicate"] }));
            case 'error':
                return (_jsxs(Badge, { variant: "destructive", children: [_jsx(XCircle, { className: "h-3 w-3 mr-1" }), "Error"] }));
            default:
                return _jsx(Badge, { children: status });
        }
    };
    const getCategoryColor = (category) => {
        const colors = {
            cybersecurity: 'bg-red-100 text-red-800',
            regulatory: 'bg-blue-100 text-blue-800',
            market: 'bg-green-100 text-green-800',
            environmental: 'bg-emerald-100 text-emerald-800',
            operational: 'bg-orange-100 text-orange-800',
            other: 'bg-gray-100 text-gray-800',
        };
        return colors[category] || colors.other;
    };
    return (_jsx(Dialog, { open: open, onOpenChange: onClose, children: _jsxs(DialogContent, { className: "max-w-6xl max-h-[90vh] overflow-hidden flex flex-col", children: [_jsxs(DialogHeader, { children: [_jsx(DialogTitle, { children: "Scan Results" }), _jsx(DialogDescription, { children: "Detailed view of all scanned news items and their processing status" })] }), _jsxs("div", { className: "grid grid-cols-3 md:grid-cols-6 gap-2 py-3 border-b", children: [_jsxs("div", { className: "text-center", children: [_jsx("div", { className: "text-2xl font-bold text-gray-900", children: stats.feeds_processed }), _jsx("div", { className: "text-xs text-gray-500", children: "Feeds" })] }), _jsxs("div", { className: "text-center", children: [_jsx("div", { className: "text-2xl font-bold text-gray-900", children: stats.events_found }), _jsx("div", { className: "text-xs text-gray-500", children: "Found" })] }), _jsxs("div", { className: "text-center", children: [_jsx("div", { className: "text-2xl font-bold text-green-600", children: stats.events_stored }), _jsx("div", { className: "text-xs text-gray-500", children: "Stored" })] }), _jsxs("div", { className: "text-center", children: [_jsx("div", { className: "text-2xl font-bold text-gray-600", children: stats.events_filtered }), _jsx("div", { className: "text-xs text-gray-500", children: "Filtered" })] }), _jsxs("div", { className: "text-center", children: [_jsx("div", { className: "text-2xl font-bold text-gray-400", children: stats.events_duplicate }), _jsx("div", { className: "text-xs text-gray-500", children: "Duplicate" })] }), _jsxs("div", { className: "text-center", children: [_jsx("div", { className: "text-2xl font-bold text-purple-600", children: stats.alerts_created }), _jsx("div", { className: "text-xs text-gray-500", children: "Alerts" })] })] }), _jsxs(Tabs, { value: activeTab, onValueChange: (v) => setActiveTab(v), className: "flex-1 flex flex-col overflow-hidden", children: [_jsxs(TabsList, { children: [_jsxs(TabsTrigger, { value: "all", children: ["All (", results.length, ")"] }), _jsxs(TabsTrigger, { value: "stored", children: ["Stored (", results.filter((r) => r.status === 'stored').length, ")"] }), _jsxs(TabsTrigger, { value: "filtered", children: ["Filtered (", results.filter((r) => r.status === 'filtered').length, ")"] }), _jsxs(TabsTrigger, { value: "duplicate", children: ["Duplicate (", results.filter((r) => r.status === 'duplicate').length, ")"] })] }), _jsx("div", { className: "flex-1 overflow-y-auto mt-4", children: _jsxs("div", { className: "space-y-3 pr-2", children: [filteredResults.map((item, idx) => (_jsxs("div", { className: "border rounded-lg p-4 hover:border-purple-300 transition-colors", children: [_jsxs("div", { className: "flex items-start justify-between gap-3 mb-2", children: [_jsxs("div", { className: "flex-1", children: [_jsx("h4", { className: "font-semibold text-sm text-gray-900 mb-1", children: item.title }), _jsxs("div", { className: "flex items-center gap-2 text-xs text-gray-500", children: [_jsx("span", { children: item.source_name }), _jsx("span", { children: "\u2022" }), _jsx("span", { children: item.country }), _jsx("span", { children: "\u2022" }), _jsx("span", { children: new Date(item.pubDate).toLocaleDateString() })] })] }), _jsxs("div", { className: "flex items-center gap-2", children: [getStatusBadge(item.status), item.status === 'filtered' && (_jsx(Button, { size: "sm", variant: "outline", onClick: () => handleRetain(item), disabled: retaining === item.title, children: retaining === item.title ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-3 w-3 mr-1 animate-spin" }), "Saving..."] })) : (_jsxs(_Fragment, { children: [_jsx(Save, { className: "h-3 w-3 mr-1" }), "Retain"] })) }))] })] }), _jsx("p", { className: "text-xs text-gray-600 mb-3 line-clamp-2", children: item.description }), _jsxs("div", { className: "flex items-center gap-2 flex-wrap", children: [_jsx(Badge, { className: getCategoryColor(item.category), variant: "secondary", children: item.category }), item.keywords && item.keywords.length > 0 && (_jsxs(_Fragment, { children: [item.keywords.slice(0, 3).map((keyword) => (_jsx(Badge, { variant: "outline", className: "text-xs", children: keyword }, keyword))), item.keywords.length > 3 && (_jsxs("span", { className: "text-xs text-gray-400", children: ["+", item.keywords.length - 3, " more"] }))] })), item.reason && (_jsx("span", { className: "text-xs text-gray-500 italic ml-auto", children: item.reason })), item.link && (_jsx(Button, { size: "sm", variant: "ghost", className: "h-6 px-2 ml-auto", onClick: () => window.open(item.link, '_blank'), children: _jsx(ExternalLink, { className: "h-3 w-3" }) }))] })] }, idx))), filteredResults.length === 0 && (_jsx("div", { className: "text-center py-12 text-gray-500", children: "No items in this category" }))] }) })] }), _jsx("div", { className: "flex justify-end gap-2 pt-4 border-t", children: _jsx(Button, { variant: "outline", onClick: onClose, children: "Close" }) })] }) }));
}
