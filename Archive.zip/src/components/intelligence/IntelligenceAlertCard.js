import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// src/components/intelligence/IntelligenceAlertCard.tsx
// Card display for individual risk intelligence alerts
import { Card, CardContent, CardHeader } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { AlertTriangle, TrendingUp, TrendingDown, Eye, Clock, ExternalLink, CheckCircle2, XCircle, } from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
export function IntelligenceAlertCard({ alert, onReview }) {
    const getStatusBadge = () => {
        switch (alert.status) {
            case 'pending':
                return (_jsxs(Badge, { variant: "outline", className: "bg-yellow-50 text-yellow-700 border-yellow-300", children: [_jsx(Clock, { className: "h-3 w-3 mr-1" }), "Pending Review"] }));
            case 'accepted':
                return (_jsxs(Badge, { variant: "outline", className: "bg-green-50 text-green-700 border-green-300", children: [_jsx(CheckCircle2, { className: "h-3 w-3 mr-1" }), "Accepted"] }));
            case 'rejected':
                return (_jsxs(Badge, { variant: "outline", className: "bg-red-50 text-red-700 border-red-300", children: [_jsx(XCircle, { className: "h-3 w-3 mr-1" }), "Rejected"] }));
            case 'expired':
                return (_jsx(Badge, { variant: "outline", className: "bg-gray-50 text-gray-600 border-gray-300", children: "Expired" }));
            default:
                return _jsx(Badge, { variant: "outline", children: alert.status });
        }
    };
    const getConfidenceBadge = () => {
        const confidence = alert.confidence_score;
        if (confidence >= 0.8) {
            return _jsxs(Badge, { className: "bg-green-600", children: ["High Confidence (", Math.round(confidence * 100), "%)"] });
        }
        else if (confidence >= 0.6) {
            return _jsxs(Badge, { className: "bg-yellow-600", children: ["Medium Confidence (", Math.round(confidence * 100), "%)"] });
        }
        else {
            return _jsxs(Badge, { className: "bg-gray-600", children: ["Low Confidence (", Math.round(confidence * 100), "%)"] });
        }
    };
    const getLikelihoodChangeIndicator = () => {
        const change = alert.suggested_likelihood_change;
        if (change > 0) {
            return (_jsxs("div", { className: "flex items-center gap-1 text-red-600", children: [_jsx(TrendingUp, { className: "h-4 w-4" }), _jsxs("span", { className: "text-sm font-medium", children: ["+", change] })] }));
        }
        else if (change < 0) {
            return (_jsxs("div", { className: "flex items-center gap-1 text-green-600", children: [_jsx(TrendingDown, { className: "h-4 w-4" }), _jsx("span", { className: "text-sm font-medium", children: change })] }));
        }
        else {
            return (_jsx("div", { className: "flex items-center gap-1 text-gray-600", children: _jsx("span", { className: "text-sm font-medium", children: "No change" }) }));
        }
    };
    const getCategoryColor = (category) => {
        switch (category) {
            case 'cybersecurity':
                return 'bg-purple-100 text-purple-700 border-purple-300';
            case 'regulatory':
                return 'bg-blue-100 text-blue-700 border-blue-300';
            case 'market':
                return 'bg-orange-100 text-orange-700 border-orange-300';
            case 'environmental':
                return 'bg-green-100 text-green-700 border-green-300';
            case 'operational':
                return 'bg-gray-100 text-gray-700 border-gray-300';
            default:
                return 'bg-gray-100 text-gray-600 border-gray-300';
        }
    };
    return (_jsxs(Card, { className: `hover:shadow-md transition-shadow ${alert.status === 'pending' ? 'border-l-4 border-l-yellow-500' : ''}`, children: [_jsx(CardHeader, { className: "pb-3", children: _jsxs("div", { className: "flex items-start justify-between gap-3", children: [_jsxs("div", { className: "flex-1 min-w-0", children: [_jsxs("div", { className: "space-y-1 mb-2", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(AlertTriangle, { className: "h-4 w-4 text-orange-500 flex-shrink-0" }), _jsx("h4", { className: "font-medium text-sm text-gray-900", children: alert.risk_code }), getStatusBadge()] }), alert.risk_title && (_jsx("p", { className: "text-xs font-medium text-gray-700 ml-6", children: alert.risk_title })), alert.risk_description && (_jsx("p", { className: "text-xs text-gray-600 ml-6 line-clamp-1", children: alert.risk_description }))] }), _jsx("h5", { className: "text-sm font-medium text-gray-700 mb-1", children: alert.event.title }), _jsxs("div", { className: "flex items-center gap-3 text-xs text-gray-500", children: [_jsx(Badge, { variant: "outline", className: getCategoryColor(alert.event.event_category), children: alert.event.event_category }), _jsx("span", { children: alert.event.source_name }), _jsx("span", { children: formatDistanceToNow(new Date(alert.event.published_date), { addSuffix: true }) })] })] }), _jsxs("div", { className: "flex flex-col items-end gap-2", children: [getLikelihoodChangeIndicator(), getConfidenceBadge()] })] }) }), _jsxs(CardContent, { className: "pt-0 space-y-3", children: [_jsx("div", { children: _jsx("p", { className: "text-sm text-gray-700 line-clamp-2", children: alert.reasoning }) }), alert.impact_assessment && (_jsx("div", { className: "p-2 bg-blue-50 rounded border border-blue-200", children: _jsx("p", { className: "text-xs text-blue-800", children: alert.impact_assessment }) })), alert.suggested_controls && alert.suggested_controls.length > 0 && (_jsxs("div", { children: [_jsx("p", { className: "text-xs font-medium text-gray-600 mb-1", children: "Suggested Controls:" }), _jsxs("ul", { className: "space-y-1", children: [alert.suggested_controls.slice(0, 2).map((control, idx) => (_jsxs("li", { className: "text-xs text-gray-600 flex items-start gap-1", children: [_jsx("span", { className: "text-gray-400 mt-0.5", children: "\u2022" }), _jsx("span", { className: "line-clamp-1", children: control })] }, idx))), alert.suggested_controls.length > 2 && (_jsxs("li", { className: "text-xs text-gray-500 italic", children: ["+", alert.suggested_controls.length - 2, " more"] }))] })] })), _jsxs("div", { className: "flex items-center justify-between pt-2 border-t", children: [_jsx("div", { className: "flex items-center gap-2", children: alert.event.source_url && (_jsxs(Button, { variant: "ghost", size: "sm", className: "text-xs h-7", onClick: () => window.open(alert.event.source_url, '_blank'), children: [_jsx(ExternalLink, { className: "h-3 w-3 mr-1" }), "Source"] })) }), alert.status === 'pending' && onReview && (_jsxs(Button, { size: "sm", className: "h-7 text-xs", onClick: () => onReview(alert), children: [_jsx(Eye, { className: "h-3 w-3 mr-1" }), "Review"] })), alert.status !== 'pending' && alert.reviewed_at && (_jsxs("span", { className: "text-xs text-gray-500", children: ["Reviewed ", format(new Date(alert.reviewed_at), 'MMM d')] }))] })] })] }));
}
