import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { Sparkles, Loader2 } from 'lucide-react';
import { generateControlMeasures } from '../lib/ai';
export function AIControlSuggester({ riskTitle, riskDescription, category, onControlsGenerated }) {
    const [isGenerating, setIsGenerating] = useState(false);
    const [generatedControls, setGeneratedControls] = useState([]);
    const handleGenerate = async () => {
        setIsGenerating(true);
        setGeneratedControls([]);
        try {
            const context = {
                riskCategory: category,
            };
            const controls = await generateControlMeasures(riskTitle, riskDescription, context);
            setGeneratedControls(controls);
            if (onControlsGenerated) {
                onControlsGenerated(controls);
            }
        }
        catch (error) {
            console.error('Control generation failed:', error);
            alert(`Failed to generate control measures: ${error.message}`);
        }
        finally {
            setIsGenerating(false);
        }
    };
    return (_jsxs("div", { className: "space-y-3", children: [_jsx("button", { onClick: handleGenerate, disabled: isGenerating, className: "w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg px-4 py-2 hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-opacity flex items-center justify-center gap-2", children: isGenerating ? (_jsxs(_Fragment, { children: [_jsx(Loader2, { className: "h-4 w-4 animate-spin" }), "Generating Control Measures..."] })) : (_jsxs(_Fragment, { children: [_jsx(Sparkles, { className: "h-4 w-4" }), "Generate AI Control Measures"] })) }), generatedControls.length > 0 && (_jsxs("div", { className: "bg-purple-50 border border-purple-200 rounded-lg p-4 space-y-2", children: [_jsxs("h5", { className: "font-medium text-gray-900 flex items-center gap-2", children: [_jsx(Sparkles, { className: "h-4 w-4 text-purple-600" }), "AI-Generated Control Measures:"] }), _jsx("ul", { className: "space-y-2 text-sm", children: generatedControls.map((control, idx) => (_jsxs("li", { className: "flex gap-2", children: [_jsxs("span", { className: "font-medium text-purple-600", children: [idx + 1, "."] }), _jsx("span", { className: "text-gray-700", children: control })] }, idx))) }), _jsx("p", { className: "text-xs text-gray-500 mt-3", children: "Review these suggestions and add them to your control measures as needed." })] }))] }));
}
