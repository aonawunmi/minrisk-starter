import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// src/components/DashboardTab.tsx
// Main Dashboard with Executive Overview and Risk Appetite
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, Shield, BarChart3, AlertTriangle } from 'lucide-react';
import AppetiteDashboard from '@/components/risk-appetite/AppetiteDashboard';
export function DashboardTab({ risks, incidents, showToast }) {
    // Calculate summary statistics
    const totalRisks = risks.length;
    const highRisks = risks.filter(r => r.residual_score >= 12).length;
    const totalIncidents = incidents.length;
    const recentIncidents = incidents.filter(i => {
        const incidentDate = new Date(i.incident_date);
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        return incidentDate >= thirtyDaysAgo;
    }).length;
    const avgResidualScore = risks.length > 0
        ? (risks.reduce((sum, r) => sum + r.residual_score, 0) / risks.length).toFixed(1)
        : '0.0';
    return (_jsxs(Tabs, { defaultValue: "overview", className: "w-full", children: [_jsxs(TabsList, { children: [_jsx(TabsTrigger, { value: "overview", children: "\uD83D\uDCCA Overview" }), _jsx(TabsTrigger, { value: "appetite", children: "\uD83C\uDFAF Risk Appetite" })] }), _jsxs(TabsContent, { value: "overview", className: "space-y-6", children: [_jsxs("div", { children: [_jsx("h2", { className: "text-2xl font-bold mb-2", children: "Executive Dashboard" }), _jsx("p", { className: "text-gray-600", children: "Real-time overview of your risk management status" })] }), _jsxs("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4", children: [_jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsxs(CardDescription, { className: "flex items-center gap-2", children: [_jsx(BarChart3, { className: "h-4 w-4" }), "Total Risks"] }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-3xl font-bold", children: totalRisks }), _jsx("p", { className: "text-xs text-gray-500 mt-1", children: "Active in portfolio" })] })] }), _jsxs(Card, { className: "border-red-200 bg-red-50", children: [_jsx(CardHeader, { className: "pb-2", children: _jsxs(CardDescription, { className: "flex items-center gap-2", children: [_jsx(AlertTriangle, { className: "h-4 w-4" }), "High Priority"] }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-3xl font-bold text-red-700", children: highRisks }), _jsxs("p", { className: "text-xs text-gray-600 mt-1", children: [totalRisks > 0 ? `${((highRisks / totalRisks) * 100).toFixed(1)}%` : '0%', " of total"] })] })] }), _jsxs(Card, { className: "border-orange-200 bg-orange-50", children: [_jsx(CardHeader, { className: "pb-2", children: _jsxs(CardDescription, { className: "flex items-center gap-2", children: [_jsx(TrendingUp, { className: "h-4 w-4" }), "Avg Risk Score"] }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-3xl font-bold text-orange-700", children: avgResidualScore }), _jsx("p", { className: "text-xs text-gray-600 mt-1", children: "Residual risk level" })] })] }), _jsxs(Card, { className: "border-blue-200 bg-blue-50", children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardDescription, { children: "Incidents (30d)" }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-3xl font-bold text-blue-700", children: recentIncidents }), _jsxs("p", { className: "text-xs text-gray-600 mt-1", children: [totalIncidents, " total recorded"] })] })] })] }), _jsxs(Card, { children: [_jsxs(CardHeader, { children: [_jsx(CardTitle, { children: "Quick Actions" }), _jsx(CardDescription, { children: "Common tasks and navigation" })] }), _jsx(CardContent, { children: _jsxs("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4", children: [_jsxs("button", { onClick: () => {
                                                const event = new CustomEvent('minrisk:navigate', { detail: 'register' });
                                                window.dispatchEvent(event);
                                            }, className: "p-4 border rounded-lg hover:bg-gray-50 text-center transition-colors", children: [_jsx("div", { className: "text-2xl mb-2", children: "\uD83D\uDCCB" }), _jsx("div", { className: "font-medium", children: "Risk Register" })] }), _jsxs("button", { onClick: () => {
                                                const event = new CustomEvent('minrisk:navigate', { detail: 'analytics' });
                                                window.dispatchEvent(event);
                                            }, className: "p-4 border rounded-lg hover:bg-gray-50 text-center transition-colors", children: [_jsx("div", { className: "text-2xl mb-2", children: "\uD83D\uDCC8" }), _jsx("div", { className: "font-medium", children: "Analytics" })] }), _jsxs("button", { onClick: () => {
                                                const event = new CustomEvent('minrisk:navigate', { detail: 'operations' });
                                                window.dispatchEvent(event);
                                            }, className: "p-4 border rounded-lg hover:bg-gray-50 text-center transition-colors", children: [_jsx("div", { className: "text-2xl mb-2", children: "\uD83D\uDEA8" }), _jsx("div", { className: "font-medium", children: "Operations" })] }), _jsxs("button", { onClick: () => {
                                                const event = new CustomEvent('minrisk:navigate', { detail: 'ai_assistant' });
                                                window.dispatchEvent(event);
                                            }, className: "p-4 border rounded-lg hover:bg-gray-50 text-center transition-colors", children: [_jsx("div", { className: "text-2xl mb-2", children: "\u2728" }), _jsx("div", { className: "font-medium", children: "AI Assistant" })] })] }) })] }), _jsx(Card, { className: "border-blue-200 bg-blue-50", children: _jsx(CardContent, { className: "pt-6", children: _jsxs("div", { className: "flex gap-2", children: [_jsx(Shield, { className: "h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" }), _jsxs("div", { className: "text-sm text-blue-800", children: [_jsx("strong", { children: "Welcome to MinRisk" }), " - Your enterprise risk management platform. Navigate using the tabs above to access risk register, analytics, operations, and more. View Risk Appetite status in the tab above."] })] }) }) })] }), _jsx(TabsContent, { value: "appetite", children: _jsx(AppetiteDashboard, { showToast: showToast }) })] }));
}
