import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// src/components/RiskRegisterTabGroup.tsx
// Grouped tab for Risk Register, Controls, Heat Map, and Import
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
export function RiskRegisterTabGroup({ RiskRegisterContent, ControlRegisterContent, HeatMapContent, ImportContent, canEdit, }) {
    return (_jsxs(Tabs, { defaultValue: "register", className: "w-full", children: [_jsxs(TabsList, { children: [_jsx(TabsTrigger, { value: "register", children: "\uD83D\uDCCB Register" }), _jsx(TabsTrigger, { value: "controls", children: "\uD83D\uDEE1\uFE0F Controls" }), _jsx(TabsTrigger, { value: "heatmap", children: "\uD83D\uDD25 Heat Map" }), canEdit && _jsx(TabsTrigger, { value: "import", children: "\uD83D\uDCE5 Import" })] }), _jsx(TabsContent, { value: "register", className: "space-y-4", children: RiskRegisterContent }), _jsx(TabsContent, { value: "controls", className: "space-y-4", children: ControlRegisterContent }), _jsx(TabsContent, { value: "heatmap", className: "space-y-4", children: HeatMapContent }), canEdit && (_jsx(TabsContent, { value: "import", className: "space-y-4", children: ImportContent }))] }));
}
