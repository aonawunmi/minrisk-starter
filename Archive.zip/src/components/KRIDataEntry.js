import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// src/components/KRIDataEntry.tsx
// KRI Data Entry - Record KRI measurements
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Plus, Loader2 } from 'lucide-react';
import { loadKRIDefinitions, loadKRIData, createKRIDataEntry } from '@/lib/kri';
export function KRIDataEntry() {
    const [kris, setKris] = useState([]);
    const [selectedKRI, setSelectedKRI] = useState('');
    const [entries, setEntries] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showDialog, setShowDialog] = useState(false);
    const [saving, setSaving] = useState(false);
    // Form state
    const [formData, setFormData] = useState({
        measurement_date: new Date().toISOString().split('T')[0],
        measurement_value: '',
        notes: '',
        data_quality: 'verified',
    });
    useEffect(() => {
        loadKRIDefinitions().then((data) => {
            setKris(data.filter(k => k.enabled));
            if (data.length > 0 && data[0].enabled) {
                setSelectedKRI(data[0].id);
            }
        }).finally(() => setLoading(false));
    }, []);
    useEffect(() => {
        if (selectedKRI) {
            loadKRIData(selectedKRI, 30).then(setEntries);
        }
    }, [selectedKRI]);
    const selectedKRIData = kris.find(k => k.id === selectedKRI);
    const handleAddEntry = () => {
        setFormData({
            measurement_date: new Date().toISOString().split('T')[0],
            measurement_value: '',
            notes: '',
            data_quality: 'verified',
        });
        setShowDialog(true);
    };
    const handleSave = async () => {
        if (!selectedKRI || !formData.measurement_value) {
            alert('Please fill in required fields');
            return;
        }
        setSaving(true);
        try {
            await createKRIDataEntry({
                kri_id: selectedKRI,
                measurement_date: formData.measurement_date,
                measurement_value: parseFloat(formData.measurement_value),
                notes: formData.notes || undefined,
                data_quality: formData.data_quality,
            });
            // Reload entries
            const updatedEntries = await loadKRIData(selectedKRI, 30);
            setEntries(updatedEntries);
            setShowDialog(false);
        }
        catch (error) {
            console.error('Error saving entry:', error);
            alert('Failed to save entry');
        }
        finally {
            setSaving(false);
        }
    };
    if (loading) {
        return _jsx("div", { className: "p-8 text-center", children: "Loading KRIs..." });
    }
    if (kris.length === 0) {
        return (_jsxs("div", { className: "p-8 text-center text-gray-500", children: [_jsx("p", { children: "No KRIs defined yet" }), _jsx("p", { className: "text-sm mt-2", children: "Create KRIs in the Management tab first" })] }));
    }
    return (_jsxs("div", { className: "space-y-4", children: [_jsx("div", { className: "flex justify-between items-center", children: _jsx("h2", { className: "text-2xl font-bold", children: "KRI Data Entry" }) }), _jsxs(Card, { children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "Select KRI" }) }), _jsxs(CardContent, { children: [_jsxs("div", { className: "flex gap-4 items-end", children: [_jsxs("div", { className: "flex-1", children: [_jsx(Label, { htmlFor: "kri-select", children: "Key Risk Indicator" }), _jsxs(Select, { value: selectedKRI, onValueChange: setSelectedKRI, children: [_jsx(SelectTrigger, { id: "kri-select", children: _jsx(SelectValue, { placeholder: "Select a KRI" }) }), _jsx(SelectContent, { children: kris.map((kri) => (_jsxs(SelectItem, { value: kri.id, children: [kri.kri_code, " - ", kri.kri_name] }, kri.id))) })] })] }), _jsxs(Button, { onClick: handleAddEntry, disabled: !selectedKRI, children: [_jsx(Plus, { className: "mr-2 h-4 w-4" }), "Add Measurement"] })] }), selectedKRIData && (_jsxs("div", { className: "mt-4 p-4 bg-gray-50 rounded-lg", children: [_jsxs("div", { className: "grid grid-cols-2 gap-4 text-sm", children: [_jsxs("div", { children: [_jsx("span", { className: "font-medium", children: "Unit:" }), " ", selectedKRIData.measurement_unit] }), _jsxs("div", { children: [_jsx("span", { className: "font-medium", children: "Frequency:" }), " ", selectedKRIData.collection_frequency] }), _jsxs("div", { children: [_jsx("span", { className: "font-medium", children: "Type:" }), " ", selectedKRIData.indicator_type] }), _jsxs("div", { children: [_jsx("span", { className: "font-medium", children: "Category:" }), " ", selectedKRIData.category || 'N/A'] })] }), selectedKRIData.description && (_jsx("div", { className: "mt-2 text-sm text-gray-600", children: selectedKRIData.description }))] }))] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { children: _jsxs(CardTitle, { children: ["Recent Measurements (", entries.length, ")"] }) }), _jsx(CardContent, { children: entries.length === 0 ? (_jsxs("div", { className: "text-center py-12 text-gray-500", children: [_jsx("p", { children: "No measurements recorded yet" }), _jsx("p", { className: "text-sm mt-2", children: "Click \"Add Measurement\" to record the first value" })] })) : (_jsx("div", { className: "space-y-2", children: entries.map((entry) => (_jsxs("div", { className: "flex items-center justify-between p-4 border rounded-lg", children: [_jsxs("div", { className: "flex-1", children: [_jsxs("div", { className: "flex items-center gap-4", children: [_jsxs("div", { className: "font-medium text-lg", children: [entry.measurement_value, " ", selectedKRIData?.measurement_unit] }), _jsx("div", { className: "text-sm text-gray-600", children: new Date(entry.measurement_date).toLocaleDateString() }), entry.alert_status && (_jsx("span", { className: `px-2 py-1 rounded text-xs font-medium ${entry.alert_status === 'red' ? 'bg-red-100 text-red-800' :
                                                            entry.alert_status === 'yellow' ? 'bg-yellow-100 text-yellow-800' :
                                                                'bg-green-100 text-green-800'}`, children: entry.alert_status.toUpperCase() }))] }), entry.notes && (_jsx("div", { className: "text-sm text-gray-500 mt-1", children: entry.notes }))] }), _jsx("div", { className: "text-xs text-gray-400", children: entry.data_quality })] }, entry.id))) })) })] }), _jsx(Dialog, { open: showDialog, onOpenChange: setShowDialog, children: _jsxs(DialogContent, { className: "max-w-lg", children: [_jsxs(DialogHeader, { children: [_jsx(DialogTitle, { children: "Record Measurement" }), _jsx(DialogDescription, { children: selectedKRIData && `${selectedKRIData.kri_code} - ${selectedKRIData.kri_name}` })] }), _jsxs("div", { className: "grid gap-4 py-4", children: [_jsxs("div", { children: [_jsx(Label, { htmlFor: "measurement_date", children: "Measurement Date *" }), _jsx(Input, { id: "measurement_date", type: "date", value: formData.measurement_date, onChange: (e) => setFormData({ ...formData, measurement_date: e.target.value }) })] }), _jsxs("div", { children: [_jsxs(Label, { htmlFor: "measurement_value", children: ["Measurement Value * (", selectedKRIData?.measurement_unit, ")"] }), _jsx(Input, { id: "measurement_value", type: "number", step: "any", value: formData.measurement_value, onChange: (e) => setFormData({ ...formData, measurement_value: e.target.value }), placeholder: "Enter the measured value" })] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "data_quality", children: "Data Quality" }), _jsxs(Select, { value: formData.data_quality, onValueChange: (value) => setFormData({ ...formData, data_quality: value }), children: [_jsx(SelectTrigger, { children: _jsx(SelectValue, {}) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "verified", children: "Verified" }), _jsx(SelectItem, { value: "estimated", children: "Estimated" }), _jsx(SelectItem, { value: "provisional", children: "Provisional" })] })] })] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "notes", children: "Notes (Optional)" }), _jsx(Textarea, { id: "notes", value: formData.notes, onChange: (e) => setFormData({ ...formData, notes: e.target.value }), placeholder: "Any context or observations about this measurement" })] }), selectedKRIData && (selectedKRIData.lower_threshold || selectedKRIData.upper_threshold) && (_jsxs("div", { className: "p-3 bg-blue-50 rounded-lg text-sm", children: [_jsx("div", { className: "font-medium mb-1", children: "Thresholds:" }), selectedKRIData.target_value && (_jsxs("div", { children: ["Target: ", selectedKRIData.target_value] })), selectedKRIData.lower_threshold && (_jsxs("div", { children: ["Lower: ", selectedKRIData.lower_threshold] })), selectedKRIData.upper_threshold && (_jsxs("div", { children: ["Upper: ", selectedKRIData.upper_threshold] }))] }))] }), _jsxs(DialogFooter, { children: [_jsx(Button, { variant: "outline", onClick: () => setShowDialog(false), disabled: saving, children: "Cancel" }), _jsxs(Button, { onClick: handleSave, disabled: saving, children: [saving && _jsx(Loader2, { className: "mr-2 h-4 w-4 animate-spin" }), "Save Measurement"] })] })] }) })] }));
}
