import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// src/components/AnalyticsTabGroup.tsx
// Grouped tab for Analytics, VaR Sandbox, and Reports
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
export function AnalyticsTabGroup({ AnalyticsContent, VarSandboxContent, RiskReportContent, }) {
    return (_jsxs(Tabs, { defaultValue: "analytics", className: "w-full", children: [_jsxs(TabsList, { children: [_jsx(TabsTrigger, { value: "analytics", children: "\uD83D\uDCCA Analytics" }), _jsx(TabsTrigger, { value: "var", children: "\uD83D\uDCC8 VaR Sandbox" }), _jsx(TabsTrigger, { value: "reports", children: "\uD83D\uDCCB Reports" })] }), _jsx(TabsContent, { value: "analytics", className: "space-y-4", children: AnalyticsContent }), _jsx(TabsContent, { value: "var", className: "space-y-4", children: VarSandboxContent }), _jsx(TabsContent, { value: "reports", className: "space-y-4", children: RiskReportContent })] }));
}
