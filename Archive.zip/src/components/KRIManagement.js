import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// src/components/KRIManagement.tsx
// KRI Management - CRUD operations for KRI definitions
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Plus, Pencil, Trash2, Loader2, Link as LinkIcon, Sparkles, X } from 'lucide-react';
import { loadKRIDefinitions, createKRIDefinition, updateKRIDefinition, deleteKRIDefinition, generateNextKRICode, suggestRisksForKRI, linkKRIToRisk, unlinkKRIFromRisk, getLinkedRisksForKRI } from '@/lib/kri';
import { loadRisks } from '@/lib/database';
import { Badge } from '@/components/ui/badge';
export function KRIManagement({ canEdit }) {
    const [kris, setKris] = useState([]);
    const [risks, setRisks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showDialog, setShowDialog] = useState(false);
    const [editingKRI, setEditingKRI] = useState(null);
    const [saving, setSaving] = useState(false);
    // AI Risk Linking state
    const [showLinkDialog, setShowLinkDialog] = useState(false);
    const [linkingKRI, setLinkingKRI] = useState(null);
    const [aiSuggestions, setAISuggestions] = useState([]);
    const [analyzingRisks, setAnalyzingRisks] = useState(false);
    const [linkingRiskCode, setLinkingRiskCode] = useState(null);
    const [manualRiskCode, setManualRiskCode] = useState('');
    const [linkedRisksMap, setLinkedRisksMap] = useState(new Map());
    // Form state
    const [formData, setFormData] = useState({
        kri_code: '',
        kri_name: '',
        description: '',
        category: '',
        indicator_type: 'lagging',
        measurement_unit: '',
        data_source: '',
        collection_frequency: 'monthly',
        responsible_user: '',
        target_value: '',
        lower_threshold: '',
        upper_threshold: '',
        threshold_direction: 'above',
    });
    useEffect(() => {
        loadData();
    }, []);
    const loadData = async () => {
        setLoading(true);
        try {
            const [kriData, riskData] = await Promise.all([
                loadKRIDefinitions(),
                loadRisks()
            ]);
            setKris(kriData);
            setRisks(riskData);
            // Load linked risks for each KRI
            const linksMap = new Map();
            for (const kri of kriData) {
                try {
                    const linkedRisks = await getLinkedRisksForKRI(kri.id);
                    if (linkedRisks.length > 0) {
                        linksMap.set(kri.id, linkedRisks);
                    }
                }
                catch (error) {
                    console.error(`Failed to load linked risks for KRI ${kri.kri_code}:`, error);
                }
            }
            setLinkedRisksMap(linksMap);
        }
        finally {
            setLoading(false);
        }
    };
    const handleAddNew = async () => {
        const nextCode = await generateNextKRICode();
        setFormData({
            kri_code: nextCode,
            kri_name: '',
            description: '',
            category: '',
            indicator_type: 'lagging',
            measurement_unit: '',
            data_source: '',
            collection_frequency: 'monthly',
            responsible_user: '',
            target_value: '',
            lower_threshold: '',
            upper_threshold: '',
            threshold_direction: 'above',
        });
        setEditingKRI(null);
        setShowDialog(true);
    };
    const handleEdit = (kri) => {
        setFormData({
            kri_code: kri.kri_code,
            kri_name: kri.kri_name,
            description: kri.description || '',
            category: kri.category || '',
            indicator_type: kri.indicator_type,
            measurement_unit: kri.measurement_unit,
            data_source: kri.data_source || '',
            collection_frequency: kri.collection_frequency,
            responsible_user: kri.responsible_user || '',
            target_value: kri.target_value?.toString() || '',
            lower_threshold: kri.lower_threshold?.toString() || '',
            upper_threshold: kri.upper_threshold?.toString() || '',
            threshold_direction: kri.threshold_direction,
        });
        setEditingKRI(kri);
        setShowDialog(true);
    };
    const handleSave = async () => {
        if (!formData.kri_name || !formData.measurement_unit) {
            alert('Please fill in required fields');
            return;
        }
        setSaving(true);
        try {
            const data = {
                kri_code: formData.kri_code,
                kri_name: formData.kri_name,
                description: formData.description || undefined,
                category: formData.category || undefined,
                indicator_type: formData.indicator_type,
                measurement_unit: formData.measurement_unit,
                data_source: formData.data_source || undefined,
                collection_frequency: formData.collection_frequency,
                responsible_user: formData.responsible_user || undefined,
                target_value: formData.target_value ? parseFloat(formData.target_value) : undefined,
                lower_threshold: formData.lower_threshold ? parseFloat(formData.lower_threshold) : undefined,
                upper_threshold: formData.upper_threshold ? parseFloat(formData.upper_threshold) : undefined,
                threshold_direction: formData.threshold_direction,
                enabled: true,
            };
            if (editingKRI) {
                await updateKRIDefinition(editingKRI.id, data);
            }
            else {
                await createKRIDefinition(data);
            }
            await loadData();
            setShowDialog(false);
        }
        catch (error) {
            console.error('Error saving KRI:', error);
            alert('Failed to save KRI');
        }
        finally {
            setSaving(false);
        }
    };
    const handleDelete = async (kri) => {
        if (!confirm(`Are you sure you want to delete KRI "${kri.kri_name}"?`)) {
            return;
        }
        try {
            await deleteKRIDefinition(kri.id);
            await loadData();
        }
        catch (error) {
            console.error('Error deleting KRI:', error);
            alert('Failed to delete KRI');
        }
    };
    // AI Risk Linking handlers
    const handleLinkToRisk = async (kri) => {
        setLinkingKRI(kri);
        setShowLinkDialog(true);
        setAISuggestions([]);
        setManualRiskCode('');
        // Start AI analysis
        setAnalyzingRisks(true);
        try {
            const suggestions = await suggestRisksForKRI(kri);
            setAISuggestions(suggestions);
        }
        catch (error) {
            console.error('Error analyzing KRI for risk suggestions:', error);
            alert('Failed to analyze KRI for risk suggestions');
        }
        finally {
            setAnalyzingRisks(false);
        }
    };
    const handleConfirmLink = async (riskCode, confidence) => {
        if (!linkingKRI)
            return;
        setLinkingRiskCode(riskCode);
        try {
            await linkKRIToRisk(linkingKRI.id, riskCode, confidence);
            // Reload linked risks for this KRI
            const linkedRisks = await getLinkedRisksForKRI(linkingKRI.id);
            setLinkedRisksMap(prev => new Map(prev).set(linkingKRI.id, linkedRisks));
            // Re-run AI analysis to get fresh suggestions (filtering out newly linked risk)
            setAnalyzingRisks(true);
            const suggestions = await suggestRisksForKRI(linkingKRI);
            setAISuggestions(suggestions);
            setAnalyzingRisks(false);
            // Clear manual selection
            setManualRiskCode('');
            // DON'T close dialog - allow linking to multiple risks
        }
        catch (error) {
            console.error('Error linking KRI to risk:', error);
            alert('Failed to link KRI to risk');
        }
        finally {
            setLinkingRiskCode(null);
        }
    };
    const handleManualLink = () => {
        if (!manualRiskCode) {
            alert('Please select a risk to link');
            return;
        }
        // Manual links have no AI confidence score
        handleConfirmLink(manualRiskCode, undefined);
    };
    const handleUnlink = async (kriId, riskCode, riskTitle) => {
        if (!confirm(`Remove link to ${riskCode} (${riskTitle})?`)) {
            return;
        }
        try {
            await unlinkKRIFromRisk(kriId, riskCode);
            // Reload linked risks for this KRI
            const linkedRisks = await getLinkedRisksForKRI(kriId);
            if (linkedRisks.length > 0) {
                setLinkedRisksMap(prev => new Map(prev).set(kriId, linkedRisks));
            }
            else {
                setLinkedRisksMap(prev => {
                    const newMap = new Map(prev);
                    newMap.delete(kriId);
                    return newMap;
                });
            }
        }
        catch (error) {
            console.error('Error unlinking KRI:', error);
            alert('Failed to unlink KRI');
        }
    };
    // Helper to get linked risks for a KRI
    const getLinkedRisks = (kri) => {
        return linkedRisksMap.get(kri.id) || [];
    };
    if (loading) {
        return _jsx("div", { className: "p-8 text-center", children: "Loading KRIs..." });
    }
    return (_jsxs("div", { className: "space-y-4", children: [_jsxs("div", { className: "flex justify-between items-center", children: [_jsx("h2", { className: "text-2xl font-bold", children: "KRI Definitions" }), canEdit && (_jsxs(Button, { onClick: handleAddNew, children: [_jsx(Plus, { className: "mr-2 h-4 w-4" }), "Add KRI"] }))] }), _jsxs(Card, { children: [_jsx(CardHeader, { children: _jsxs(CardTitle, { children: ["Active KRIs (", kris.length, ")"] }) }), _jsx(CardContent, { children: kris.length === 0 ? (_jsxs("div", { className: "text-center py-12 text-gray-500", children: [_jsx("p", { children: "No KRIs defined" }), _jsx("p", { className: "text-sm mt-2", children: "Click \"Add KRI\" to create your first indicator" })] })) : (_jsx("div", { className: "space-y-2", children: kris.map((kri) => {
                                const linkedRisks = getLinkedRisks(kri);
                                return (_jsxs("div", { className: "flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50", children: [_jsxs("div", { className: "flex-1", children: [_jsxs("div", { className: "font-medium", children: [kri.kri_code, " - ", kri.kri_name] }), _jsx("div", { className: "text-sm text-gray-600", children: kri.description }), _jsxs("div", { className: "flex gap-4 mt-2 text-xs text-gray-500", children: [_jsxs("span", { children: ["Category: ", kri.category || 'N/A'] }), _jsxs("span", { children: ["Type: ", kri.indicator_type] }), _jsxs("span", { children: ["Frequency: ", kri.collection_frequency] }), _jsxs("span", { children: ["Unit: ", kri.measurement_unit] })] }), linkedRisks.length > 0 && (_jsx("div", { className: "mt-2 flex flex-wrap gap-1", children: linkedRisks.map((linkedRisk) => (_jsxs(Badge, { variant: "outline", className: "bg-blue-50 text-blue-800 border-blue-200 text-xs", children: [_jsx(LinkIcon, { className: "h-3 w-3 mr-1 inline" }), linkedRisk.risk_code, ": ", linkedRisk.risk_title, linkedRisk.ai_link_confidence && ` (${linkedRisk.ai_link_confidence}%)`, canEdit && (_jsx("button", { onClick: () => handleUnlink(kri.id, linkedRisk.risk_code, linkedRisk.risk_title), className: "ml-1 hover:text-red-600", title: "Unlink", children: _jsx(X, { className: "h-3 w-3 inline" }) }))] }, linkedRisk.risk_code))) }))] }), canEdit && (_jsxs("div", { className: "flex gap-2", children: [_jsx(Button, { variant: "outline", size: "sm", onClick: () => handleLinkToRisk(kri), title: "Link to more risks with AI", children: _jsx(Sparkles, { className: "h-4 w-4 text-purple-500" }) }), _jsx(Button, { variant: "outline", size: "sm", onClick: () => handleEdit(kri), children: _jsx(Pencil, { className: "h-4 w-4" }) }), _jsx(Button, { variant: "outline", size: "sm", onClick: () => handleDelete(kri), children: _jsx(Trash2, { className: "h-4 w-4" }) })] }))] }, kri.id));
                            }) })) })] }), _jsx(Dialog, { open: showDialog, onOpenChange: setShowDialog, children: _jsxs(DialogContent, { className: "max-w-3xl max-h-[90vh] overflow-y-auto", children: [_jsxs(DialogHeader, { children: [_jsx(DialogTitle, { children: editingKRI ? 'Edit KRI' : 'Create New KRI' }), _jsx(DialogDescription, { children: "Define a Key Risk Indicator to track over time" })] }), _jsxs("div", { className: "grid gap-4 py-4", children: [_jsxs("div", { className: "grid grid-cols-2 gap-4", children: [_jsxs("div", { children: [_jsx(Label, { htmlFor: "kri_code", children: "KRI Code *" }), _jsx(Input, { id: "kri_code", value: formData.kri_code, onChange: (e) => setFormData({ ...formData, kri_code: e.target.value }), disabled: !!editingKRI })] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "kri_name", children: "KRI Name *" }), _jsx(Input, { id: "kri_name", value: formData.kri_name, onChange: (e) => setFormData({ ...formData, kri_name: e.target.value }), placeholder: "e.g., Customer Complaints Count" })] })] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "description", children: "Description" }), _jsx(Textarea, { id: "description", value: formData.description, onChange: (e) => setFormData({ ...formData, description: e.target.value }), placeholder: "What does this KRI measure?" })] }), _jsxs("div", { className: "grid grid-cols-2 gap-4", children: [_jsxs("div", { children: [_jsx(Label, { htmlFor: "category", children: "Risk Category" }), _jsx(Input, { id: "category", value: formData.category, onChange: (e) => setFormData({ ...formData, category: e.target.value }), placeholder: "e.g., Operational, Financial" })] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "indicator_type", children: "Indicator Type *" }), _jsxs(Select, { value: formData.indicator_type, onValueChange: (value) => setFormData({ ...formData, indicator_type: value }), children: [_jsx(SelectTrigger, { children: _jsx(SelectValue, {}) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "leading", children: "Leading" }), _jsx(SelectItem, { value: "lagging", children: "Lagging" }), _jsx(SelectItem, { value: "concurrent", children: "Concurrent" })] })] })] })] }), _jsxs("div", { className: "grid grid-cols-2 gap-4", children: [_jsxs("div", { children: [_jsx(Label, { htmlFor: "measurement_unit", children: "Measurement Unit *" }), _jsx(Input, { id: "measurement_unit", value: formData.measurement_unit, onChange: (e) => setFormData({ ...formData, measurement_unit: e.target.value }), placeholder: "e.g., count, %, days" })] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "collection_frequency", children: "Collection Frequency *" }), _jsxs(Select, { value: formData.collection_frequency, onValueChange: (value) => setFormData({ ...formData, collection_frequency: value }), children: [_jsx(SelectTrigger, { children: _jsx(SelectValue, {}) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "daily", children: "Daily" }), _jsx(SelectItem, { value: "weekly", children: "Weekly" }), _jsx(SelectItem, { value: "monthly", children: "Monthly" }), _jsx(SelectItem, { value: "quarterly", children: "Quarterly" }), _jsx(SelectItem, { value: "annually", children: "Annually" })] })] })] })] }), _jsxs("div", { className: "grid grid-cols-3 gap-4", children: [_jsxs("div", { children: [_jsx(Label, { htmlFor: "target_value", children: "Target Value" }), _jsx(Input, { id: "target_value", type: "number", value: formData.target_value, onChange: (e) => setFormData({ ...formData, target_value: e.target.value }), placeholder: "Ideal value" })] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "lower_threshold", children: "Lower Threshold" }), _jsx(Input, { id: "lower_threshold", type: "number", value: formData.lower_threshold, onChange: (e) => setFormData({ ...formData, lower_threshold: e.target.value }), placeholder: "Warning level" })] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "upper_threshold", children: "Upper Threshold" }), _jsx(Input, { id: "upper_threshold", type: "number", value: formData.upper_threshold, onChange: (e) => setFormData({ ...formData, upper_threshold: e.target.value }), placeholder: "Critical level" })] })] }), _jsxs("div", { children: [_jsx(Label, { htmlFor: "threshold_direction", children: "Threshold Direction" }), _jsxs(Select, { value: formData.threshold_direction, onValueChange: (value) => setFormData({ ...formData, threshold_direction: value }), children: [_jsx(SelectTrigger, { children: _jsx(SelectValue, {}) }), _jsxs(SelectContent, { children: [_jsx(SelectItem, { value: "above", children: "Above (higher is bad)" }), _jsx(SelectItem, { value: "below", children: "Below (lower is bad)" }), _jsx(SelectItem, { value: "between", children: "Between (outside range is bad)" })] })] })] })] }), _jsxs(DialogFooter, { children: [_jsx(Button, { variant: "outline", onClick: () => setShowDialog(false), disabled: saving, children: "Cancel" }), _jsxs(Button, { onClick: handleSave, disabled: saving, children: [saving && _jsx(Loader2, { className: "mr-2 h-4 w-4 animate-spin" }), editingKRI ? 'Update' : 'Create'] })] })] }) }), _jsx(Dialog, { open: showLinkDialog, onOpenChange: setShowLinkDialog, children: _jsxs(DialogContent, { className: "max-w-2xl max-h-[90vh] overflow-y-auto", children: [_jsxs(DialogHeader, { children: [_jsxs(DialogTitle, { className: "flex items-center gap-2", children: [_jsx(Sparkles, { className: "h-5 w-5 text-purple-500" }), "AI-Powered Risk Linking"] }), _jsxs(DialogDescription, { children: ["AI analyzed KRI \"", linkingKRI?.kri_name, "\" against your Risk Register. Select a risk to link for integrated monitoring."] })] }), _jsxs("div", { className: "space-y-4 py-4", children: [linkingKRI && getLinkedRisks(linkingKRI).length > 0 && (_jsxs("div", { className: "bg-green-50 border border-green-200 rounded-lg p-3", children: [_jsxs("p", { className: "text-sm text-green-900 font-medium mb-2", children: ["\u2705 Currently Linked Risks (", getLinkedRisks(linkingKRI).length, ")"] }), _jsx("div", { className: "flex flex-wrap gap-1", children: getLinkedRisks(linkingKRI).map((linkedRisk) => (_jsxs(Badge, { variant: "outline", className: "bg-green-100 text-green-800 border-green-300 text-xs", children: [linkedRisk.risk_code, ": ", linkedRisk.risk_title, _jsx("button", { onClick: () => handleUnlink(linkingKRI.id, linkedRisk.risk_code, linkedRisk.risk_title), className: "ml-1 hover:text-red-600", title: "Unlink", children: _jsx(X, { className: "h-3 w-3 inline" }) })] }, linkedRisk.risk_code))) })] })), analyzingRisks ? (_jsxs("div", { className: "flex flex-col items-center justify-center py-12", children: [_jsx(Loader2, { className: "h-8 w-8 animate-spin text-purple-500 mb-3" }), _jsx("p", { className: "text-sm text-gray-600", children: "Analyzing KRI against risks..." }), _jsx("p", { className: "text-xs text-gray-500 mt-1", children: "This may take a few seconds" })] })) : (
                                // Show both AI suggestions and manual selection
                                _jsxs(_Fragment, { children: [aiSuggestions.length > 0 && (_jsxs(_Fragment, { children: [_jsxs("div", { className: "bg-purple-50 border border-purple-200 rounded-lg p-3", children: [_jsx("p", { className: "text-sm text-purple-900 font-medium", children: "\uD83E\uDD16 AI Recommendations" }), _jsxs("p", { className: "text-xs text-purple-800 mt-1", children: ["Top ", aiSuggestions.length, " risk", aiSuggestions.length > 1 ? 's' : '', " that this KRI can monitor effectively"] })] }), _jsx("div", { className: "space-y-3", children: aiSuggestions.map((suggestion, index) => (_jsxs("div", { className: "border rounded-lg p-4 hover:border-purple-300 transition-colors", children: [_jsx("div", { className: "flex items-start justify-between mb-2", children: _jsxs("div", { className: "flex-1", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsxs("span", { className: "font-semibold text-sm", children: ["#", index + 1, " ", suggestion.risk.risk_code, ": ", suggestion.risk.risk_title] }), _jsxs("span", { className: `px-2 py-0.5 rounded text-xs font-medium ${suggestion.confidence >= 80
                                                                                        ? 'bg-green-100 text-green-800'
                                                                                        : suggestion.confidence >= 60
                                                                                            ? 'bg-yellow-100 text-yellow-800'
                                                                                            : 'bg-gray-100 text-gray-800'}`, children: [suggestion.confidence, "% match"] })] }), _jsx("p", { className: "text-xs text-gray-600 mt-1", children: suggestion.risk.risk_description })] }) }), _jsxs("div", { className: "bg-blue-50 border border-blue-200 rounded p-2 mt-2", children: [_jsx("p", { className: "text-xs text-blue-900 font-medium mb-1", children: "AI Reasoning:" }), _jsx("p", { className: "text-xs text-blue-800", children: suggestion.reasoning })] }), _jsxs(Button, { size: "sm", className: "mt-3 w-full", onClick: () => handleConfirmLink(suggestion.risk.risk_code, suggestion.confidence), disabled: linkingRiskCode !== null, children: [linkingRiskCode === suggestion.risk.risk_code && _jsx(Loader2, { className: "mr-2 h-3 w-3 animate-spin" }), "Link to ", suggestion.risk.risk_code] })] }, suggestion.risk.risk_code))) })] })), _jsxs("div", { className: "border-t pt-4 mt-4", children: [_jsxs("div", { className: "bg-gray-50 border border-gray-200 rounded-lg p-3 mb-3", children: [_jsx("p", { className: "text-sm text-gray-900 font-medium", children: "\uD83D\uDCDD Manual Selection" }), _jsx("p", { className: "text-xs text-gray-700 mt-1", children: "Select any risk from your register if the AI suggestions don't match" })] }), _jsxs("div", { className: "space-y-3", children: [_jsxs("div", { children: [_jsx(Label, { htmlFor: "manual-risk-select", children: "Select Risk from Register" }), _jsxs(Select, { value: manualRiskCode, onValueChange: setManualRiskCode, children: [_jsx(SelectTrigger, { id: "manual-risk-select", children: _jsx(SelectValue, { placeholder: "Choose a risk to link..." }) }), _jsx(SelectContent, { children: risks
                                                                                .filter(risk => {
                                                                                if (!linkingKRI)
                                                                                    return true;
                                                                                const linked = linkedRisksMap.get(linkingKRI.id) || [];
                                                                                return !linked.some(lr => lr.risk_code === risk.risk_code);
                                                                            })
                                                                                .map((risk) => (_jsxs(SelectItem, { value: risk.risk_code, children: [risk.risk_code, ": ", risk.risk_title] }, risk.risk_code))) })] })] }), manualRiskCode && (_jsxs("div", { className: "bg-blue-50 border border-blue-200 rounded p-3", children: [_jsx("p", { className: "text-xs font-medium text-blue-900 mb-1", children: "Selected Risk:" }), _jsx("p", { className: "text-sm text-blue-800", children: risks.find(r => r.risk_code === manualRiskCode)?.risk_title })] })), _jsxs(Button, { size: "sm", className: "w-full", onClick: handleManualLink, disabled: !manualRiskCode || linkingRiskCode !== null, children: [linkingRiskCode === manualRiskCode && _jsx(Loader2, { className: "mr-2 h-3 w-3 animate-spin" }), "Link to Selected Risk"] })] })] })] }))] }), _jsx(DialogFooter, { children: _jsx(Button, { variant: "outline", onClick: () => setShowLinkDialog(false), disabled: linkingRiskCode !== null, children: "Cancel" }) })] }) })] }));
}
