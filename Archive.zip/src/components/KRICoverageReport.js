import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// src/components/KRICoverageReport.tsx
// KRI Coverage Analysis Report - Shows which risks have KRI monitoring
import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, AlertTriangle, CheckCircle2, XCircle, Activity } from 'lucide-react';
import { getKRICoverageAnalysis, } from '@/lib/kri';
export function KRICoverageReport() {
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [coverage, setCoverage] = useState([]);
    useEffect(() => {
        loadCoverageData();
    }, []);
    const loadCoverageData = async () => {
        try {
            setLoading(true);
            setError(null);
            const data = await getKRICoverageAnalysis();
            setCoverage(data);
        }
        catch (err) {
            console.error('Failed to load KRI coverage:', err);
            setError('Failed to load KRI coverage analysis');
        }
        finally {
            setLoading(false);
        }
    };
    if (loading) {
        return (_jsx("div", { className: "flex items-center justify-center p-12", children: _jsxs("div", { className: "text-center", children: [_jsx(Activity, { className: "h-8 w-8 animate-spin mx-auto mb-2 text-blue-500" }), _jsx("p", { className: "text-gray-600", children: "Loading coverage analysis..." })] }) }));
    }
    if (error) {
        return (_jsxs(Alert, { variant: "destructive", children: [_jsx(AlertTriangle, { className: "h-4 w-4" }), _jsx(AlertDescription, { children: error })] }));
    }
    const noCoverage = coverage.filter(c => c.coverage_status === 'No Coverage');
    const basicCoverage = coverage.filter(c => c.coverage_status === 'Basic Coverage');
    const goodCoverage = coverage.filter(c => c.coverage_status === 'Good Coverage');
    const getCoverageIcon = (status) => {
        switch (status) {
            case 'Good Coverage':
                return _jsx(CheckCircle2, { className: "h-5 w-5 text-green-600" });
            case 'Basic Coverage':
                return _jsx(TrendingUp, { className: "h-5 w-5 text-yellow-600" });
            default:
                return _jsx(XCircle, { className: "h-5 w-5 text-red-600" });
        }
    };
    const getCoverageBadgeColor = (status) => {
        switch (status) {
            case 'Good Coverage':
                return 'bg-green-100 text-green-800';
            case 'Basic Coverage':
                return 'bg-yellow-100 text-yellow-800';
            default:
                return 'bg-red-100 text-red-800';
        }
    };
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [_jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardTitle, { className: "text-sm font-medium text-gray-600", children: "No KRI Monitoring" }) }), _jsxs(CardContent, { children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx("div", { className: "text-3xl font-bold text-red-600", children: noCoverage.length }), _jsx(XCircle, { className: "h-8 w-8 text-red-500" })] }), _jsx("p", { className: "text-xs text-gray-500 mt-1", children: "High priority for KRI setup" })] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardTitle, { className: "text-sm font-medium text-gray-600", children: "Basic Coverage" }) }), _jsxs(CardContent, { children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx("div", { className: "text-3xl font-bold text-yellow-600", children: basicCoverage.length }), _jsx(TrendingUp, { className: "h-8 w-8 text-yellow-500" })] }), _jsx("p", { className: "text-xs text-gray-500 mt-1", children: "1 KRI monitoring" })] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardTitle, { className: "text-sm font-medium text-gray-600", children: "Good Coverage" }) }), _jsxs(CardContent, { children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx("div", { className: "text-3xl font-bold text-green-600", children: goodCoverage.length }), _jsx(CheckCircle2, { className: "h-8 w-8 text-green-500" })] }), _jsx("p", { className: "text-xs text-gray-500 mt-1", children: "2+ KRIs monitoring" })] })] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "Risk-KRI Coverage Matrix" }) }), _jsx(CardContent, { children: coverage.length === 0 ? (_jsxs("div", { className: "text-center py-8 text-gray-500", children: [_jsx(Activity, { className: "h-12 w-12 mx-auto mb-3 opacity-50" }), _jsx("p", { children: "No risks found in register" })] })) : (_jsx("div", { className: "space-y-3", children: coverage.map((item) => (_jsxs("div", { className: "flex items-start justify-between p-4 border rounded-lg hover:bg-gray-50", children: [_jsxs("div", { className: "flex-1", children: [_jsxs("div", { className: "flex items-center gap-2 mb-1", children: [getCoverageIcon(item.coverage_status), _jsxs("span", { className: "font-semibold text-sm", children: [item.risk_code, " - ", item.risk_title] })] }), _jsxs("div", { className: "flex gap-3 text-xs text-gray-600 mb-2", children: [_jsxs("span", { children: ["Category: ", item.risk_category || 'N/A'] }), _jsxs("span", { children: ["L: ", item.inherent_likelihood || 'N/A'] }), _jsxs("span", { children: ["I: ", item.inherent_impact || 'N/A'] })] }), item.kri_count > 0 && item.linked_kri_codes && (_jsx("div", { className: "flex flex-wrap gap-1 mt-2", children: item.linked_kri_codes.map((code, idx) => (_jsxs(Badge, { variant: "outline", className: "text-xs", children: [code, ": ", item.linked_kri_names?.[idx]] }, code))) }))] }), _jsxs("div", { className: "flex flex-col items-end gap-2", children: [_jsx("span", { className: `px-3 py-1 rounded-full text-xs font-medium ${getCoverageBadgeColor(item.coverage_status)}`, children: item.coverage_status }), _jsxs("span", { className: "text-xs text-gray-500", children: [item.kri_count, " KRI", item.kri_count !== 1 ? 's' : ''] })] })] }, item.risk_id))) })) })] }), noCoverage.length > 0 && (_jsxs(Card, { children: [_jsx(CardHeader, { children: _jsxs(CardTitle, { className: "flex items-center gap-2", children: [_jsx(AlertTriangle, { className: "h-5 w-5 text-orange-500" }), "Recommendations"] }) }), _jsx(CardContent, { children: _jsxs("div", { className: "space-y-2", children: [_jsxs("div", { className: "p-3 bg-orange-50 border border-orange-200 rounded", children: [_jsxs("p", { className: "text-sm font-medium text-orange-900", children: [noCoverage.length, " risk", noCoverage.length !== 1 ? 's' : '', " without KRI monitoring"] }), _jsxs("p", { className: "text-xs text-orange-800 mt-1", children: ["Consider creating KRIs for high-impact risks: ", noCoverage.slice(0, 3).map(r => r.risk_code).join(', '), noCoverage.length > 3 && ` and ${noCoverage.length - 3} more`] })] }), basicCoverage.length > 0 && (_jsxs("div", { className: "p-3 bg-yellow-50 border border-yellow-200 rounded", children: [_jsxs("p", { className: "text-sm font-medium text-yellow-900", children: [basicCoverage.length, " risk", basicCoverage.length !== 1 ? 's' : '', " with only 1 KRI"] }), _jsx("p", { className: "text-xs text-yellow-800 mt-1", children: "Consider adding additional KRIs for more comprehensive monitoring" })] }))] }) })] })), _jsxs(Card, { children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "Best Practices" }) }), _jsx(CardContent, { children: _jsxs("div", { className: "space-y-2 text-sm", children: [_jsxs("div", { className: "flex gap-2", children: [_jsx(CheckCircle2, { className: "h-5 w-5 text-green-600 flex-shrink-0" }), _jsxs("div", { children: [_jsx("p", { className: "font-medium", children: "High-Impact Risks" }), _jsx("p", { className: "text-gray-600 text-xs", children: "Should have 2-3 KRIs for comprehensive monitoring" })] })] }), _jsxs("div", { className: "flex gap-2", children: [_jsx(CheckCircle2, { className: "h-5 w-5 text-green-600 flex-shrink-0" }), _jsxs("div", { children: [_jsx("p", { className: "font-medium", children: "Leading Indicators" }), _jsx("p", { className: "text-gray-600 text-xs", children: "Prioritize leading KRIs for early warning" })] })] }), _jsxs("div", { className: "flex gap-2", children: [_jsx(CheckCircle2, { className: "h-5 w-5 text-green-600 flex-shrink-0" }), _jsxs("div", { children: [_jsx("p", { className: "font-medium", children: "Regular Reviews" }), _jsx("p", { className: "text-gray-600 text-xs", children: "Review KRI coverage quarterly to identify gaps" })] })] })] }) })] })] }));
}
