import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// src/components/AnalyticsDashboard.tsx
import { useState, useMemo } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { BarChart3, TrendingUp, TrendingDown, AlertTriangle, Activity, PieChart, LineChart, Shield, Minus, } from 'lucide-react';
export function AnalyticsDashboard({ risks, incidents, selectedPeriod }) {
    const [activeTab, setActiveTab] = useState('executive');
    // Filter risks by selected period
    const filteredRisks = useMemo(() => {
        if (selectedPeriod.length === 0)
            return risks;
        return risks.filter(r => r.relevant_period && selectedPeriod.includes(r.relevant_period));
    }, [risks, selectedPeriod]);
    // Calculate Executive Summary KPIs
    const executiveMetrics = useMemo(() => {
        const totalRisks = filteredRisks.length;
        const criticalRisks = filteredRisks.filter(r => {
            const score = r.likelihood_residual * r.impact_residual;
            return score >= 20; // Severe
        }).length;
        const highRisks = filteredRisks.filter(r => {
            const score = r.likelihood_residual * r.impact_residual;
            return score >= 12 && score < 20; // High
        }).length;
        const openRisks = filteredRisks.filter(r => r.status === 'Open').length;
        const closedRisks = filteredRisks.filter(r => r.status === 'Closed').length;
        const avgInherentScore = totalRisks > 0
            ? filteredRisks.reduce((sum, r) => sum + (r.likelihood_inherent * r.impact_inherent), 0) / totalRisks
            : 0;
        const avgResidualScore = totalRisks > 0
            ? filteredRisks.reduce((sum, r) => sum + (r.likelihood_residual * r.impact_residual), 0) / totalRisks
            : 0;
        const totalIncidents = incidents.length;
        const openIncidents = incidents.filter(i => i.status === 'Reported' || i.status === 'Under Investigation').length;
        const highSeverityIncidents = incidents.filter(i => i.severity >= 4).length;
        const totalFinancialImpact = incidents.reduce((sum, i) => sum + (i.financial_impact || 0), 0);
        return {
            totalRisks,
            criticalRisks,
            highRisks,
            openRisks,
            closedRisks,
            avgInherentScore,
            avgResidualScore,
            totalIncidents,
            openIncidents,
            highSeverityIncidents,
            totalFinancialImpact,
        };
    }, [filteredRisks, incidents]);
    // Risk Distribution by Severity (based on residual score)
    const riskBySeverity = useMemo(() => {
        const distribution = {
            'Severe': 0,
            'High': 0,
            'Moderate': 0,
            'Low': 0,
            'Minimal': 0,
        };
        filteredRisks.forEach(r => {
            const score = r.likelihood_residual * r.impact_residual;
            if (score >= 20) {
                distribution['Severe']++;
            }
            else if (score >= 12) {
                distribution['High']++;
            }
            else if (score >= 6) {
                distribution['Moderate']++;
            }
            else if (score >= 3) {
                distribution['Low']++;
            }
            else {
                distribution['Minimal']++;
            }
        });
        return distribution;
    }, [filteredRisks]);
    // Risk Distribution by Category
    const riskByCategory = useMemo(() => {
        const categories = {};
        filteredRisks.forEach(r => {
            categories[r.category] = (categories[r.category] || 0) + 1;
        });
        return categories;
    }, [filteredRisks]);
    // Risk Distribution by Division
    const riskByDivision = useMemo(() => {
        const divisions = {};
        filteredRisks.forEach(r => {
            divisions[r.division] = (divisions[r.division] || 0) + 1;
        });
        return divisions;
    }, [filteredRisks]);
    // Incident Distribution by Type
    const incidentByType = useMemo(() => {
        const types = {};
        incidents.forEach(i => {
            types[i.incident_type] = (types[i.incident_type] || 0) + 1;
        });
        return types;
    }, [incidents]);
    // Incident Distribution by Severity
    const incidentBySeverity = useMemo(() => {
        const distribution = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
        incidents.forEach(i => {
            distribution[i.severity]++;
        });
        return distribution;
    }, [incidents]);
    // Control Effectiveness Metrics
    const controlMetrics = useMemo(() => {
        const allControls = filteredRisks.flatMap(r => r.controls || []);
        if (allControls.length === 0) {
            return {
                avgDesign: 0,
                avgImplementation: 0,
                avgMonitoring: 0,
                avgEffectiveness: 0,
                totalControls: 0,
            };
        }
        const avgDesign = allControls.reduce((sum, c) => sum + c.design, 0) / allControls.length;
        const avgImplementation = allControls.reduce((sum, c) => sum + c.implementation, 0) / allControls.length;
        const avgMonitoring = allControls.reduce((sum, c) => sum + c.monitoring, 0) / allControls.length;
        const avgEffectiveness = allControls.reduce((sum, c) => sum + c.effectiveness_evaluation, 0) / allControls.length;
        return {
            avgDesign,
            avgImplementation,
            avgMonitoring,
            avgEffectiveness,
            totalControls: allControls.length,
        };
    }, [filteredRisks]);
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("div", { children: [_jsx("h2", { className: "text-2xl font-bold text-gray-900", children: "Analytics Dashboard" }), _jsxs("p", { className: "text-sm text-gray-600 mt-1", children: ["Comprehensive risk and incident analytics", selectedPeriod.length > 0 && (_jsxs("span", { className: "ml-2 text-blue-600 font-medium", children: ["(Filtered by: ", selectedPeriod.join(', '), ")"] }))] })] }), _jsxs(Badge, { variant: "outline", className: "bg-gradient-to-r from-blue-100 to-purple-100 text-blue-800 border-blue-300", children: [_jsx(BarChart3, { className: "h-4 w-4 mr-1" }), "Real-time Analytics"] })] }), _jsxs(Tabs, { value: activeTab, onValueChange: setActiveTab, children: [_jsxs(TabsList, { className: "grid w-full grid-cols-5", children: [_jsxs(TabsTrigger, { value: "executive", children: [_jsx(Activity, { className: "h-4 w-4 mr-2" }), "Executive Summary"] }), _jsxs(TabsTrigger, { value: "risks", children: [_jsx(PieChart, { className: "h-4 w-4 mr-2" }), "Risk Analytics"] }), _jsxs(TabsTrigger, { value: "trends", children: [_jsx(LineChart, { className: "h-4 w-4 mr-2" }), "Trend Analysis"] }), _jsxs(TabsTrigger, { value: "incidents", children: [_jsx(AlertTriangle, { className: "h-4 w-4 mr-2" }), "Incident Analytics"] }), _jsxs(TabsTrigger, { value: "controls", children: [_jsx(Shield, { className: "h-4 w-4 mr-2" }), "Control Effectiveness"] })] }), _jsx(TabsContent, { value: "executive", className: "space-y-6", children: _jsx(ExecutiveSummary, { metrics: executiveMetrics }) }), _jsx(TabsContent, { value: "risks", className: "space-y-6", children: _jsx(RiskAnalytics, { riskBySeverity: riskBySeverity, riskByCategory: riskByCategory, riskByDivision: riskByDivision, risks: filteredRisks }) }), _jsx(TabsContent, { value: "trends", className: "space-y-6", children: _jsx(TrendAnalysis, { risks: filteredRisks }) }), _jsx(TabsContent, { value: "incidents", className: "space-y-6", children: _jsx(IncidentAnalytics, { incidentByType: incidentByType, incidentBySeverity: incidentBySeverity, totalFinancialImpact: executiveMetrics.totalFinancialImpact }) }), _jsx(TabsContent, { value: "controls", className: "space-y-6", children: _jsx(ControlEffectiveness, { metrics: controlMetrics, risks: filteredRisks }) })] })] }));
}
// Executive Summary Component
function ExecutiveSummary({ metrics }) {
    const riskReductionPercent = metrics.avgInherentScore > 0
        ? ((metrics.avgInherentScore - metrics.avgResidualScore) / metrics.avgInherentScore * 100)
        : 0;
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { className: "grid grid-cols-4 gap-4", children: [_jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardTitle, { className: "text-sm font-medium text-gray-600", children: "Total Risks" }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-3xl font-bold text-gray-900", children: metrics.totalRisks }), _jsxs("div", { className: "flex items-center gap-2 mt-2", children: [_jsxs(Badge, { variant: "outline", className: "bg-red-100 text-red-800 border-red-300", children: [metrics.criticalRisks, " Critical"] }), _jsxs(Badge, { variant: "outline", className: "bg-orange-100 text-orange-800 border-orange-300", children: [metrics.highRisks, " High"] })] })] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardTitle, { className: "text-sm font-medium text-gray-600", children: "Risk Status" }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-3xl font-bold text-blue-600", children: metrics.openRisks }), _jsxs("div", { className: "flex items-center gap-2 mt-2", children: [_jsx("span", { className: "text-sm text-gray-600", children: "Open" }), _jsx("span", { className: "text-sm text-gray-400", children: "|" }), _jsxs("span", { className: "text-sm text-green-600", children: [metrics.closedRisks, " Closed"] })] })] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardTitle, { className: "text-sm font-medium text-gray-600", children: "Avg Risk Score" }) }), _jsxs(CardContent, { children: [_jsxs("div", { className: "flex items-baseline gap-2", children: [_jsx("span", { className: "text-3xl font-bold text-gray-900", children: metrics.avgResidualScore.toFixed(1) }), _jsx("span", { className: "text-sm text-gray-400", children: "/ 25" })] }), _jsxs("div", { className: "flex items-center gap-1 mt-2", children: [_jsx(TrendingDown, { className: "h-4 w-4 text-green-600" }), _jsxs("span", { className: "text-sm text-green-600", children: [riskReductionPercent.toFixed(0), "% reduction"] })] })] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardTitle, { className: "text-sm font-medium text-gray-600", children: "Total Incidents" }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-3xl font-bold text-gray-900", children: metrics.totalIncidents }), _jsxs("div", { className: "flex items-center gap-2 mt-2", children: [_jsxs(Badge, { variant: "outline", className: "bg-yellow-100 text-yellow-800 border-yellow-300", children: [metrics.openIncidents, " Open"] }), _jsxs(Badge, { variant: "outline", className: "bg-red-100 text-red-800 border-red-300", children: [metrics.highSeverityIncidents, " High"] })] })] })] })] }), _jsxs(Card, { className: "bg-gradient-to-r from-green-50 to-blue-50 border-green-200", children: [_jsx(CardHeader, { children: _jsxs(CardTitle, { className: "flex items-center gap-2", children: [_jsx(Activity, { className: "h-5 w-5 text-green-600" }), "Financial Impact Summary"] }) }), _jsxs(CardContent, { children: [_jsxs("div", { className: "text-3xl font-bold text-green-700", children: ["\u20A6", (metrics.totalFinancialImpact / 1000000).toFixed(2), "M"] }), _jsx("p", { className: "text-sm text-gray-600 mt-2", children: "Total financial impact from all incidents" })] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "Risk Mitigation Effectiveness" }) }), _jsx(CardContent, { children: _jsxs("div", { className: "flex items-center justify-around", children: [_jsxs("div", { className: "text-center", children: [_jsx("div", { className: "text-sm font-medium text-gray-600 mb-2", children: "Inherent Risk" }), _jsx("div", { className: "text-4xl font-bold text-red-600", children: metrics.avgInherentScore.toFixed(1) })] }), _jsxs("div", { className: "flex flex-col items-center", children: [_jsx(TrendingDown, { className: "h-8 w-8 text-green-600" }), _jsxs("span", { className: "text-sm text-green-600 font-medium mt-1", children: [riskReductionPercent.toFixed(0), "% Reduction"] })] }), _jsxs("div", { className: "text-center", children: [_jsx("div", { className: "text-sm font-medium text-gray-600 mb-2", children: "Residual Risk" }), _jsx("div", { className: "text-4xl font-bold text-blue-600", children: metrics.avgResidualScore.toFixed(1) })] })] }) })] })] }));
}
// Risk Analytics Component
function RiskAnalytics({ riskBySeverity, riskByCategory, riskByDivision, risks }) {
    const [selectedFilter, setSelectedFilter] = useState(null);
    const [showDialog, setShowDialog] = useState(false);
    const handleFilterClick = (type, value) => {
        setSelectedFilter({ type, value });
        setShowDialog(true);
    };
    const getSeverityFromScore = (score) => {
        if (score >= 20)
            return 'Severe';
        if (score >= 12)
            return 'High';
        if (score >= 6)
            return 'Moderate';
        if (score >= 3)
            return 'Low';
        return 'Minimal';
    };
    const filteredRisks = useMemo(() => {
        if (!selectedFilter)
            return [];
        switch (selectedFilter.type) {
            case 'severity':
                return risks.filter((r) => {
                    const score = r.likelihood_residual * r.impact_residual;
                    return getSeverityFromScore(score) === selectedFilter.value;
                });
            case 'category':
                return risks.filter((r) => r.category === selectedFilter.value);
            case 'division':
                return risks.filter((r) => r.division === selectedFilter.value);
            default:
                return [];
        }
    }, [selectedFilter, risks]);
    const getSeverityColor = (severity) => {
        switch (severity) {
            case 'Severe': return 'bg-red-100 text-red-800 border-red-300';
            case 'High': return 'bg-orange-100 text-orange-800 border-orange-300';
            case 'Moderate': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
            case 'Low': return 'bg-lime-100 text-lime-800 border-lime-300';
            case 'Minimal': return 'bg-green-100 text-green-800 border-green-300';
            default: return 'bg-gray-100 text-gray-800 border-gray-300';
        }
    };
    // Calculate max count for proper bar scaling
    const maxSeverityCount = Math.max(...Object.values(riskBySeverity), 1);
    const maxCategoryCount = Math.max(...Object.values(riskByCategory), 1);
    const maxDivisionCount = Math.max(...Object.values(riskByDivision), 1);
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs(Card, { children: [_jsxs(CardHeader, { children: [_jsx(CardTitle, { children: "Risk Distribution by Severity" }), _jsx("p", { className: "text-sm text-gray-600 mt-1", children: "Click on any bar to view risks" })] }), _jsx(CardContent, { children: _jsx("div", { className: "space-y-3", children: Object.entries(riskBySeverity).map(([severity, count]) => (_jsxs("div", { className: "flex items-center gap-3", children: [_jsx("div", { className: "w-24 text-sm font-medium text-gray-700", children: severity }), _jsx("div", { className: "flex-1", children: _jsx("div", { className: "bg-gray-200 rounded-full h-8 cursor-pointer hover:bg-gray-300 transition-colors", onClick: () => handleFilterClick('severity', severity), children: _jsx("div", { className: `h-8 rounded-full flex items-center px-3 text-sm font-medium transition-all hover:shadow-lg ${severity === 'Severe' ? 'bg-red-600 hover:bg-red-700 text-white' :
                                                    severity === 'High' ? 'bg-orange-500 hover:bg-orange-600 text-white' :
                                                        severity === 'Moderate' ? 'bg-yellow-400 hover:bg-yellow-500 text-black' :
                                                            severity === 'Low' ? 'bg-lime-400 hover:bg-lime-500 text-black' :
                                                                'bg-green-400 hover:bg-green-500 text-black'}`, style: {
                                                    width: `${Math.max((count / maxSeverityCount) * 100, count > 0 ? 10 : 0)}%`,
                                                    minWidth: count > 0 ? '40px' : '0px'
                                                }, title: `Click to view ${count} ${severity} risk(s)`, children: count }) }) })] }, severity))) }) })] }), _jsxs(Card, { children: [_jsxs(CardHeader, { children: [_jsx(CardTitle, { children: "Risk Distribution by Category" }), _jsx("p", { className: "text-sm text-gray-600 mt-1", children: "Click on any bar to view risks" })] }), _jsx(CardContent, { children: _jsx("div", { className: "space-y-3", children: Object.entries(riskByCategory)
                                .sort(([, a], [, b]) => b - a)
                                .map(([category, count]) => (_jsxs("div", { className: "flex items-center gap-3", children: [_jsx("div", { className: "w-32 text-sm font-medium text-gray-700 truncate", title: category, children: category }), _jsx("div", { className: "flex-1", children: _jsx("div", { className: "bg-gray-200 rounded-full h-6 cursor-pointer hover:bg-gray-300 transition-colors", onClick: () => handleFilterClick('category', category), children: _jsx("div", { className: "bg-blue-600 hover:bg-blue-700 h-6 rounded-full flex items-center px-3 text-white text-xs font-medium transition-all hover:shadow-lg", style: {
                                                    width: `${Math.max((count / maxCategoryCount) * 100, count > 0 ? 8 : 0)}%`,
                                                    minWidth: count > 0 ? '35px' : '0px'
                                                }, title: `Click to view ${count} risk(s) in ${category}`, children: count }) }) })] }, category))) }) })] }), _jsxs(Card, { children: [_jsxs(CardHeader, { children: [_jsx(CardTitle, { children: "Risk Distribution by Division" }), _jsx("p", { className: "text-sm text-gray-600 mt-1", children: "Click on any bar to view risks" })] }), _jsx(CardContent, { children: _jsx("div", { className: "space-y-3", children: Object.entries(riskByDivision)
                                .sort(([, a], [, b]) => b - a)
                                .map(([division, count]) => (_jsxs("div", { className: "flex items-center gap-3", children: [_jsx("div", { className: "w-32 text-sm font-medium text-gray-700 truncate", title: division, children: division }), _jsx("div", { className: "flex-1", children: _jsx("div", { className: "bg-gray-200 rounded-full h-6 cursor-pointer hover:bg-gray-300 transition-colors", onClick: () => handleFilterClick('division', division), children: _jsx("div", { className: "bg-purple-600 hover:bg-purple-700 h-6 rounded-full flex items-center px-3 text-white text-xs font-medium transition-all hover:shadow-lg", style: {
                                                    width: `${Math.max((count / maxDivisionCount) * 100, count > 0 ? 8 : 0)}%`,
                                                    minWidth: count > 0 ? '35px' : '0px'
                                                }, title: `Click to view ${count} risk(s) in ${division}`, children: count }) }) })] }, division))) }) })] }), selectedFilter && (_jsx(Dialog, { open: showDialog, onOpenChange: setShowDialog, children: _jsxs(DialogContent, { className: "max-w-5xl max-h-[85vh] overflow-hidden flex flex-col", children: [_jsx(DialogHeader, { children: _jsxs(DialogTitle, { className: "flex items-center justify-between", children: [_jsxs("span", { children: [selectedFilter.type === 'severity' && `${selectedFilter.value} Priority Risks`, selectedFilter.type === 'category' && `${selectedFilter.value} Category`, selectedFilter.type === 'division' && `${selectedFilter.value} Division`] }), _jsxs(Badge, { variant: "outline", className: "ml-2", children: [filteredRisks.length, " Risks"] })] }) }), _jsx("div", { className: "flex-1 overflow-y-auto mt-4", children: _jsx("div", { className: "space-y-3", children: filteredRisks.length === 0 ? (_jsx("div", { className: "text-center py-8 text-gray-500", children: "No risks found for this filter" })) : (filteredRisks.map((risk) => {
                                    const residualScore = risk.likelihood_residual * risk.impact_residual;
                                    const severity = getSeverityFromScore(residualScore);
                                    return (_jsx(Card, { className: "border hover:border-blue-300 transition-colors", children: _jsxs(CardContent, { className: "pt-4", children: [_jsx("div", { className: "flex items-start justify-between mb-2", children: _jsxs("div", { className: "flex-1", children: [_jsxs("div", { className: "flex items-center gap-2 mb-1", children: [_jsx(Badge, { variant: "outline", className: "bg-gray-100 text-gray-800 border-gray-300", children: risk.risk_code }), _jsx(Badge, { variant: "outline", className: getSeverityColor(severity), children: severity }), _jsx(Badge, { variant: "outline", className: "bg-blue-100 text-blue-800 border-blue-300", children: risk.category })] }), _jsx("h4", { className: "font-semibold text-gray-900 mb-1", children: risk.risk_title }), _jsx("p", { className: "text-sm text-gray-700 mb-2", children: risk.risk_description })] }) }), _jsxs("div", { className: "grid grid-cols-3 gap-4 text-sm", children: [_jsxs("div", { children: [_jsx("span", { className: "text-gray-600", children: "Division:" }), _jsx("span", { className: "ml-1 font-medium text-gray-900", children: risk.division })] }), _jsxs("div", { children: [_jsx("span", { className: "text-gray-600", children: "Department:" }), _jsx("span", { className: "ml-1 font-medium text-gray-900", children: risk.department })] }), _jsxs("div", { children: [_jsx("span", { className: "text-gray-600", children: "Owner:" }), _jsx("span", { className: "ml-1 font-medium text-gray-900", children: risk.owner })] })] }), _jsxs("div", { className: "grid grid-cols-2 gap-4 mt-3 pt-3 border-t", children: [_jsxs("div", { children: [_jsx("div", { className: "text-xs text-gray-600 mb-1", children: "Inherent Risk" }), _jsx("div", { className: "flex items-center gap-2", children: _jsxs("span", { className: "text-sm font-medium text-red-600", children: ["L: ", risk.likelihood_inherent, " \u00D7 I: ", risk.impact_inherent, " = ", risk.likelihood_inherent * risk.impact_inherent] }) })] }), _jsxs("div", { children: [_jsx("div", { className: "text-xs text-gray-600 mb-1", children: "Residual Risk" }), _jsx("div", { className: "flex items-center gap-2", children: _jsxs("span", { className: "text-sm font-medium text-blue-600", children: ["L: ", risk.likelihood_residual, " \u00D7 I: ", risk.impact_residual, " = ", risk.likelihood_residual * risk.impact_residual] }) })] })] })] }) }, risk.risk_code));
                                })) }) })] }) }))] }));
}
// Trend Analysis Component
function TrendAnalysis({ risks }) {
    // Group risks by period
    const risksByPeriod = useMemo(() => {
        const periods = {};
        risks.forEach(r => {
            const period = r.relevant_period || 'No Period';
            if (!periods[period])
                periods[period] = [];
            periods[period].push(r);
        });
        return periods;
    }, [risks]);
    const periodStats = useMemo(() => {
        return Object.entries(risksByPeriod).map(([period, periodRisks]) => {
            const avgInherent = periodRisks.reduce((sum, r) => sum + (r.likelihood_inherent * r.impact_inherent), 0) / periodRisks.length;
            const avgResidual = periodRisks.reduce((sum, r) => sum + (r.likelihood_residual * r.impact_residual), 0) / periodRisks.length;
            const critical = periodRisks.filter(r => {
                const score = r.likelihood_residual * r.impact_residual;
                return score >= 20; // Severe
            }).length;
            const high = periodRisks.filter(r => {
                const score = r.likelihood_residual * r.impact_residual;
                return score >= 12 && score < 20; // High
            }).length;
            return {
                period,
                count: periodRisks.length,
                avgInherent,
                avgResidual,
                critical,
                high,
            };
        }).sort((a, b) => a.period.localeCompare(b.period));
    }, [risksByPeriod]);
    return (_jsx("div", { className: "space-y-6", children: _jsxs(Card, { children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "Risk Trends by Period" }) }), _jsx(CardContent, { children: _jsx("div", { className: "overflow-x-auto", children: _jsxs("table", { className: "w-full", children: [_jsx("thead", { children: _jsxs("tr", { className: "border-b", children: [_jsx("th", { className: "text-left py-2 px-3 text-sm font-medium text-gray-700", children: "Period" }), _jsx("th", { className: "text-center py-2 px-3 text-sm font-medium text-gray-700", children: "Total Risks" }), _jsx("th", { className: "text-center py-2 px-3 text-sm font-medium text-gray-700", children: "Critical" }), _jsx("th", { className: "text-center py-2 px-3 text-sm font-medium text-gray-700", children: "High" }), _jsx("th", { className: "text-center py-2 px-3 text-sm font-medium text-gray-700", children: "Avg Inherent" }), _jsx("th", { className: "text-center py-2 px-3 text-sm font-medium text-gray-700", children: "Avg Residual" }), _jsx("th", { className: "text-center py-2 px-3 text-sm font-medium text-gray-700", children: "Trend" })] }) }), _jsx("tbody", { children: periodStats.map((stat, idx) => {
                                        const prevStat = idx > 0 ? periodStats[idx - 1] : null;
                                        const trend = prevStat
                                            ? stat.avgResidual - prevStat.avgResidual
                                            : 0;
                                        return (_jsxs("tr", { className: "border-b hover:bg-gray-50", children: [_jsx("td", { className: "py-3 px-3 text-sm font-medium", children: stat.period }), _jsx("td", { className: "py-3 px-3 text-center text-sm", children: stat.count }), _jsx("td", { className: "py-3 px-3 text-center", children: _jsx(Badge, { variant: "outline", className: "bg-red-100 text-red-800 border-red-300", children: stat.critical }) }), _jsx("td", { className: "py-3 px-3 text-center", children: _jsx(Badge, { variant: "outline", className: "bg-orange-100 text-orange-800 border-orange-300", children: stat.high }) }), _jsx("td", { className: "py-3 px-3 text-center text-sm font-medium text-red-600", children: stat.avgInherent.toFixed(1) }), _jsx("td", { className: "py-3 px-3 text-center text-sm font-medium text-blue-600", children: stat.avgResidual.toFixed(1) }), _jsx("td", { className: "py-3 px-3 text-center", children: idx === 0 ? (_jsx(Minus, { className: "h-4 w-4 text-gray-400 mx-auto" })) : trend < 0 ? (_jsxs("div", { className: "flex items-center justify-center gap-1 text-green-600", children: [_jsx(TrendingDown, { className: "h-4 w-4" }), _jsx("span", { className: "text-xs", children: "Improving" })] })) : trend > 0 ? (_jsxs("div", { className: "flex items-center justify-center gap-1 text-red-600", children: [_jsx(TrendingUp, { className: "h-4 w-4" }), _jsx("span", { className: "text-xs", children: "Worsening" })] })) : (_jsxs("div", { className: "flex items-center justify-center gap-1 text-gray-600", children: [_jsx(Minus, { className: "h-4 w-4" }), _jsx("span", { className: "text-xs", children: "Stable" })] })) })] }, stat.period));
                                    }) })] }) }) })] }) }));
}
// Incident Analytics Component
function IncidentAnalytics({ incidentByType, incidentBySeverity, totalFinancialImpact }) {
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs(Card, { children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "Incident Distribution by Type" }) }), _jsx(CardContent, { children: _jsx("div", { className: "space-y-3", children: Object.entries(incidentByType)
                                .sort(([, a], [, b]) => b - a)
                                .map(([type, count]) => (_jsxs("div", { className: "flex items-center gap-3", children: [_jsx("div", { className: "w-40 text-sm font-medium text-gray-700 truncate", children: type }), _jsx("div", { className: "flex-1", children: _jsx("div", { className: "bg-gray-200 rounded-full h-6", children: _jsx("div", { className: "bg-orange-600 h-6 rounded-full flex items-center px-3 text-white text-xs font-medium", style: { width: `${Math.min(count * 10, 100)}%` }, children: count }) }) })] }, type))) }) })] }), _jsxs(Card, { children: [_jsx(CardHeader, { children: _jsx(CardTitle, { children: "Incident Distribution by Severity" }) }), _jsx(CardContent, { children: _jsx("div", { className: "space-y-3", children: Object.entries(incidentBySeverity)
                                .reverse()
                                .map(([severity, count]) => (_jsxs("div", { className: "flex items-center gap-3", children: [_jsxs("div", { className: "w-24 text-sm font-medium text-gray-700", children: ["Level ", severity] }), _jsx("div", { className: "flex-1", children: _jsx("div", { className: "bg-gray-200 rounded-full h-8", children: _jsx("div", { className: `h-8 rounded-full flex items-center px-3 text-white text-sm font-medium ${Number(severity) >= 4 ? 'bg-red-600' :
                                                    Number(severity) === 3 ? 'bg-orange-500' :
                                                        'bg-yellow-500'}`, style: { width: `${Math.min(count * 15, 100)}%` }, children: count }) }) })] }, severity))) }) })] }), _jsxs(Card, { className: "bg-gradient-to-r from-red-50 to-orange-50 border-red-200", children: [_jsx(CardHeader, { children: _jsxs(CardTitle, { className: "flex items-center gap-2", children: [_jsx(AlertTriangle, { className: "h-5 w-5 text-red-600" }), "Total Financial Impact"] }) }), _jsxs(CardContent, { children: [_jsxs("div", { className: "text-4xl font-bold text-red-700", children: ["\u20A6", (totalFinancialImpact / 1000000).toFixed(2), "M"] }), _jsx("p", { className: "text-sm text-gray-600 mt-2", children: "Cumulative financial loss from all incidents" })] })] })] }));
}
// Control Effectiveness Component
function ControlEffectiveness({ metrics, risks }) {
    const dimeLabels = ['Not Implemented', 'Partially', 'Substantially', 'Fully'];
    const getDimeColor = (score) => {
        if (score >= 2.5)
            return 'bg-green-600';
        if (score >= 1.5)
            return 'bg-yellow-600';
        return 'bg-red-600';
    };
    // Find controls with low scores
    const lowScoringControls = useMemo(() => {
        const controls = [];
        risks.forEach(risk => {
            risk.controls?.forEach(control => {
                const avg = (control.design + control.implementation + control.monitoring + control.effectiveness_evaluation) / 4;
                if (avg < 2) {
                    controls.push({ risk, control, avgScore: avg });
                }
            });
        });
        return controls.sort((a, b) => a.avgScore - b.avgScore).slice(0, 10);
    }, [risks]);
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { className: "grid grid-cols-4 gap-4", children: [_jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardTitle, { className: "text-sm font-medium text-gray-600", children: "Design" }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-3xl font-bold text-gray-900", children: metrics.avgDesign.toFixed(1) }), _jsxs("div", { className: "mt-2", children: [_jsx("div", { className: "bg-gray-200 rounded-full h-2", children: _jsx("div", { className: `h-2 rounded-full ${getDimeColor(metrics.avgDesign)}`, style: { width: `${(metrics.avgDesign / 3) * 100}%` } }) }), _jsx("span", { className: "text-xs text-gray-500 mt-1 block", children: dimeLabels[Math.round(metrics.avgDesign)] })] })] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardTitle, { className: "text-sm font-medium text-gray-600", children: "Implementation" }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-3xl font-bold text-gray-900", children: metrics.avgImplementation.toFixed(1) }), _jsxs("div", { className: "mt-2", children: [_jsx("div", { className: "bg-gray-200 rounded-full h-2", children: _jsx("div", { className: `h-2 rounded-full ${getDimeColor(metrics.avgImplementation)}`, style: { width: `${(metrics.avgImplementation / 3) * 100}%` } }) }), _jsx("span", { className: "text-xs text-gray-500 mt-1 block", children: dimeLabels[Math.round(metrics.avgImplementation)] })] })] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardTitle, { className: "text-sm font-medium text-gray-600", children: "Monitoring" }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-3xl font-bold text-gray-900", children: metrics.avgMonitoring.toFixed(1) }), _jsxs("div", { className: "mt-2", children: [_jsx("div", { className: "bg-gray-200 rounded-full h-2", children: _jsx("div", { className: `h-2 rounded-full ${getDimeColor(metrics.avgMonitoring)}`, style: { width: `${(metrics.avgMonitoring / 3) * 100}%` } }) }), _jsx("span", { className: "text-xs text-gray-500 mt-1 block", children: dimeLabels[Math.round(metrics.avgMonitoring)] })] })] })] }), _jsxs(Card, { children: [_jsx(CardHeader, { className: "pb-2", children: _jsx(CardTitle, { className: "text-sm font-medium text-gray-600", children: "Effectiveness" }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-3xl font-bold text-gray-900", children: metrics.avgEffectiveness.toFixed(1) }), _jsxs("div", { className: "mt-2", children: [_jsx("div", { className: "bg-gray-200 rounded-full h-2", children: _jsx("div", { className: `h-2 rounded-full ${getDimeColor(metrics.avgEffectiveness)}`, style: { width: `${(metrics.avgEffectiveness / 3) * 100}%` } }) }), _jsx("span", { className: "text-xs text-gray-500 mt-1 block", children: dimeLabels[Math.round(metrics.avgEffectiveness)] })] })] })] })] }), _jsxs(Card, { className: "bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200", children: [_jsx(CardHeader, { children: _jsxs(CardTitle, { className: "flex items-center gap-2", children: [_jsx(Shield, { className: "h-5 w-5 text-blue-600" }), "Total Active Controls"] }) }), _jsxs(CardContent, { children: [_jsx("div", { className: "text-4xl font-bold text-blue-700", children: metrics.totalControls }), _jsx("p", { className: "text-sm text-gray-600 mt-2", children: "Control measures across all risks" })] })] }), lowScoringControls.length > 0 && (_jsxs(Card, { className: "border-orange-200", children: [_jsx(CardHeader, { children: _jsxs(CardTitle, { className: "flex items-center gap-2", children: [_jsx(AlertTriangle, { className: "h-5 w-5 text-orange-600" }), "Controls Requiring Attention"] }) }), _jsx(CardContent, { children: _jsx("div", { className: "space-y-3", children: lowScoringControls.map((item, idx) => (_jsx("div", { className: "border-l-4 border-orange-500 pl-3 py-2", children: _jsxs("div", { className: "flex items-start justify-between", children: [_jsxs("div", { className: "flex-1", children: [_jsxs("div", { className: "text-sm font-medium text-gray-900 mb-1", children: ["[", item.risk.risk_code, "] ", item.risk.risk_title] }), _jsx("div", { className: "text-sm text-gray-700 mb-2", children: item.control.description }), _jsxs("div", { className: "flex gap-2 text-xs", children: [_jsxs("span", { className: "text-gray-600", children: ["D: ", item.control.design] }), _jsxs("span", { className: "text-gray-600", children: ["I: ", item.control.implementation] }), _jsxs("span", { className: "text-gray-600", children: ["M: ", item.control.monitoring] }), _jsxs("span", { className: "text-gray-600", children: ["E: ", item.control.effectiveness_evaluation] })] })] }), _jsxs(Badge, { variant: "outline", className: "bg-orange-100 text-orange-800 border-orange-300", children: ["Avg: ", item.avgScore.toFixed(1)] })] }) }, idx))) }) })] }))] }));
}
